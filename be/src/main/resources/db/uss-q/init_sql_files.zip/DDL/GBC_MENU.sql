--------------------------------------------------------
--  DDL for Table GBC_MENU
--------------------------------------------------------

  CREATE TABLE "GBC_MENU" 
   (	"ID" NUMBER(18,0), 
	"ID_MENU" NUMBER(18,0), 
	"NAME_K" VARCHAR2(50 BYTE), 
	"MEMO_K" VARCHAR2(500 BYTE), 
	"ENABLED" NUMBER(1,0), 
	"ITEM_URL" VARCHAR2(250 BYTE), 
	"CREATED_BY" VARCHAR2(20 BYTE), 
	"CREATED" TIMESTAMP (6), 
	"MODIFIED_BY" VARCHAR2(20 BYTE), 
	"MODIFIED" TIMESTAMP (6), 
	"MENU_ORDER" NUMBER(2,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;

   COMMENT ON COLUMN "GBC_MENU"."ID" IS 'Primary key';
   COMMENT ON COLUMN "GBC_MENU"."ID_MENU" IS 'Parent menu foreign key';
   COMMENT ON COLUMN "GBC_MENU"."NAME_K" IS 'Menu name (dictionary key)';
   COMMENT ON COLUMN "GBC_MENU"."MEMO_K" IS 'Menu meno, description or notes (dictionary key)';
   COMMENT ON COLUMN "GBC_MENU"."ENABLED" IS 'Is menu enabled, 1 - enabled, 0 - disabled';
   COMMENT ON COLUMN "GBC_MENU"."ITEM_URL" IS 'Menu item url';
   COMMENT ON COLUMN "GBC_MENU"."CREATED_BY" IS 'Login of user who created the record';
   COMMENT ON COLUMN "GBC_MENU"."CREATED" IS 'Record creation date';
   COMMENT ON COLUMN "GBC_MENU"."MODIFIED_BY" IS 'Login of user who modified the record.';
   COMMENT ON COLUMN "GBC_MENU"."MODIFIED" IS 'Record modification date';
   COMMENT ON COLUMN "GBC_MENU"."MENU_ORDER" IS 'Menu order';
   COMMENT ON TABLE "GBC_MENU"  IS 'Contains tree structure of menu items.';
