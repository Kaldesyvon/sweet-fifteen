--------------------------------------------------------
--  DDL for Table GBC_QUANTITY
--------------------------------------------------------

  CREATE TABLE "GBC_QUANTITY" 
   (	"ID" NUMBER(18,0), 
	"ID_MATERIAL_NODE" NUMBER(18,0), 
	"ID_UNIT" NUMBER(18,0), 
	"REMOTE_CODE" VARCHAR2(100 BYTE), 
	"QUANTITY" NUMBER, 
	"MEMO" VARCHAR2(250 BYTE), 
	"CREATED_BY" VARCHAR2(20 BYTE), 
	"CREATED" TIMESTAMP (6), 
	"MODIFIED_BY" VARCHAR2(20 BYTE), 
	"MODIFIED" TIMESTAMP (6), 
	"OBJ_VERSION" NUMBER(18,0), 
	"DATE_FROM" TIMESTAMP (6), 
	"DATE_TO" TIMESTAMP (6), 
	"AUTO_ANALYSIS" NUMBER(1,0) DEFAULT 0, 
	"EDITABLE" NUMBER(1,0) DEFAULT 1, 
	"IO" NUMBER(1,0), 
	"UNCERTAINTY" NUMBER, 
	"ID_METER" NUMBER, 
	"NUMBER_OF_MEASUREMENTS" NUMBER DEFAULT 1, 
	"ID_REMOTE_MATERIAL_CODE" NUMBER(9,0), 
	"ID_REMOTE_CODE_LOAD" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE ROW MOVEMENT ;

   COMMENT ON COLUMN "GBC_QUANTITY"."ID" IS 'Primary key';
   COMMENT ON COLUMN "GBC_QUANTITY"."ID_MATERIAL_NODE" IS 'Material node foreign key';
   COMMENT ON COLUMN "GBC_QUANTITY"."ID_UNIT" IS 'Unit foreign key for quantity';
   COMMENT ON COLUMN "GBC_QUANTITY"."REMOTE_CODE" IS 'Identification/unique code of quantity on remote system - sent by web service';
   COMMENT ON COLUMN "GBC_QUANTITY"."QUANTITY" IS 'Material quantity';
   COMMENT ON COLUMN "GBC_QUANTITY"."MEMO" IS 'Memo, description or quantity notes';
   COMMENT ON COLUMN "GBC_QUANTITY"."CREATED_BY" IS 'Login of user who created the record';
   COMMENT ON COLUMN "GBC_QUANTITY"."CREATED" IS 'Record creation date';
   COMMENT ON COLUMN "GBC_QUANTITY"."MODIFIED_BY" IS 'Login of user who modified the record.';
   COMMENT ON COLUMN "GBC_QUANTITY"."MODIFIED" IS 'Record modification date';
   COMMENT ON COLUMN "GBC_QUANTITY"."OBJ_VERSION" IS 'Object version';
   COMMENT ON COLUMN "GBC_QUANTITY"."DATE_FROM" IS 'Month of consumtion/production of material quantity if it is month value, or date/time of consumtion/production of material quantity if it is not month value or start date/time of consumtion/production of material quantity if it is not month value and ''date to'' is not null.';
   COMMENT ON COLUMN "GBC_QUANTITY"."DATE_TO" IS 'End date/time of consumtion/production of material quantity if it is not month value and ''date to'' is not null.';
   COMMENT ON COLUMN "GBC_QUANTITY"."AUTO_ANALYSIS" IS 'Auto assign analysis if missing or analysis added/changed, 1- true, 0 - false';
   COMMENT ON COLUMN "GBC_QUANTITY"."EDITABLE" IS 'Editable, 1- yes, 0 - no';
   COMMENT ON COLUMN "GBC_QUANTITY"."IO" IS 'Flow, 1- input, -1 -output';
   COMMENT ON COLUMN "GBC_QUANTITY"."ID_REMOTE_MATERIAL_CODE" IS 'ID from GBC_MATERIAL_CONVERSION, BCO2 material code';
   COMMENT ON COLUMN "GBC_QUANTITY"."ID_REMOTE_CODE_LOAD" IS 'ID from GBC_LOAD_... tab';
   COMMENT ON TABLE "GBC_QUANTITY"  IS 'Material quantity than are on plant input or output.';
