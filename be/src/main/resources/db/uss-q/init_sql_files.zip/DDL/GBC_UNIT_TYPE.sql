--------------------------------------------------------
--  DDL for Table GBC_UNIT_TYPE
--------------------------------------------------------

  CREATE TABLE "GBC_UNIT_TYPE" 
   (	"ID" NUMBER(18,0), 
	"NAME_K" VARCHAR2(50 BYTE), 
	"CREATED_BY" VARCHAR2(20 BYTE), 
	"CREATED" TIMESTAMP (6), 
	"MODIFIED_BY" VARCHAR2(20 BYTE), 
	"MODIFIED" TIMESTAMP (6), 
	"MEMO_K" VARCHAR2(30 BYTE), 
	"QUANTITY" NUMBER(1,0) DEFAULT 0, 
	"ANALYSIS" NUMBER(1,0) DEFAULT 0, 
	"COMPUTE" NUMBER(1,0) DEFAULT 1, 
	"OBJ_VERSION" NUMBER(18,0) DEFAULT 0
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;

   COMMENT ON COLUMN "GBC_UNIT_TYPE"."ID" IS 'Primary key';
   COMMENT ON COLUMN "GBC_UNIT_TYPE"."NAME_K" IS 'Unit type name';
   COMMENT ON COLUMN "GBC_UNIT_TYPE"."CREATED_BY" IS 'Login of user who created the record';
   COMMENT ON COLUMN "GBC_UNIT_TYPE"."CREATED" IS 'Record creation date';
   COMMENT ON COLUMN "GBC_UNIT_TYPE"."MODIFIED_BY" IS 'Login of user who modified the record.';
   COMMENT ON COLUMN "GBC_UNIT_TYPE"."MODIFIED" IS 'Record modification date';
   COMMENT ON COLUMN "GBC_UNIT_TYPE"."MEMO_K" IS 'Unit type memo';
   COMMENT ON COLUMN "GBC_UNIT_TYPE"."QUANTITY" IS 'Unit type allowed for quantity (1), not allowed (0)';
   COMMENT ON COLUMN "GBC_UNIT_TYPE"."ANALYSIS" IS 'Unit type allowed for analysis (1), not allowed (0)';
   COMMENT ON COLUMN "GBC_UNIT_TYPE"."COMPUTE" IS 'Allow to compute quantity*analysis (1), not allowed (0), eg. for temperature, pH this flag have to be set to (0).';
   COMMENT ON COLUMN "GBC_UNIT_TYPE"."OBJ_VERSION" IS 'Object version';
   COMMENT ON TABLE "GBC_UNIT_TYPE"  IS 'List of unit types.';
