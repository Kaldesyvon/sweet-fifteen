--------------------------------------------------------
--  DDL for Table GBC_UNIT
--------------------------------------------------------

  CREATE TABLE "GBC_UNIT" 
   (	"ID" NUMBER(18,0), 
	"ID_UNIT_TYPE" NUMBER(18,0), 
	"CODE" VARCHAR2(20 BYTE), 
	"ABBR" VARCHAR2(20 BYTE), 
	"NAME_K" VARCHAR2(20 BYTE), 
	"K" NUMBER, 
	"Q" NUMBER, 
	"CREATED_BY" VARCHAR2(20 BYTE), 
	"CREATED" TIMESTAMP (6), 
	"MODIFIED_BY" VARCHAR2(20 BYTE), 
	"MODIFIED" TIMESTAMP (6), 
	"OBJ_VERSION" NUMBER(18,0) DEFAULT 0
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;

   COMMENT ON COLUMN "GBC_UNIT"."ID" IS 'Primary key';
   COMMENT ON COLUMN "GBC_UNIT"."ID_UNIT_TYPE" IS 'Unit type foreign key';
   COMMENT ON COLUMN "GBC_UNIT"."CODE" IS 'Unit code';
   COMMENT ON COLUMN "GBC_UNIT"."ABBR" IS 'Unit abbr.';
   COMMENT ON COLUMN "GBC_UNIT"."NAME_K" IS 'Unit name';
   COMMENT ON COLUMN "GBC_UNIT"."K" IS 'Coefficient K for calculating between unit of the same type. Formula : unit_to = K_to/K_from*unit_from + Q_from - Q_to*(K_to/K_from)';
   COMMENT ON COLUMN "GBC_UNIT"."Q" IS 'Coefficient Q for calculating between unit of the same type. Formula : unit_to = K_to/K_from*unit_from + Q_from - Q_to*(K_to/K_from)';
   COMMENT ON COLUMN "GBC_UNIT"."CREATED_BY" IS 'Login of user who created the record';
   COMMENT ON COLUMN "GBC_UNIT"."CREATED" IS 'Record creation date';
   COMMENT ON COLUMN "GBC_UNIT"."MODIFIED_BY" IS 'Login of user who modified the record';
   COMMENT ON COLUMN "GBC_UNIT"."MODIFIED" IS 'Record modification date';
   COMMENT ON COLUMN "GBC_UNIT"."OBJ_VERSION" IS 'Object version';
   COMMENT ON TABLE "GBC_UNIT"  IS 'List of units used for material quantuty.';
