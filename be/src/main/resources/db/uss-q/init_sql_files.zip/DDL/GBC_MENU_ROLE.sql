--------------------------------------------------------
--  DDL for Table GBC_MENU_ROLE
--------------------------------------------------------

  CREATE TABLE "GBC_MENU_ROLE" 
   (	"ID" NUMBER(18,0), 
	"ID_MENU" NUMBER(18,0), 
	"ID_ROLE" NUMBER(18,0), 
	"CREATED_BY" VARCHAR2(20 BYTE), 
	"CREATED" TIMESTAMP (6), 
	"MODIFIED_BY" VARCHAR2(20 BYTE), 
	"MODIFIED" TIMESTAMP (6), 
	"ALL_PLANTS" NUMBER(1,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;

   COMMENT ON COLUMN "GBC_MENU_ROLE"."ID" IS 'Primary key';
   COMMENT ON COLUMN "GBC_MENU_ROLE"."ID_MENU" IS 'Menu foreign key';
   COMMENT ON COLUMN "GBC_MENU_ROLE"."ID_ROLE" IS 'Role foreign key';
   COMMENT ON COLUMN "GBC_MENU_ROLE"."CREATED_BY" IS 'Login of user who created the record';
   COMMENT ON COLUMN "GBC_MENU_ROLE"."CREATED" IS 'Record creation date';
   COMMENT ON COLUMN "GBC_MENU_ROLE"."MODIFIED_BY" IS 'Login of user who modified the record.';
   COMMENT ON COLUMN "GBC_MENU_ROLE"."MODIFIED" IS 'Record modification date';
   COMMENT ON COLUMN "GBC_MENU_ROLE"."ALL_PLANTS" IS 'All nodes required , 1- yes, 0 - no.';
   COMMENT ON TABLE "GBC_MENU_ROLE"  IS 'Contains informations how are menu items assigned to roles - which roles have access to which menu items.';
