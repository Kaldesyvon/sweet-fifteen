--------------------------------------------------------
--  DDL for View VGBC_RESULTS_MONTH
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VGBC_RESULTS_MONTH" ("ID", "ID_UNIT_SET", "ID_NODE", "ID_MATERIAL", "ID_MATERIAL_NODE", "ID_ANALYSIS_PARAM", "ID_SCOPE", "QUANTITY", "ID_UNIT", "UNIT_ABBR", "ANALYTICAL_VALUE", "ID_UNIT_NUMEN", "ID_UNIT_DENOM", "UNIT_ABBR_AV", "MONTH", "NO_OF_ROWS", "NODE_REPORT_POS", "ANALYSIS_PARAM_NAME_K", "MATERIAL_NAME", "NODE_NAME_K", "SCOPE_NAME_K", "IO", "UNCERTAINTY") AS
  SELECT        q.id_unit_set
              || q.id_node
              || q.id_material
              || TRUNC (date_from, 'MM')
              || a.id_analysis_param
              || s.id
                 id,                                       --iba rep hibernate
              q.id_unit_set id_unit_set,
              q.id_node id_node,
              q.id_material id_material,
              smn.id_material_node id_material_node,
              a.id_analysis_param id_analysis_param,
              s.id id_scope,
              SUM (q.quantity) quantity,
              q.id_unit_to id_unit,
              q.unit_to_abbr unit_abbr,
              SUM(DECODE (
                     ut.compute,
                     0,
                     NULL,
                     ( (a.factor_a * smn.FACTOR_A
                        + NVL (a.factor_b, 0) * NVL (smn.FACTOR_B, 0))
                      * q.quantity
                      * q.IO
                      * smn.USE_CALCULATION)
                  ))
                 analytical_value,
              a.id_unit_numen_to id_unit_numen,
              a.id_unit_denom_to id_unit_denom,
              a.unit_numen_abbr_to unit_abbr_av,
              TRUNC (date_from, 'MM') MONTH,
              COUNT ( * ) no_of_rows,
              q.NODE_REPORT_POS NODE_REPORT_POS,
              a.ANALYSIS_PARAM_NAME_K ANALYSIS_PARAM_NAME_K,
              q.MATERIAL_NAME MATERIAL_NAME,
              q.PLANT_NAME NODE_NAME_K,
              s.name_k scope_name_k,
              q.io,
             CASE 
                 WHEN SUM(DECODE (ut.compute,0,NULL,( (a.factor_a * smn.FACTOR_A + NVL (a.factor_b, 0) * NVL (smn.FACTOR_B, 0) + NVL (a.factor_c, 0) * NVL (smn.FACTOR_C, 0)) * q.quantity * smn.USE_CALCULATION))) > 0 
                 THEN ABS(SQRT (SUM (POWER(SQRT(POWER(NVL(q.UNCERTAINTY,(SELECT TO_NUMBER(VALUE) FROM GBC_PARAM WHERE CODE='param.maxUncertainty'))/SQRT(NVL(q.NUMBER_OF_MEASUREMENTS,1)),2)+POWER(NVL(a.UNCERTAINTY,(SELECT TO_NUMBER(VALUE) FROM GBC_PARAM WHERE CODE='param.maxUncertainty')),2))*DECODE (ut.compute,0,NULL,( (a.factor_a * smn.FACTOR_A + NVL (a.factor_b, 0) * NVL (smn.FACTOR_B, 0) + NVL (a.factor_c, 0) * NVL (smn.FACTOR_C, 0)) * q.quantity * q.IO * smn.USE_CALCULATION)),2)))/SUM(DECODE (ut.compute,0,NULL,( (a.factor_a * smn.FACTOR_A + NVL (a.factor_b, 0) * NVL (smn.FACTOR_B, 0) + NVL (a.factor_c, 0) * NVL (smn.FACTOR_C, 0)) * q.quantity * q.IO * smn.USE_CALCULATION)))) 
                 ELSE 0 
              END uncertainty
       FROM                  vgbc_quantity q
                          CROSS JOIN
                             gbc_scope s
                       INNER JOIN
                          gbc_scope_material_node smn
                       ON smn.id_material_node = q.id_material_node
                          AND s.id = smn.id_scope
                    LEFT OUTER JOIN
                       gbc_quantity_analysis qa
                    ON qa.ID_QUANTITY = q.ID
                 LEFT OUTER JOIN
                    vgbc_analysis a
                 ON     a.ID = qa.ID_ANALYSIS
                    AND a.id_unit_set = q.id_unit_set
                    AND qa.ID_ANALYSIS_PARAM = a.ID_ANALYSIS_PARAM
              LEFT OUTER JOIN
                 gbc_unit_type ut
              ON ut.id = a.id_unit_type_numen
   --  left outer join gbc_analysis_param ap on ap.ID = qa.ID_ANALYSIS_PARAM AND ap.ID = a.ID_ANALYSIS_PARAM
   -- WHERE   q.id_unit_set = 1 AND s.id = 54 AND id_analysis_param = 1
   GROUP BY q.id_unit_set
              || q.id_node
              || q.id_material
              || TRUNC (date_from, 'MM')
              || a.id_analysis_param
              || s.id, q.id_unit_set, q.id_node, q.id_material, smn.id_material_node, a.id_analysis_param, s.id, q.id_unit_to, q.unit_to_abbr, a.id_unit_numen_to, a.id_unit_denom_to, a.unit_numen_abbr_to, TRUNC (date_from, 'MM'), q.NODE_REPORT_POS, a.ANALYSIS_PARAM_NAME_K, q.MATERIAL_NAME, q.PLANT_NAME, s.name_k, q.io
;
  GRANT SELECT ON "VGBC_RESULTS_MONTH" TO "GBC_PRX";
  GRANT SELECT ON "VGBC_RESULTS_MONTH" TO "TRANSFER_BI";
