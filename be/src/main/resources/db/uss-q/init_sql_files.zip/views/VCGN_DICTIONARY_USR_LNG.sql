--------------------------------------------------------
--  DDL for View VCGN_DICTIONARY_USR_LNG
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_DICTIONARY_USR_LNG" ("ID", "ID_LANGUAGE", "KEY", "TRANSLATION", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "OBJ_VERSION", "ID_DICTIONARY_TABLE") AS
  SELECT   "ID",
            "ID_LANGUAGE",
            "KEY",
            "TRANSLATION",
            "CREATED_BY",
            "CREATED",
            "MODIFIED_BY",
            "MODIFIED",
            "OBJ_VERSION",
            "ID_DICTIONARY_TABLE"
     FROM   gbc_dictionary d
    WHERE   D.ID_LANGUAGE = ph_tst_cgn.getidlanguage 
;
  GRANT SELECT ON "VCGN_DICTIONARY_USR_LNG" TO "TRANSFER_BI";
