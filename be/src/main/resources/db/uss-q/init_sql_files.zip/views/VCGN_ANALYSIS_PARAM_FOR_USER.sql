--------------------------------------------------------
--  DDL for View VCGN_ANALYSIS_PARAM_FOR_USER
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_ANALYSIS_PARAM_FOR_USER" ("ID", "CODE", "NAME_K", "SYMBOL", "MASS", "CAS_NO", "ID_UNIT_TYPE", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "OBJ_VERSION", "ID_PARENT_ANALYSIS_PARAM", "PARENT_KOEF", "ID_TYPE", "ID_ANALYSIS_FORMAT", "ORDER", "MEMO") AS
  SELECT "ID",
          "CODE",
          "NAME_K",
          "SYMBOL",
          "MASS",
          "CAS_NO",
          "ID_UNIT_TYPE",
          "CREATED_BY",
          "CREATED",
          "MODIFIED_BY",
          "MODIFIED",
          "OBJ_VERSION",
          "ID_PARENT_ANALYSIS_PARAM",
          "PARENT_KOEF",
          "ID_TYPE",
          "ID_ANALYSIS_FORMAT",
          "ORDER",
          "MEMO"
     FROM GBC_ANALYSIS_PARAM
    WHERE id != 71 OR (id = 71 AND ph_tst_cgn.hasusercostrole () = 1)
;
  GRANT SELECT ON "VCGN_ANALYSIS_PARAM_FOR_USER" TO "TRANSFER_BI";
  GRANT SELECT ON "VCGN_ANALYSIS_PARAM_FOR_USER" TO "CGN_PRX";
