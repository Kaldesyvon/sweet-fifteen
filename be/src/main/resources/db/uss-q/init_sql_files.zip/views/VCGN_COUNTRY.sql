--------------------------------------------------------
--  DDL for View VCGN_COUNTRY
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_COUNTRY" ("ID", "ID_REGION", "NAME", "REPORT_POS", "MEMO", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "OBJ_VERSION") AS
  SELECT   c.ID,
            c.ID_REGION,
            NVL (NVL (dul.translation, de.translation), c.NAME_K) name,
            c.REPORT_POS,
            c.MEMO,
            c.CREATED_BY,
            c.CREATED,
            c.MODIFIED_BY,
            c.MODIFIED,
            c.OBJ_VERSION
     FROM         gbc_country c
               LEFT OUTER JOIN
                  vcgn_dictionary_usr_lng dul
               ON dul.key = c.name_k
            LEFT OUTER JOIN
               vcgn_dictionary_en de
            ON de.key = c.name_k 
;
  GRANT SELECT ON "VCGN_COUNTRY" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_COUNTRY" TO "TRANSFER_BI";
