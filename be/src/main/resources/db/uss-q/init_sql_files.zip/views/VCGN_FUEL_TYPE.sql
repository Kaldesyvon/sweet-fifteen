--------------------------------------------------------
--  DDL for View VCGN_FUEL_TYPE
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_FUEL_TYPE" ("ID", "NAME") AS
  SELECT   FT.ID,
            NVL (NVL (dul.translation, de.translation), ft.NAME_K) name
     FROM         gbc_fuel_type ft
               LEFT OUTER JOIN
                  vcgn_dictionary_usr_lng dul
               ON dul.key = ft.name_k
            LEFT OUTER JOIN
               vcgn_dictionary_en de
            ON de.key = ft.name_k 
;
  GRANT SELECT ON "VCGN_FUEL_TYPE" TO "TRANSFER_BI";
  GRANT SELECT ON "VCGN_FUEL_TYPE" TO "CGN_PRX";
