--------------------------------------------------------
--  DDL for View VCGN_SCOPE_NODE
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_SCOPE_NODE" ("ID_SCOPE", "SCOPE_NAME", "ID_SCOPE_FUEL_SPEC", "SCOPE_FUEL_SPEC_NAME", "ID_SCOPE_PROCESS_SPEC", "SCOPE_PROCESS_SPEC_NAME", "ID_SCOPE_TYPE_SPEC", "SCOPE_TYPE_SPEC_NAME", "ID_MATERIAL_NODE", "ID_MATERIAL", "ID_NODE", "USE_CALCULATION") AS
  SELECT   DISTINCT s.id AS id_scope,
                     s.name AS scope_name,
                     S.ID_SCOPE_FUEL_SPEC,
                     sfs.name SCOPE_FUEL_SPEC_NAME,
                     S.ID_SCOPE_PROCESS_SPEC,
                     sps.name SCOPE_PROCESS_SPEC_NAME,
                     S.ID_SCOPE_TYPE_SPEC,
                     sts.name SCOPE_TYPE_SPEC_NAME,
                     smn.id_material_node,
                     MN.ID_MATERIAL,
                     mn.id_node,
                     SMN.USE_CALCULATION
     FROM                     vcgn_scope s
                           INNER JOIN
                              GBC_SCOPE_MATERIAL_NODE smn
                           ON smn.id_scope = s.id
                        INNER JOIN
                           gbc_material_node mn
                        ON mn.id = smn.id_material_node
                     INNER JOIN
                        vcgn_user_nodes_all un
                     ON un.id = mn.id_node
                  LEFT OUTER JOIN
                     VCGN_SCOPE_FUEL_SPEC sfs
                  ON sfs.id = S.ID_SCOPE_FUEL_SPEC
               LEFT OUTER JOIN
                  VCGN_SCOPE_PROCESS_SPEC sps
               ON sps.id = S.ID_SCOPE_PROCESS_SPEC
            LEFT OUTER JOIN
               VCGN_SCOPE_TYPE_SPEC sts
            ON sts.id = S.ID_SCOPE_TYPE_SPEC 
;
  GRANT SELECT ON "VCGN_SCOPE_NODE" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_SCOPE_NODE" TO "TRANSFER_BI";
