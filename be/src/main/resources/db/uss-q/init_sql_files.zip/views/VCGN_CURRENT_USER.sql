--------------------------------------------------------
--  DDL for View VCGN_CURRENT_USER
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_CURRENT_USER" ("ID", "ID_NODE", "LOGIN", "NAME", "SURNAME", "FUNCTION", "EMAIL", "PHONE", "ID_LANGUAGE", "ID_NODE_DEF", "TIMEZONE", "MAIL_NOTIFICATION", "ID_UNIT_SET", "ID_SCOPE_DEF", "ID_ANALYSIS_PARAM_DEF", "UNIT_SET_NAME") AS
  SELECT   u.ID,
            u.ID_NODE,
            u.LOGIN,
            u.NAME,
            u.SURNAME,
            u.FUNCTION,
            u.EMAIL,
            u.PHONE,
            u.ID_LANGUAGE,
            u.ID_NODE_DEF,
            u.TIMEZONE,
            u.MAIL_NOTIFICATION,
            u.ID_UNIT_SET,
            u.ID_SCOPE_DEF,
            u.ID_ANALYSIS_PARAM_DEF,
            us.name unit_set_name
     FROM   gbc_user u, vcgn_unit_set us
    WHERE   u.id = ph_tst_cgn.getiduser AND us.id = U.ID_UNIT_SET 
;
  GRANT SELECT ON "VCGN_CURRENT_USER" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_CURRENT_USER" TO "TRANSFER_BI";
