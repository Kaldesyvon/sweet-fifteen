--------------------------------------------------------
--  DDL for View VCGN_CURNT_SETINGS
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_CURNT_SETINGS" ("ID_USER", "LOGIN", "ID_LANGUAGE", "ID_UNIT_SET") AS
  SELECT   u.id id_user,
            U.LOGIN,
            U.ID_LANGUAGE,
            U.ID_UNIT_SET
     FROM   gbc_user u
    WHERE   U.LOGIN = ph_tst_cgn.getuser 
;
  GRANT SELECT ON "VCGN_CURNT_SETINGS" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_CURNT_SETINGS" TO "TRANSFER_BI";
