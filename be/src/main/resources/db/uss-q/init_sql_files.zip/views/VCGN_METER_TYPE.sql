--------------------------------------------------------
--  DDL for View VCGN_METER_TYPE
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_METER_TYPE" ("ID", "NAME") AS
  SELECT   mT.ID, MT.NAME
     FROM   gbc_meter_type mt 
;
  GRANT SELECT ON "VCGN_METER_TYPE" TO "TRANSFER_BI";
  GRANT SELECT ON "VCGN_METER_TYPE" TO "CGN_PRX";
