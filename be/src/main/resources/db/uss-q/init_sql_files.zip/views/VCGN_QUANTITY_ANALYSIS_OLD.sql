--------------------------------------------------------
--  DDL for View VCGN_QUANTITY_ANALYSIS_OLD
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_QUANTITY_ANALYSIS_OLD" ("ID_QUANTITY", "ID_NODE", "ID_MATERIAL", "ID_MATERIAL_NODE", "ID_UNIT_SET", "QUANTITY", "UNIT_TO_ABBR", "DATE_FROM", "DATE_TO", "IO", "REMOTE_CODE", "MEMO", "NODE_REPORT_POS", "MATERIAL_REPORT_POS", "AUTO_ANALYSIS", "ID_ANALYSIS", "FACTOR_A", "FORMATED_FACTOR_A", "FACTOR_B", "FORMATED_FACTOR_B", "VALID_FROM", "VALID_TO", "ID_ANALYSIS_PARAM", "UNIT_ABBR_TO_ANALYSIS", "UNIT_NUMEN_ABBR_TO", "ID_SCOPE", "AP_ALLOWED") AS
  SELECT   q.ID ID_QUANTITY,
            q.ID_NODE,
            q.ID_MATERIAL,
            q.ID_MATERIAL_NODE,
            q.ID_UNIT_SET,
            q.QUANTITY,
            q.UNIT_TO_ABBR,
            q.DATE_FROM,
            q.DATE_TO,
            q.IO,
            q.REMOTE_CODE,
            q.MEMO,
            q.NODE_REPORT_POS,
            q.MATERIAL_REPORT_POS,
            q.AUTO_ANALYSIS,
            qa.ID_ANALYSIS,
            A.FACTOR_A,
            A.FORMATED_FACTOR_A,
            A.FACTOR_B,
            A.FORMATED_FACTOR_B,
            A.VALID_FROM,
            A.VALID_TO,
            A.ID_ANALYSIS_PARAM,
            A.UNIT_ABBR_TO UNIT_ABBR_TO_ANALYSIS,
            A.UNIT_NUMEN_ABBR_TO,
            SMN.ID_SCOPE ID_SCOPE,
            NVL (mna.id, 0) ap_allowed
     FROM               vcgn_quantity q
                     LEFT OUTER JOIN
                        GBC_SCOPE_MATERIAL_NODE smn
                     ON SMN.ID_MATERIAL_NODE = Q.ID_MATERIAL_NODE
                  LEFT OUTER JOIN
                     gbc_quantity_analysis qa
                  ON QA.ID_QUANTITY = Q.ID
               LEFT OUTER JOIN
                  vcgn_analysis a
               ON A.ID = QA.ID_ANALYSIS
            LEFT OUTER JOIN
               GBC_MATERIAL_NODE_AP mna
            ON MNA.ID_ANALYSIS_PARAM = A.ID_ANALYSIS_PARAM
               AND MNA.ID_MATERIAL_NODE = A.ID_MATERIAL_NODE
   UNION ALL
   SELECT   NULL ID_QUANTITY,
            a.ID_NODE,
            a.ID_MATERIAL,
            a.ID_MATERIAL_NODE,
            a.ID_UNIT_SET,
            NULL QUANTITY,
            NULL UNIT_TO_ABBR,
            NULL DATE_FROM,
            NULL DATE_TO,
            NULL IO,
            NULL REMOTE_CODE,
            NULL MEMO,
            NULL NODE_REPORT_POS,
            NULL MATERIAL_REPORT_POS,
            NULL AUTO_ANALYSIS,
            A.ID ID_ANALYSIS,
            A.FACTOR_A,
            A.FORMATED_FACTOR_A,
            A.FACTOR_B,
            A.FORMATED_FACTOR_B,
            A.VALID_FROM,
            A.VALID_TO,
            A.ID_ANALYSIS_PARAM,
            A.UNIT_ABBR_TO UNIT_ABBR_TO_ANALYSIS,
            A.UNIT_NUMEN_ABBR_TO,
            SMN.ID_SCOPE ID_SCOPE,
            NVL (mna.id, 0) ap_allowed
     FROM         vcgn_analysis a
               LEFT OUTER JOIN
                  GBC_SCOPE_MATERIAL_NODE smn
               ON SMN.ID_MATERIAL_NODE = A.ID_MATERIAL_NODE
            LEFT OUTER JOIN
               GBC_MATERIAL_NODE_AP mna
            ON MNA.ID_ANALYSIS_PARAM = A.ID_ANALYSIS_PARAM
               AND MNA.ID_MATERIAL_NODE = A.ID_MATERIAL_NODE
    WHERE   NOT EXISTS (SELECT   1
                          FROM   gbc_quantity_analysis qa
                         WHERE   QA.ID_ANALYSIS = a.id) 
;
  GRANT SELECT ON "VCGN_QUANTITY_ANALYSIS_OLD" TO "TRANSFER_BI";
