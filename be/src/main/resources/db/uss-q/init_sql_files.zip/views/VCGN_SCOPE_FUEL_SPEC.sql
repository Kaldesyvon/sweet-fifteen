--------------------------------------------------------
--  DDL for View VCGN_SCOPE_FUEL_SPEC
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_SCOPE_FUEL_SPEC" ("ID", "NAME") AS
  SELECT   sfs.id,
            NVL (NVL (dul.translation, de.translation), sfs.NAME_K) name
     FROM         GBC_SCOPE_FUEL_SPEC sfs
               LEFT OUTER JOIN
                  vcgn_dictionary_usr_lng dul
               ON dul.key = sfs.name_k
            LEFT OUTER JOIN
               vcgn_dictionary_en de
            ON de.key = sfs.name_k 
;
  GRANT SELECT ON "VCGN_SCOPE_FUEL_SPEC" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_SCOPE_FUEL_SPEC" TO "TRANSFER_BI";
