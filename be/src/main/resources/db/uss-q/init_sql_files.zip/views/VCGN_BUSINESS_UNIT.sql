--------------------------------------------------------
--  DDL for View VCGN_BUSINESS_UNIT
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_BUSINESS_UNIT" ("ID", "CODE", "NAME", "REPORT_POSITION") AS
  SELECT   bu.ID,
            BU.CODE,
            NVL (NVL (dul.translation, de.translation), bu.NAME_K) name,
            BU.REPORT_POSITION
     FROM         GBC_BUSINESS_UNIT bu
               LEFT OUTER JOIN
                  vcgn_dictionary_usr_lng dul
               ON dul.key = bu.name_k
            LEFT OUTER JOIN
               vcgn_dictionary_en de
            ON de.key = bu.name_k 
;
  GRANT SELECT ON "VCGN_BUSINESS_UNIT" TO "TRANSFER_BI";
  GRANT SELECT ON "VCGN_BUSINESS_UNIT" TO "CGN_PRX";
