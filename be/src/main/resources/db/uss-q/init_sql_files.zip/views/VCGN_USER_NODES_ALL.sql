--------------------------------------------------------
--  DDL for View VCGN_USER_NODES_ALL
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_USER_NODES_ALL" ("ID", "ID_NODE_LEVEL", "ID_NODE", "CODE", "NAME", "MEMO", "REPORT_POS", "GPS_POSITION", "VALID_FROM", "VALID_TO", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "OBJ_VERSION", "OBJ_DISCRIM", "QA_ENABLED", "LOCK_ENABLED", "ROLES_ENABLED", "EPA_CODE", "MAX_CAPACITY", "CAPACITY_UNIT", "TIER", "SUB_PART") AS
  SELECT   "ID",
                "ID_NODE_LEVEL",
                "ID_NODE",
                "CODE",
                name,
                "MEMO",
                "REPORT_POS",
                "GPS_POSITION",
                "VALID_FROM",
                "VALID_TO",
                "CREATED_BY",
                "CREATED",
                "MODIFIED_BY",
                "MODIFIED",
                "OBJ_VERSION",
                "OBJ_DISCRIM",
                "QA_ENABLED",
                "LOCK_ENABLED",
                "ROLES_ENABLED",
                "EPA_CODE",
                "MAX_CAPACITY",
                "CAPACITY_UNIT",
                "TIER",
                "SUB_PART"
         FROM   vcgn_node n
   CONNECT BY   PRIOR N.ID = N.ID_NODE
   START WITH   N.ID IN (    SELECT   id_node FROM vcgn_direct_node) 
;
  GRANT SELECT ON "VCGN_USER_NODES_ALL" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_USER_NODES_ALL" TO "TRANSFER_BI";
