--------------------------------------------------------
--  DDL for View VGBC_RESULTS_MONTH_ADV
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VGBC_RESULTS_MONTH_ADV" ("ID", "ID_UNIT_SET", "ID_NODE", "ID_MATERIAL", "ID_ANALYSIS_PARAM", "QUANTITY", "ID_UNIT", "UNIT_ABBR", "ANALYTICAL_VALUE_A", "ANALYTICAL_VALUE_B", "ANALYTICAL_VALUE", "ID_UNIT_NUMEN", "ID_UNIT_DENOM", "UNIT_ABBR_AV", "MONTH", "NO_OF_ROWS") AS
  SELECT      q.id_unit_set
              || q.id_node
              || q.id_material
              || TRUNC (date_from, 'MM')
              || a.id_analysis_param
                 id,                                       --iba rep hibernate
              q.id_unit_set id_unit_set,
              q.id_node id_node,
              q.id_material id_material,
              a.id_analysis_param id_analysis_param,
              SUM (q.quantity) quantity,
              q.id_unit_to id_unit,
              q.unit_to_abbr unit_abbr,
              SUM(DECODE (ut.compute,
                          0, NULL,
                          ( (a.factor_a) * q.quantity * q.IO)))
                 analytical_value_a,
              SUM(DECODE (ut.compute,
                          0, NULL,
                          ( (NVL (a.factor_b, 0)) * q.quantity * q.IO)))
                 analytical_value_b,
              SUM(DECODE (
                     ut.compute,
                     0,
                     NULL,
                     ( (a.factor_a + NVL (a.factor_b, 0)) * q.quantity * q.IO)
                  ))
                 analytical_value,
              a.id_unit_numen_to id_unit_numen,
              a.id_unit_denom_to id_unit_denom,
              a.unit_numen_abbr_to unit_abbr_av,
              TRUNC (date_from, 'MM') month,
              COUNT ( * ) no_of_rows
       FROM            vgbc_quantity q
                    LEFT OUTER JOIN
                       gbc_quantity_analysis qa
                    ON qa.ID_QUANTITY = q.ID
                 LEFT OUTER JOIN
                    vgbc_analysis a
                 ON     a.ID = qa.ID_ANALYSIS
                    AND a.id_unit_set = q.id_unit_set
                    AND qa.ID_ANALYSIS_PARAM = a.ID_ANALYSIS_PARAM
              LEFT OUTER JOIN
                 gbc_unit_type ut
              ON ut.id = a.id_unit_type_numen
   --where q.id_unit_set = 1 and s.id = 56 and id_analysis_param = 1
   GROUP BY q.id_unit_set
              || q.id_node
              || q.id_material
              || TRUNC (date_from, 'MM')
              || a.id_analysis_param, q.id_unit_set, q.id_node, q.id_material, a.id_analysis_param, q.id_unit_to, q.unit_to_abbr, a.id_unit_numen_to, a.id_unit_denom_to, a.unit_numen_abbr_to, TRUNC (date_from, 'MM')
;
  GRANT SELECT ON "VGBC_RESULTS_MONTH_ADV" TO "GBC_PRX";
  GRANT SELECT ON "VGBC_RESULTS_MONTH_ADV" TO "TRANSFER_BI";
