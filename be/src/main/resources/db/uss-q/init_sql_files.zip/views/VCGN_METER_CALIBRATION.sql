--------------------------------------------------------
--  DDL for View VCGN_METER_CALIBRATION
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_METER_CALIBRATION" ("ID", "ID_METER", "CALIBRATION_BY", "CALIBRATION_DATE", "CALIBRATION_DESCRIPTION", "CORRECTIVE_ACTIONS", "MEMO", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "OBJ_VERSION") AS
  SELECT   mc."ID",
            mc."ID_METER",
            mc."CALIBRATION_BY",
            mc."CALIBRATION_DATE",
            mc."CALIBRATION_DESCRIPTION",
            mc."CORRECTIVE_ACTIONS",
            mc."MEMO",
            mc."CREATED_BY",
            mc."CREATED",
            mc."MODIFIED_BY",
            mc."MODIFIED",
            mc."OBJ_VERSION"
     FROM   gbc_meter_calibration mc 
;
  GRANT SELECT ON "VCGN_METER_CALIBRATION" TO "TRANSFER_BI";
  GRANT SELECT ON "VCGN_METER_CALIBRATION" TO "CGN_PRX";
