--------------------------------------------------------
--  DDL for View VCGN_LANDFILL
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_LANDFILL" ("CAPACITY", "ID", "ID_UNIT", "UNIT_ABBR", "LANDFILL_COVER_DESCRIPTION", "LEACHATE_RECIRCULATION", "NAME", "NOTE_1", "NOTE_2", "NOTE_3", "OPENED_DATE", "PASSIVE_VENTS_FLARES", "PROJECTED_CLOSE_DATE", "STATUS") AS
  SELECT   LF.CAPACITY,
            LF.ID,
            LF.ID_UNIT,
            U.ABBR UNIT_ABBR,
            LF.LANDFILL_COVER_DESCRIPTION,
            LF.LEACHATE_RECIRCULATION,
            LF.NAME,
            LF.NOTE_1,
            LF.NOTE_2,
            LF.NOTE_3,
            LF.OPENED_DATE,
            LF.PASSIVE_VENTS_FLARES,
            LF.PROJECTED_CLOSE_DATE,
            LF.STATUS
     FROM      gbc_landfill lf
            INNER JOIN
               gbc_unit u
            ON u.id = LF.ID_UNIT 
;
  GRANT SELECT ON "VCGN_LANDFILL" TO "TRANSFER_BI";
  GRANT SELECT ON "VCGN_LANDFILL" TO "CGN_PRX";
