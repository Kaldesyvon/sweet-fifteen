--------------------------------------------------------
--  DDL for View VCGN_MATERIAL_NODE_TYPE
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_MATERIAL_NODE_TYPE" ("ID_MATERIAL_NODE", "ID_MATERIAL_TYPE", "MATERIAL_TYPE_NAME", "MEMO", "CODE") AS
  SELECT   MNT.ID_MATERIAL_NODE,
            mt.ID ID_MATERIAL_TYPE,
            NVL (NVL (dul.translation, de.translation), mt.NAME_K)
               MATERIAL_TYPE_name,
            mt.MEMO,
            MT.CODE
     FROM            gbc_material_node_type mnt
                  INNER JOIN
                     gbc_material_type mt
                  ON MT.ID = MNT.ID_MATERIAL_TYPE
               LEFT OUTER JOIN
                  vcgn_dictionary_usr_lng dul
               ON dul.key = mt.name_k
            LEFT OUTER JOIN
               vcgn_dictionary_en de
            ON de.key = mt.name_k 
;
  GRANT SELECT ON "VCGN_MATERIAL_NODE_TYPE" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_MATERIAL_NODE_TYPE" TO "TRANSFER_BI";
