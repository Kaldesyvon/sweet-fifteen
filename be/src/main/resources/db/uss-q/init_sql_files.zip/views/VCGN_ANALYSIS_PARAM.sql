--------------------------------------------------------
--  DDL for View VCGN_ANALYSIS_PARAM
------------------------- todo NOT MIGRATED - ERROR
---------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_ANALYSIS_PARAM" ("ID", "CODE", "NAME", "SYMBOL", "MASS", "CAS_NO", "ID_UNIT_TYPE", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "OBJ_VERSION", "ID_PARENT_ANALYSIS_PARAM", "PARENT_KOEF", "ID_TYPE", "ID_ANALYSIS_FORMAT", "ORDER", "MEMO", "ID_NIT", "UNIT_ABBR") AS
  SELECT   ap.ID,
            ap.CODE,
            NVL (NVL (dul.translation, de.translation), ap.NAME_K) name,
            ap.SYMBOL,
            ap.MASS,
            ap.CAS_NO,
            ap.ID_UNIT_TYPE,
            ap.CREATED_BY,
            ap.CREATED,
            ap.MODIFIED_BY,
            ap.MODIFIED,
            ap.OBJ_VERSION,
            ap.ID_PARENT_ANALYSIS_PARAM,
            ap.PARENT_KOEF,
            ap.ID_TYPE,
            ap.ID_ANALYSIS_FORMAT,
            ap."ORDER",
            ap.MEMO,
            u.id id_nit,
            U.ABBR unit_abbr
     FROM               gbc_analysis_param ap
                     LEFT OUTER JOIN
                        vcgn_dictionary_usr_lng dul
                     ON dul.key = ap.name_k
                  LEFT OUTER JOIN
                     vcgn_dictionary_en de
                  ON de.key = ap.name_k
               LEFT OUTER JOIN
                  GBC_UNIT_SET_SETTINGS_AP ussa
               ON USSA.ID_ANALYSIS_PARAM = ap.id
                  AND USSA.ID_UNIT_SET = ph_tst_cgn.getidunitset
            LEFT OUTER JOIN
               GBC_UNIT u
            ON U.ID = USSA.ID_UNIT 
;
  GRANT SELECT ON "VCGN_ANALYSIS_PARAM" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_ANALYSIS_PARAM" TO "TRANSFER_BI";
