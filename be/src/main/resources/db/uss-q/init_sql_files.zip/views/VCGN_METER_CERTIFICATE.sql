--------------------------------------------------------
--  DDL for View VCGN_METER_CERTIFICATE
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_METER_CERTIFICATE" ("ID", "ID_METER", "MEMO", "NAME", "VALID_FROM", "VALID_TO") AS
  SELECT   MCE.ID,
            MCE.ID_METER,
            MCE.MEMO,
            MCE.NAME,
            MCE.VALID_FROM,
            MCE.VALID_TO
     FROM   gbc_meter_certificate mce 
;
  GRANT SELECT ON "VCGN_METER_CERTIFICATE" TO "TRANSFER_BI";
  GRANT SELECT ON "VCGN_METER_CERTIFICATE" TO "CGN_PRX";
