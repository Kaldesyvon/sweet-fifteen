--------------------------------------------------------
--  DDL for View VGBC_QUANTITY_MONTH
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VGBC_QUANTITY_MONTH" ("ID", "ID_UNIT_SET", "ID_NODE", "ID_MATERIAL", "ID_MATERIAL_NODE", "MONTH", "MONTH_QUANTITY", "ID_UNIT", "UNIT_ABBR", "IO", "NO_OF_ROWS") AS
  SELECT id_unit_set
  || id_node
  || id_material
  || TRUNC (date_from, 'MM') 
  || io id, --iba rep hibernate
  id_unit_set,
  id_node,
  id_material,
  id_material_node,
  TRUNC (date_from, 'MM') MONTH,
  SUM (quantity) month_quantity,
  id_unit_to id_unit,
  unit_to_abbr unit_abbr,
  qv.io io,
  COUNT ( * ) no_of_rows
FROM VGBC_QUANTITY qv
group by id_unit_set
  || id_node
  || id_material
  || TRUNC (date_from, 'MM') 
  || io, id_unit_set, id_node, id_material, id_material_node, TRUNC (date_from, 'MM'), id_unit_to, unit_to_abbr, qv.io
;
  GRANT SELECT ON "VGBC_QUANTITY_MONTH" TO "GBC_PRX";
  GRANT SELECT ON "VGBC_QUANTITY_MONTH" TO "TRANSFER_BI";
