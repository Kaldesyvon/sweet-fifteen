--------------------------------------------------------
--  DDL for View VGBC_PRODUCTION_PLAN
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VGBC_PRODUCTION_PLAN" ("ID", "ID_NODE", "ID_MATERIAL", "ID_MATERIAL_NODE", "MONTH", "ID_UNIT_SET", "ID_UNIT_FROM", "ID_UNIT_TO", "QUANTITY", "UNIT_TO_ABBR", "MEMO", "CREATED", "CREATED_BY", "MODIFIED", "MODIFIED_BY", "OBJ_VERSION") AS
  SELECT   pp.id id,
            mp.id_node id_node,
            m.id id_material,
            mp.id id_material_node,
            pp.month month,
            us.id id_unit_set,
            unit_from.id id_unit_from,
            unit_to.id id_unit_to,
            (  unit_to.k / unit_from.k * pp.quantity
             + unit_to.q
             - unit_from.q * (unit_to.k / unit_from.k))
               quantity,
            unit_to.abbr unit_to_abbr,
            pp.memo memo,
            pp.created created,
            pp.created_by created_by,
            pp.modified modified,
            pp.modified_by modified_by,
            pp.obj_version obj_version
     FROM                        gbc_production_plan pp
                              CROSS JOIN
                                 gbc_unit_set us
                           INNER JOIN
                              gbc_unit unit_from
                           ON unit_from.id = pp.id_unit
                     LEFT OUTER JOIN
                        gbc_material_node mp
                     ON mp.id = pp.id_material_node
                    LEFT OUTER JOIN
                      gbc_material m
                    ON m.id = mp.id_material
                  LEFT OUTER JOIN
                     gbc_material m2
                  ON m2.id = mp.id_material
               LEFT OUTER JOIN
                  GBC_UNIT_SET_SETTINGS uss_to
               ON uss_to.id_unit_set = us.id
                  AND (uss_to.id_material = NVL (m.id, m2.id))
            LEFT OUTER JOIN
               gbc_unit unit_to
            ON unit_to.id = uss_to.id_unit
;
  GRANT SELECT ON "VGBC_PRODUCTION_PLAN" TO "GBC_PRX";
  GRANT SELECT ON "VGBC_PRODUCTION_PLAN" TO "TRANSFER_BI";
