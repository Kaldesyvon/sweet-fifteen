--------------------------------------------------------
--  DDL for View VCGN_STATE_POST_CODE
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_STATE_POST_CODE" ("ID", "POSTAL_CODE", "STATE", "COUNTRY_NAME") AS
  select "ID","POSTAL_CODE","STATE","COUNTRY_NAME" from GBC_STATE_POST_CODE
;
  GRANT SELECT ON "VCGN_STATE_POST_CODE" TO "TRANSFER_BI";
  GRANT SELECT ON "VCGN_STATE_POST_CODE" TO "CGN_PRX";
