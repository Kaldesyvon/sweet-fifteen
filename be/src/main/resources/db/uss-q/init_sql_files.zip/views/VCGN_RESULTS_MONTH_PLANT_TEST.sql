--------------------------------------------------------
--  DDL for View VCGN_RESULTS_MONTH_PLANT_TEST
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_RESULTS_MONTH_PLANT_TEST" ("ID_NODE_PLANT", "ID_NODE", "ID_MATERIAL", "ID_MATERIAL_NODE", "ID_ANALYSIS_PARAM", "ID_SCOPE", "QUANTITY", "ID_UNIT", "UNIT_ABBR", "ANALYTICAL_VALUE", "ID_UNIT_NUMEN", "ID_UNIT_DENOM", "UNIT_ABBR_AV", "MONTH", "IO") AS
  (  SELECT   nwp.id_node_plant id_node_plant,
               q.id_node,
               q.id_material id_material,
               smn.id_material_node id_material_node,
               a.id_analysis_param id_analysis_param,
               smn.id_scope id_scope,
               SUM (q.quantity) quantity,
               q.id_unit_to id_unit,
               q.unit_to_abbr unit_abbr,
               SUM(DECODE (
                      ut.compute,
                      0,
                      NULL,
                      ( (a.factor_a * smn.FACTOR_A
                         + NVL (a.factor_b, 0) * NVL (smn.FACTOR_B, 0))
                       * q.quantity
                       * q.IO)
                   ))
                  analytical_value,
               a.id_unit_numen_to id_unit_numen,
               a.id_unit_denom_to id_unit_denom,
               a.unit_numen_abbr_to unit_abbr_av,
               TRUNC (date_from, 'MM') MONTH,
               q.io
        FROM                  vcgn_quantity q
                           INNER JOIN
                              vcgn_node_with_plant nwp
                           ON nwp.id_node = q.id_node
                        LEFT OUTER JOIN
                           gbc_scope_material_node smn
                        ON smn.id_material_node = q.id_material_node
                     LEFT OUTER JOIN
                        gbc_quantity_analysis qa
                     ON qa.ID_QUANTITY = q.ID
                  LEFT OUTER JOIN
                     vcgn_analysis a
                  ON     a.ID = qa.ID_ANALYSIS
                     AND a.id_unit_set = q.id_unit_set
                     AND qa.ID_ANALYSIS_PARAM = a.ID_ANALYSIS_PARAM
               LEFT OUTER JOIN
                  gbc_unit_type ut
               ON ut.id = a.id_unit_type_numen
    GROUP BY   nwp.id_node_plant,
               q.id_node,
               q.id_material,
               smn.id_material_node,
               a.id_analysis_param,
               smn.id_scope,
               q.id_unit_to,
               q.unit_to_abbr,
               a.id_unit_numen_to,
               a.id_unit_denom_to,
               a.unit_numen_abbr_to,
               TRUNC (date_from, 'MM'),
               q.io) 
;
  GRANT SELECT ON "VCGN_RESULTS_MONTH_PLANT_TEST" TO "TRANSFER_BI";
