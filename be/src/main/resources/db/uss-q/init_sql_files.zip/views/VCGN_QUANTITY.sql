--------------------------------------------------------
--  DDL for View VCGN_QUANTITY
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_QUANTITY" ("ID", "ID_NODE", "ID_MATERIAL", "ID_MATERIAL_NODE", "TIER", "ID_UNIT_SET", "ID_UNIT_FROM", "ID_UNIT_TO", "ID_UNIT_SET_SETTINGS", "QUANTITY", "UNIT_TO_ABBR", "DATE_FROM", "MONTH_FROM", "ID_MONTH", "ID_YEAR", "DATE_TO", "IO", "REMOTE_CODE", "MEMO", "QUANTITY_FROM", "CREATED", "CREATED_BY", "MODIFIED", "MODIFIED_BY", "EDITABLE", "AUTO_ANALYSIS", "NODE_REPORT_POS", "MATERIAL_REPORT_POS", "NUMBER_OF_MEASUREMENTS", "UNCERTAINTY", "ID_METER") AS
  SELECT   q.id id,
            p.id id_node,
            m.id id_material,
            mp.id id_material_node,
            /*            MP.TIER1,
                        MP.TIER2,
                        MP.TIER3,*/
            MP.TIER,
            us.id id_unit_set,
            unit_from.id id_unit_from,
            unit_to.id id_unit_to,
            uss_to.id id_unit_set_settings,
            (  unit_to.k / unit_from.k * q.quantity
             + unit_to.q
             - unit_from.q * (unit_to.k / unit_from.k))
               quantity,
            unit_to.abbr unit_to_abbr,
            q.date_from date_from,
            TRUNC (q.date_from, 'fmmm') month_from,
            EXTRACT (MONTH FROM q.date_from) id_month,
            EXTRACT (YEAR FROM q.date_from) id_year,
            q.date_to date_to,
            q.io io,
            q.remote_code remote_code,
            q.memo memo,
            q.quantity quantity_from,                             --nepotrebne
            --            m.name material_name,
            --            p.name_k plant_name,
            q.created created,
            q.created_by created_by,
            q.modified modified,
            q.modified_by modified_by,
            q.editable editable,
            q.auto_analysis auto_analysis,
            p.report_pos NODE_REPORT_POS,
            m.report_pos MATERIAL_REPORT_POS,
            --            q.id_eliminated id_eliminated,
            --            q.HAS_ELIMINATIONS has_eliminations,
            --            Q.ID_MEASURE_POINT,
            Q.NUMBER_OF_MEASUREMENTS,
            Q.UNCERTAINTY,
            --            MT.NAME MEASURE_POINT_NAME
            Q.ID_METER
     FROM                           gbc_quantity q
                                 INNER JOIN
                                    gbc_material_node mp
                                 ON mp.ID = q.ID_MATERIAL_NODE
                              INNER JOIN
                                 gbc_material m
                              ON m.id = mp.id_material
                           INNER JOIN
                              gbc_node p
                           ON p.id = mp.id_node
                        INNER JOIN
                           VCGN_USER_NODES_ALL una
                        ON una.id = p.id
                     INNER JOIN
                        gbc_unit unit_from
                     ON unit_from.id = q.id_unit
                  CROSS JOIN
                     gbc_unit_set us
               LEFT OUTER JOIN
                  GBC_UNIT_SET_SETTINGS uss_to
               ON uss_to.id_unit_set = us.id AND uss_to.id_material = m.id
            LEFT OUTER JOIN
               gbc_unit unit_to
            ON unit_to.id = uss_to.id_unit
    /*          left outer join
                gbc_measure_point mt
              on MT.ID=Q.ID_MEASURE_POINT  */
    WHERE   us.id = ph_tst_cgn.getidunitset 
;
  GRANT SELECT ON "VCGN_QUANTITY" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_QUANTITY" TO "TRANSFER_BI";
