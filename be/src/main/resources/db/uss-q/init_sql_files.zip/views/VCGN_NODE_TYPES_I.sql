--------------------------------------------------------
--  DDL for View VCGN_NODE_TYPES_I
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_NODE_TYPES_I" ("ID_NODE", "ID_NODE_LEVEL", "NODE_NAME", "NODE_REPORT_POS", "NODE_TYPE_REPORT_POS", "ID_NODE_TYPE", "NODE_TYPE_NAME", "ID_MATERIAL_REPORT") AS
  SELECT   NTS.ID_NODE,
            una.ID_NODE_LEVEL,
            una.NAME node_name,
            una.report_pos node_report_pos,
            nt.report_pos node_type_report_pos,
            NTS.ID_NODE_TYPE,
            nt.name node_type_name,
            nt.ID_MATERIAL_REPORT
     FROM         gbc_node_types nts
               INNER JOIN
                  vcgn_node_type nt
               ON nt.id = NTS.ID_NODE_TYPE
            INNER JOIN
               VCGN_USER_NODES_ALL una
            ON una.id = NTS.ID_NODE 
;
  GRANT SELECT ON "VCGN_NODE_TYPES_I" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_NODE_TYPES_I" TO "TRANSFER_BI";
