--------------------------------------------------------
--  DDL for View VCGN_PERIOD
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_PERIOD" ("MONTH_DATE", "ID_MONTH", "MONTH", "ID_YEAR") AS
  SELECT   d_date AS month_date,
            EXTRACT (MONTH FROM d_date) AS id_month,
            TO_CHAR (d_date,
                     'Month',
                     'NLS_DATE_LANGUAGE = ' || ph_tst_cgn.getnlslang)
               AS month,
            EXTRACT (YEAR FROM d_date) AS id_year
     FROM   (    SELECT   ADD_MONTHS (TO_DATE ('20040101', 'YYYYMMDD'),
                                      LEVEL - 1)
                             AS d_date
                   FROM   DUAL
             CONNECT BY   LEVEL <=
                             (EXTRACT (YEAR FROM SYSDATE) - 2004 + 2) * 12) 
;
  GRANT SELECT ON "VCGN_PERIOD" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_PERIOD" TO "TRANSFER_BI";
