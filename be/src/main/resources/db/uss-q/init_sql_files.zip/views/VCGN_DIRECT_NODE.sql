--------------------------------------------------------
--  DDL for View VCGN_DIRECT_NODE
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_DIRECT_NODE" ("LOGIN", "ID_NODE", "NAME_K") AS
  SELECT   cs.login, A.ID_NODE, N.NAME_K
     FROM   GBC_AUTHORIZATION a, vcgn_curnt_setings cs, gbc_node n
    WHERE       A.ID_USER = cs.id_user
            AND n.id = A.ID_NODE
            AND A.ID_ROLE = 5
            AND a.id_node IS NOT NULL
   UNION
   SELECT   cs.login, n.id, N.NAME_K
     FROM   GBC_AUTHORIZATION a, vcgn_curnt_setings cs, gbc_node n
    WHERE       A.ID_USER = cs.id_user
            AND n.id_node IS NULL
            AND A.ID_ROLE = 5
            AND a.id_node IS NULL 
;
  GRANT SELECT ON "VCGN_DIRECT_NODE" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_DIRECT_NODE" TO "TRANSFER_BI";
