--------------------------------------------------------
--  DDL for View VGBC_ACCES_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VGBC_ACCES_AUDIT" ("IS_CODE", "IS_NAME", "ACC_CODE", "ACC_NAME", "ACC_NAME_AN", "ACC_DESCR", "ACC_DESCR_AN", "PERSON_NAME", "LOGIN", "GRANY_CREATED", "GRANT_MODIFIED") AS
  select 'GBCO2'is_code, 'GBCO2' is_name,
        GR.CODE acc_code, 
        (select GDS.TRANSLATION
            from gbc_dictionary gds
           where GDS.ID_LANGUAGE = 2
                and GDS.KEY = GR.NAME_K) acc_name,
        (select GDS.TRANSLATION
            from gbc_dictionary gds
           where GDS.ID_LANGUAGE = 1
                and GDS.KEY = GR.NAME_K) acc_name_an,
        (select GDS.TRANSLATION
            from gbc_dictionary gds
           where GDS.ID_LANGUAGE = 2
                and GDS.KEY = GR.MEMO_K) acc_descr,
        (select GDS.TRANSLATION
            from gbc_dictionary gds
           where GDS.ID_LANGUAGE = 1
                and GDS.KEY = GR.MEMO_K) acc_descr_an,
        GU.NAME||' '||GU.SURNAME person_name, GU.LOGIN, 
        GA.CREATED grany_created, GA.MODIFIED grant_modified 
  from gbc_user gu, gbc_authorization ga, gbc_role gr
 where GU.ENABLED = 1
    and GA.ID_USER = GU.ID 
    and GR.ID = GA.ID_ROLE
;
  GRANT SELECT ON "VGBC_ACCES_AUDIT" TO "TRANSFER_BI";
  GRANT SELECT ON "VGBC_ACCES_AUDIT" TO "PRENOS_KOMUNIKACIE";
