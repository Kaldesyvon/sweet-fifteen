--------------------------------------------------------
--  DDL for View VGBC_RESULTS_MONTH_CGN
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VGBC_RESULTS_MONTH_CGN" ("ID", "ID_UNIT_SET", "ID_NODE", "ID_MATERIAL", "ID_ANALYSIS_PARAM", "ID_SCOPE", "QUANTITY", "ID_UNIT", "UNIT_ABBR", "ANALYTICAL_VALUE", "ID_UNIT_NUMEN", "ID_UNIT_DENOM", "UNIT_ABBR_AV", "MONTH", "NO_OF_ROWS", "NODE_REPORT_POS", "ANALYSIS_PARAM_NAME_K", "MATERIAL_NAME", "NODE_NAME_K", "SCOPE_NAME_K", "NODE_TYPE_NAME_K", "ID_MATERIAL_REPORT", "REGION_NAME_K", "IO") AS
  SELECT   rm.ID,
            rm.ID_UNIT_SET,
            rm.ID_NODE,
            rm.ID_MATERIAL,
            rm.ID_ANALYSIS_PARAM,
            rm.ID_SCOPE,
            rm.QUANTITY,
            rm.ID_UNIT,
            rm.UNIT_ABBR,
            rm.ANALYTICAL_VALUE,
            rm.ID_UNIT_NUMEN,
            rm.ID_UNIT_DENOM,
            rm.UNIT_ABBR_AV,
            rm.MONTH,
            rm.NO_OF_ROWS,
            rm.NODE_REPORT_POS,
            rm.ANALYSIS_PARAM_NAME_K,
            rm.MATERIAL_NAME,
            rm.NODE_NAME_K,
            rm.SCOPE_NAME_K,
            NT.NAME_K node_type_name_k,
            NT.ID_MATERIAL_REPORT,
            R.NAME_K region_name_k,
            rm.io
     FROM                  VGBC_RESULTS_MONTH rm
                        LEFT OUTER JOIN
                           gbc_node_types nts
                        ON NTS.ID_NODE = RM.ID_NODE
                     LEFT OUTER JOIN
                        gbc_node_type nt
                     ON NT.ID = NTS.ID_NODE_TYPE
                  LEFT OUTER JOIN
                     gbc_node_plant np
                  ON NP.ID = RM.ID_NODE
               LEFT OUTER JOIN
                  gbc_country c
               ON C.ID = NP.ID_COUNTRY
            LEFT OUTER JOIN
               gbc_region r
            ON R.ID = C.ID_REGION 
;
  GRANT SELECT ON "VGBC_RESULTS_MONTH_CGN" TO "CGN_PRX";
  GRANT SELECT ON "VGBC_RESULTS_MONTH_CGN" TO "GBC_PRX";
  GRANT SELECT ON "VGBC_RESULTS_MONTH_CGN" TO "TRANSFER_BI";
