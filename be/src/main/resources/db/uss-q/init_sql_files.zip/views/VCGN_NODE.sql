--------------------------------------------------------
--  DDL for View VCGN_NODE
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_NODE" ("ID", "ID_NODE_LEVEL", "ID_NODE", "CODE", "NAME", "MEMO", "REPORT_POS", "GPS_POSITION", "VALID_FROM", "VALID_TO", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "OBJ_VERSION", "OBJ_DISCRIM", "QA_ENABLED", "LOCK_ENABLED", "ROLES_ENABLED", "EPA_CODE", "MAX_CAPACITY", "CAPACITY_UNIT", "TIER", "SUB_PART", "ID_COUNTRY", "CITY", "STATE_PROVINCE", "USEPA_TRI_FACILITY_ID", "USEPA_RCRA_FACILITY_ID", "ID_PR_NAICS_CODE", "PR_NAICS_CODE", "PR_NAICS_CODE_DESC", "ID_SE_NAICS_CODE", "SE_NAICS_CODE", "SE_NAICS_CODE_DESC", "DUN_BRADSTREET_NUMBER", "THERMAL_CAPACITY_OPERATOR", "USEPA_THERMAL_CAP_TIER", "USEPA_CU_TYPE_COD", "TIME_ZONE", "ADDRESS_LINE_1", "ADDRESS_LINE_2", "ADDRESS_LINE_3", "ID_STATE_PROVINCE_POST_CODE", "ID_BUSINESS_UNIT", "BUSINESS_UNIT_CODE", "BUSINESS_UNIT_NAME", "BUSINESS_UNIT_REPORT_POSITION", "NOTE1", "NOTE2", "NOTE3", "POSTAL_CODE", "ID_LANDFILL", "GPS_ELEVATION", "GPS_ELEVATION_UNITS", "GPS_LATITUDE", "GPS_LONGITUDE", "NODE_REPORT_POSITION", "PROCESS_POSITION", "SINGLE_COMBUSTION_UNIT") AS
  SELECT n.ID,
          n.ID_NODE_LEVEL,
          n.ID_NODE,
          n.CODE,
          NVL (NVL (dul.translation, de.translation), n.NAME_K) name,
          n.MEMO,
          n.REPORT_POS,
          n.GPS_POSITION,
          n.VALID_FROM,
          n.VALID_TO,
          n.CREATED_BY,
          n.CREATED,
          n.MODIFIED_BY,
          n.MODIFIED,
          n.OBJ_VERSION,
          n.OBJ_DISCRIM,
          n.QA_ENABLED,
          n.LOCK_ENABLED,
          n.ROLES_ENABLED,
          n.EPA_CODE,
          n.MAX_CAPACITY,
          n.CAPACITY_UNIT,
          n.TIER,
          n.SUPPORT SUB_PART,
          n.ID_COUNTRY,
          n.CITY,
          n.STATE_PROVINCE,
          n.USEPA_TRI_FACILITY_ID,
          n.USEPA_RCRA_FACILITY_ID,
          N.ID_PR_NAICS_CODE,
          NCP.CODE PR_NAICS_CODE,
          NCP.DESCRIPTION PR_NAICS_CODE_DESC,
          N.ID_SE_NAICS_CODE,
          NCS.CODE SE_NAICS_CODE,
          NCS.DESCRIPTION SE_NAICS_CODE_DESC,
          n.DUN_BRADSTREET_NUMBER,
          n.THERMAL_CAPACITY_OPERATOR,
          n.USEPA_THERMAL_CAP_TIER,
          n.USEPA_CU_TYPE_COD,
          n.TIME_ZONE,
          n.ADDRESS_LINE_1,
          n.ADDRESS_LINE_2,
          n.ADDRESS_LINE_3,
          n.ID_STATE_PROVINCE_POST_CODE,
          n.ID_BUSINESS_UNIT,
          bu.CODE BUSINESS_UNIT_CODE,
          bu.NAME BUSINESS_UNIT_NAME,
          BU.REPORT_POSITION BUSINESS_UNIT_REPORT_POSITION,
          n.NOTE1,
          n.NOTE2,
          n.NOTE3,
          /*            n.COMMON_PIPE_PARENT,
                      n.COMMON_PIPE_ID,*/
          n.POSTAL_CODE,
          N.ID_LANDFILL,
          N.GPS_ELEVATION,
          N.GPS_ELEVATION_UNITS,
          N.GPS_LATITUDE,
          N.GPS_LONGITUDE,
          N.REPORT_POS NODE_REPORT_POSITION,
          N.PROCESS_POSITION,
          N.SINGLE_COMBUSTION_UNIT
     FROM gbc_node n
          LEFT OUTER JOIN VCGN_BUSINESS_UNIT bu
             ON bu.id = n.ID_BUSINESS_UNIT
          LEFT OUTER JOIN vcgn_dictionary_usr_lng dul
             ON dul.key = n.name_k
          LEFT OUTER JOIN vcgn_dictionary_en de
             ON de.key = n.name_k
          LEFT OUTER JOIN GBC_NAICS_CODES ncp
             ON NCP.ID = N.ID_PR_NAICS_CODE
          LEFT OUTER JOIN GBC_NAICS_CODES ncs
             ON NCs.ID = N.ID_SE_NAICS_CODE
;
  GRANT SELECT ON "VCGN_NODE" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_NODE" TO "TRANSFER_BI";
