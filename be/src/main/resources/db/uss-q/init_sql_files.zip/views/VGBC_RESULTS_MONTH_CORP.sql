--------------------------------------------------------
--  DDL for View VGBC_RESULTS_MONTH_CORP
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VGBC_RESULTS_MONTH_CORP" ("ID", "MONTH", "ID_SCOPE", "ID_NODE", "CARBON_SUM", "CARBON_INPUT", "CARBON_OUTPUT", "CARBON_UNIT", "PRODUCTED_STEEL", "ENERGY_SUM", "ENERGY_INPUT", "ENERGY_OUTPUT", "ENERGY_UNIT", "ID_UNIT_SET") AS
  SELECT  c.id_unit_set || TRUNC (c.month, 'MM') id,
        c.month,
        c.id_scope,
        c.id_node,
        sum(c.carbon_Sum),
        sum(c.carbon_Input),
        sum(c.carbon_Output),
        c.carbon_Unit,
        sum(c.producted_steel),
        sum(e.energy_Sum),
        sum(e.energy_Input),
        sum(e.energy_Output),
        e.energy_Unit,
        c.id_unit_set
   FROM
       (SELECT vrm.month,
               SUM(vrm.ANALYTICAL_VALUE) AS Carbon_Sum,  
               SUM(CASE WHEN vrm.IO = 1 THEN vrm.ANALYTICAL_VALUE else .00 END) AS Carbon_Input,
               SUM(CASE WHEN vrm.IO = -1 AND vrm.ID_ANALYSIS_PARAM = 4 THEN vrm.ANALYTICAL_VALUE ELSE .00 END ) * -1 AS Carbon_Output,     
               SUM(CASE WHEN vrm.ID_MATERIAL = 62 THEN vrm.quantity ELSE .00 END) AS producted_steel, 
               vrm.UNIT_ABBR_AV AS Carbon_Unit,
               vrm.id_unit_set,
               vrm.ID_SCOPE,
               vrm.ID_NODE
          FROM VGBC_RESULTS_MONTH vrm
         WHERE vrm.ID_ANALYSIS_PARAM = 4
         GROUP BY vrm.MONTH, vrm.UNIT_ABBR_AV, vrm.id_unit_set, vrm.ID_SCOPE, vrm.ID_NODE
        ) c
        LEFT OUTER JOIN
        ( SELECT vrm.month,
                 SUM(vrm.ANALYTICAL_VALUE) AS Energy_Sum,
                 SUM(CASE WHEN vrm.IO = 1 THEN vrm.ANALYTICAL_VALUE ELSE .00 END ) AS Energy_Input,
                 SUM(CASE WHEN vrm.IO = -1 THEN vrm.ANALYTICAL_VALUE ELSE .00 END ) * -1 AS Energy_Output,
                 vrm.UNIT_ABBR_AV AS Energy_Unit,
                 vrm.id_unit_set,
                 vrm.ID_SCOPE,
                 vrm.ID_NODE
            FROM VGBC_RESULTS_MONTH vrm
           WHERE vrm.ID_ANALYSIS_PARAM = 2
           GROUP BY vrm.MONTH, vrm.UNIT_ABBR_AV, vrm.id_unit_set, vrm.ID_SCOPE, vrm.ID_NODE
        ) e
        ON (e.month = c.month AND e.id_unit_set = c.id_unit_set AND e.id_scope = c.id_scope AND e.id_node = c.id_node)
  GROUP BY c.id_unit_set || TRUNC (c.month, 'MM'),
        c.month,
        c.id_scope,
        c.id_node,
        c.carbon_Unit,
        e.energy_Unit,
        c.id_unit_set
;
  GRANT SELECT ON "VGBC_RESULTS_MONTH_CORP" TO "TRANSFER_BI";
  GRANT SELECT ON "VGBC_RESULTS_MONTH_CORP" TO "GBC_PRX";
