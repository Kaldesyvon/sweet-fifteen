--------------------------------------------------------
--  DDL for View VCGN_INT_SUMM_PLANTS
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_INT_SUMM_PLANTS" ("MONTH", "YEAR", "ID_NODE", "ID_MATERIAL") AS
  (SELECT   period.MONTH,
             period.YEAR,
             nd.id AS id_node,
             mat.id_material
      FROM         gbc_node nd
                CROSS JOIN
                   (SELECT   62 AS id_material FROM DUAL
                    UNION
                    SELECT   64 FROM DUAL
                    UNION
                    SELECT   65 FROM DUAL) mat
             CROSS JOIN
                (SELECT   month_date AS MONTH, id_year AS year
                   FROM   vcgn_period) period) 
;
  GRANT SELECT ON "VCGN_INT_SUMM_PLANTS" TO "TRANSFER_BI";
