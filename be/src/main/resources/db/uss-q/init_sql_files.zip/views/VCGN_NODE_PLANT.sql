--------------------------------------------------------
--  DDL for View VCGN_NODE_PLANT
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_NODE_PLANT" ("ID", "ID_COUNTRY", "TIME_ZONE", "ADDRESS_LINE_1", "ADDRESS_LINE_2", "ADDRESS_LINE_3", "POSTAL_CODE", "ID_BUSINESS_UNIT", "ID_REGION", "COUNTRY_NAME", "REGION_NAME") AS
  SELECT   np.ID,
            np.ID_COUNTRY,
            np.TIME_ZONE,
            np.ADDRESS_LINE_1,
            np.ADDRESS_LINE_2,
            np.ADDRESS_LINE_3,
            np.POSTAL_CODE,
            np.ID_BUSINESS_UNIT,
            c.id_region,
            c.name country_name,
            r.name region_name
     FROM         gbc_node_plant np
               LEFT OUTER JOIN
                  vcgn_country c
               ON c.id = NP.ID_COUNTRY
            LEFT OUTER JOIN
               vcgn_region r
            ON r.id = c.id_region 
;
  GRANT SELECT ON "VCGN_NODE_PLANT" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_NODE_PLANT" TO "TRANSFER_BI";
