--------------------------------------------------------
--  DDL for View VCGN_UNIT_TYPE
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_UNIT_TYPE" ("ID", "NAME", "MEMO", "ANALYSIS", "COMPUTE", "QUANTITY") AS
  SELECT   UT.ID,
            NVL (NVL (dul.translation, de.translation), ut.NAME_K) name,
            NVL (NVL (dulm.translation, dem.translation), ut.memo_k) memo,
            UT.ANALYSIS,
            UT.COMPUTE,
            UT.QUANTITY
     FROM               gbc_unit_type ut
                     LEFT OUTER JOIN
                        vcgn_dictionary_usr_lng dul
                     ON dul.key = ut.name_k
                  LEFT OUTER JOIN
                     vcgn_dictionary_en de
                  ON de.key = ut.name_k
               LEFT OUTER JOIN
                  vcgn_dictionary_usr_lng dulm
               ON dulm.key = ut.memo_k
            LEFT OUTER JOIN
               vcgn_dictionary_en dem
            ON dem.key = ut.memo_k 
;
  GRANT SELECT ON "VCGN_UNIT_TYPE" TO "TRANSFER_BI";
  GRANT SELECT ON "VCGN_UNIT_TYPE" TO "CGN_PRX";
