--------------------------------------------------------
--  DDL for View VCGN_UNIT
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_UNIT" ("ID", "ID_UNIT_TYPE", "CODE", "ABBR", "NAME", "K", "Q", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "OBJ_VERSION") AS
  SELECT   u.ID,
            u.ID_UNIT_TYPE,
            u.CODE,
            u.ABBR,
            NVL (NVL (dul.translation, de.translation), u.NAME_K) name,
            u.K,
            u.Q,
            u.CREATED_BY,
            u.CREATED,
            u.MODIFIED_BY,
            u.MODIFIED,
            u.OBJ_VERSION
     FROM         gbc_unit u
               LEFT OUTER JOIN
                  vcgn_dictionary_usr_lng dul
               ON dul.key = u.name_k
            LEFT OUTER JOIN
               vcgn_dictionary_en de
            ON de.key = u.name_k 
;
  GRANT SELECT ON "VCGN_UNIT" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_UNIT" TO "TRANSFER_BI";
