--------------------------------------------------------
--  DDL for View VCGN_NODE_TYPES
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_NODE_TYPES" ("ID_NODE", "ID_NODE_LEVEL", "NODE_NAME", "NODE_REPORT_POS", "NODE_TYPE_REPORT_POS", "ID_NODE_TYPE", "NODE_TYPE_NAME", "ID_MATERIAL_REPORT", "ID_COUNTRY", "COUNTRY_NAME", "ID_REGION", "REGION_NAME", "CHECK_DATE", "LOCK_DATE") AS
  SELECT   NTS.ID_NODE,
            una.ID_NODE_LEVEL,
            una.NAME node_name,
            una.report_pos node_report_pos,
            nt.report_pos node_type_report_pos,
            NTS.ID_NODE_TYPE,
            nt.name node_type_name,
            nt.ID_MATERIAL_REPORT,
            np.id_country,
            np.country_name,
            np.id_region,
            np.region_name,
            ND.CHECK_DATE,
            ND.LOCK_DATE
     FROM               gbc_node_types nts
                     INNER JOIN
                        vcgn_node_type nt
                     ON nt.id = NTS.ID_NODE_TYPE
                  INNER JOIN
                     VCGN_USER_NODES_ALL una
                  ON una.id = NTS.ID_NODE
               LEFT OUTER JOIN
                  GBC_NODE_DATALOCK nd
               ON ND.ID = NTS.ID_NODE
            LEFT OUTER JOIN
               vcgn_node_plant np
            ON np.id = NTS.ID_NODE 
;
  GRANT SELECT ON "VCGN_NODE_TYPES" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_NODE_TYPES" TO "TRANSFER_BI";
