--------------------------------------------------------
--  DDL for View VCGN_NODE_WITH_PLANT
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_NODE_WITH_PLANT" ("ID_NODE_PLANT", "ID_NODE") AS
  SELECT   (    SELECT   pn.id
                   FROM   gbc_node pn
                  WHERE   pn.id_node_level = 3
             CONNECT BY   PRIOR pn.id_node = pN.ID
             START WITH   pN.ID = n.id)
               id_node_plant, n.id id_node
     FROM   gbc_node n 
;
  GRANT SELECT ON "VCGN_NODE_WITH_PLANT" TO "TRANSFER_BI";
