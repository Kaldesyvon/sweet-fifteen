--------------------------------------------------------
--  DDL for View VGBC_ADV_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VGBC_ADV_DETAILS" ("ID", "ID_MATERIAL", "MONTH", "QUANTITY", "ID_UNIT_FROM", "ID_UNIT_TO", "VAL_INTENSITY", "VAL_INTENSITY_MIN", "VAL_INTENSITY_MAX", "VAL_INTENSITY_MONTHS", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "MARKED_AS_VALID_BY", "MARKED_AS_VALID", "ID_NODE", "ID_ADV_STATUS", "ID_MAT_BASIS", "INTENSITY_STD", "ADV_PARAMS", "INTENSITY_MEAN", "ID_ANALYSIS_PARAM", "ADV_VALID", "ID_UNIT_SET", "ID_UNIT_NUMEN_FROM", "ID_UNIT_NUMEN_TO", "ID_UNIT_DENOM_FROM", "ID_UNIT_DENOM_TO", "ID_UNIT_SET_SETTINGS", "ID_UNIT_SET_SETTINGS_AP", "FACTOR_A", "FACTOR_B", "UNIT_ABBR_TO", "FORMATED_FACTOR_A", "FORMATED_FACTOR_B", "FORMATED_UNIT_ABBR_TO", "UNIT_NUMEN_ABBR_TO", "ID_UNIT_TYPE_NUMEN") AS
  SELECT   adv.ID ID,
            material_node.ID_MATERIAL id_material,
            adv.MONTH month,
            (  unit_to.k / unit_from.k * adv.quantity
             + unit_to.q
             - unit_from.q * (unit_to.k / unit_from.k))
               quantity,
            unit_from.id id_unit_from,
            unit_to.id id_unit_to,
            adv.VAL_INTENSITY VAL_INTENSITY,
            adv.VAL_INTENSITY_MIN VAL_INTENSITY_MIN,
            adv.VAL_INTENSITY_MAX VAL_INTENSITY_MAX,
            adv.VAL_INTENSITY_MONTHS VAL_INTENSITY_MONTHS,
            adv.CREATED_BY CREATED_BY,
            adv.CREATED CREATED,
            adv.MODIFIED_BY MODIFIED_BY,
            adv.MODIFIED MODIFIED,
            adv.MARKED_AS_VALID_BY MARKED_AS_VALID_BY,
            adv.MARKED_AS_VALID MARKED_AS_VALID,
            material_node.ID_NODE ID_NODE,
            DECODE (adv.ADV_VALID, 1, 1, adv.ID_ADV_STATUS) ID_ADV_STATUS,
            adv.ID_MATERIAL_BASIS ID_MAT_BASIS,
            adv.INTENSITY_STD INTENSITY_STD,
            adv.ADV_PARAMS ADV_PARAMS,
            adv.INTENSITY_MEAN INTENSITY_MEAN,
            adv.ID_ANALYSIS_PARAM ID_ANALYSIS_PARAM,
            adv.ADV_VALID ADV_VALID,
            us.id id_unit_set,
            unit_numen_from.id id_unit_numen_from,
            unit_numen_to.id id_unit_numen_to,
            unit_denom_from.id id_unit_denom_from,
            unit_denom_to.id id_unit_denom_to,
            uss_to.id id_unit_set_settings,
            uss_ap_to.id id_unit_set_settings_ap,
            (  unit_numen_to.k / unit_numen_from.k * adv.factor_a
             + unit_numen_to.q
             - unit_numen_from.q * (unit_numen_to.k / unit_numen_from.k))
            / NVL (
                 (  unit_denom_to.k / unit_denom_from.k
                  + unit_denom_to.q
                  - unit_denom_from.q * (unit_denom_to.k / unit_denom_from.k)),
                 1
              )
               factor_a,
            (  unit_numen_to.k / unit_numen_from.k * adv.factor_b
             + unit_numen_to.q
             - unit_numen_from.q * (unit_numen_to.k / unit_numen_from.k))
            / NVL (
                 (  unit_denom_to.k / unit_denom_from.k
                  + unit_denom_to.q
                  - unit_denom_from.q * (unit_denom_to.k / unit_denom_from.k)),
                 1
              )
               factor_b,
            DECODE (adv.id_unit_denominator,
                    NULL, unit_numen_to.abbr,
                    unit_numen_to.abbr || '/' || unit_denom_to.abbr)
               unit_abbr_to,
            --analysis format
            ROUND (
               DECODE (
                  unit_numen_to.id_unit_type,
                  unit_denom_from.id_unit_type,
                  --ak su typy jednotiek rovnake mozme skusit naformatovat
                  (unit_numen_to.k / unit_numen_from.k * adv.factor_a
                   + unit_numen_to.q
                   - unit_numen_from.q
                     * (unit_numen_to.k / unit_numen_from.k))
                  / NVL (
                       (unit_numen_to.k / unit_denom_from.k + unit_numen_to.q
                        - unit_denom_from.q
                          * (unit_numen_to.k / unit_denom_from.k)),
                       1
                    )
                  * uaf.koef,
                  --ak nie su typy jednotiek rovnake
                  (unit_numen_to.k / unit_numen_from.k * adv.factor_a
                   + unit_numen_to.q
                   - unit_numen_from.q
                     * (unit_numen_to.k / unit_numen_from.k))
                  / NVL (
                       (unit_denom_to.k / unit_denom_from.k + unit_denom_to.q
                        - unit_denom_from.q
                          * (unit_denom_to.k / unit_denom_from.k)),
                       1
                    )
               ),
               uaf.max_fraction_digits
            )
               formated_factor_a,
            ROUND (
               DECODE (
                  unit_numen_to.id_unit_type,
                  unit_denom_from.id_unit_type,
                  (unit_numen_to.k / unit_numen_from.k * adv.factor_b
                   + unit_numen_to.q
                   - unit_numen_from.q
                     * (unit_numen_to.k / unit_numen_from.k))
                  / NVL (
                       (unit_numen_to.k / unit_denom_from.k + unit_numen_to.q
                        - unit_denom_from.q
                          * (unit_numen_to.k / unit_denom_from.k)),
                       1
                    )
                  * uaf.koef,
                  (unit_numen_to.k / unit_numen_from.k * adv.factor_b
                   + unit_numen_to.q
                   - unit_numen_from.q
                     * (unit_numen_to.k / unit_numen_from.k))
                  / NVL (
                       (unit_denom_to.k / unit_denom_from.k + unit_denom_to.q
                        - unit_denom_from.q
                          * (unit_denom_to.k / unit_denom_from.k)),
                       1
                    )
               ),
               uaf.max_fraction_digits
            )
               formated_factor_b,
            DECODE (
               unit_numen_to.id_unit_type,
               unit_denom_from.id_unit_type,
               NVL (
                  uaf.abbr,
                  DECODE (adv.id_unit_denominator,
                          NULL, unit_numen_to.abbr,
                          unit_numen_to.abbr || '/' || unit_denom_to.abbr)
               ),
               DECODE (adv.id_unit_denominator,
                       NULL, unit_numen_to.abbr,
                       unit_numen_to.abbr || '/' || unit_denom_to.abbr)
            )
               formated_unit_abbr_to,
            --end of analysis format
            unit_numen_to.abbr unit_numen_abbr_to,
            unit_numen_to.id_unit_type id_unit_type_numen
     FROM                                    gbc_adv_details adv
                                          CROSS JOIN
                                             gbc_unit_set us
                                       INNER JOIN
                                          gbc_material_node material_node
                                       ON material_node.id =
                                             adv.id_material_node
                                       INNER JOIN
                                          gbc_unit unit_numen_from
                                       ON unit_numen_from.id =
                                             adv.id_unit_numenator
                                    INNER JOIN
                                       GBC_ANALYSIS_PARAM ap
                                    ON ap.id = adv.id_analysis_param
                                 INNER JOIN
                                    GBC_UNIT_ANALYSIS_FORMAT uaf
                                 ON uaf.id = ap.ID_ANALYSIS_FORMAT
                              LEFT OUTER JOIN
                                 gbc_unit unit_denom_from
                              ON unit_denom_from.id = adv.id_unit_denominator
                           LEFT OUTER JOIN
                              GBC_UNIT_SET_SETTINGS_AP uss_ap_to
                           ON uss_ap_to.id_unit_set = us.id
                              AND uss_ap_to.id_analysis_param = ap.id
                        LEFT OUTER JOIN
                           gbc_unit unit_numen_to
                        ON unit_numen_to.id = uss_ap_to.id_unit
                     LEFT OUTER JOIN
                        GBC_UNIT_SET_SETTINGS uss_to
                     ON uss_to.id_unit_set = us.id
                        AND uss_to.id_material = material_node.id_material
                  LEFT OUTER JOIN
                     gbc_unit unit_denom_to
                  ON unit_denom_to.id = uss_to.id_unit
               INNER JOIN
                  gbc_unit unit_from
               ON unit_from.id = adv.id_unit
            LEFT OUTER JOIN
               gbc_unit unit_to
            ON unit_to.id = uss_to.id_unit
;
  GRANT SELECT ON "VGBC_ADV_DETAILS" TO "GBC_PRX";
  GRANT SELECT ON "VGBC_ADV_DETAILS" TO "TRANSFER_BI";
