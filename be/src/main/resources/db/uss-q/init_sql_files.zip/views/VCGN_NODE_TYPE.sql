--------------------------------------------------------
--  DDL for View VCGN_NODE_TYPE
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_NODE_TYPE" ("ID", "ID_NODE_LEVEL", "NAME", "MEMO", "REPORT_POS", "CODE", "ID_MATERIAL_REPORT", "MATERIAL_REPORT_NAME") AS
  SELECT   nt.ID,
            nt.ID_NODE_LEVEL,
            NVL (NVL (dul.translation, de.translation), nt.NAME_K) name,
            nt.MEMO,
            nt.REPORT_POS,
            NT.CODE,
            nt.ID_MATERIAL_REPORT,
            M.NAME MATERIAL_REPORT_NAME
     FROM            gbc_node_type nt
                  LEFT OUTER JOIN
                     vcgn_dictionary_usr_lng dul
                  ON dul.key = nt.name_k
               LEFT OUTER JOIN
                  vcgn_dictionary_en de
               ON de.key = nt.name_k
            INNER JOIN
               vcgn_material m
            ON M.ID = NT.ID_MATERIAL_REPORT 
;
  GRANT SELECT ON "VCGN_NODE_TYPE" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_NODE_TYPE" TO "TRANSFER_BI";
