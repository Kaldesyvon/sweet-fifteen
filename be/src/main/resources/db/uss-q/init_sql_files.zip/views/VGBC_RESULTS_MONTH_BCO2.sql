--------------------------------------------------------
--  DDL for View VGBC_RESULTS_MONTH_BCO2
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VGBC_RESULTS_MONTH_BCO2" ("ID", "MONTH", "CARBON_SUM", "CARBON_INPUT", "CARBON_OUTPUT", "CARBON_UNIT", "PRODUCTED_STEEL", "ENERGY_SUM", "ENERGY_INPUT", "ENERGY_OUTPUT", "ENERGY_UNIT", "UNCERTAINTY_INPUT", "UNCERTAINTY_OUTPUT", "ID_UNIT_SET") AS
  SELECT c.id_unit_set
    || TRUNC (c.month, 'MM') id,
    c.month,
    c.carbon_Sum,
    c.carbon_Input,
    c.carbon_Output,
    c.carbon_Unit ,
    c.producted_steel,
    e.energy_Sum,
    e.energy_Input,
    e.energy_Output,
    e.energy_Unit,
    c.uncertainty_Input  AS uncertainty_Input,
    c.uncertainty_Output AS uncertainty_Output,
    c.id_unit_set
  FROM
    (SELECT vrm.MONTH,
      SUM(vrm.ANALYTICAL_VALUE) AS Carbon_Sum,
      SUM(
      CASE
        WHEN vrm.IO = 1
        THEN vrm.ANALYTICAL_VALUE
        ELSE .00
      END ) AS Carbon_Input,
      SUM(
      CASE
        WHEN vrm.IO              = -1
        AND vrm.ID_ANALYSIS_PARAM=4
        THEN vrm.ANALYTICAL_VALUE
        ELSE .00
      END ) *-1 AS Carbon_Output,
      SUM(
      CASE
        WHEN vrm.ID_MATERIAL = 62
        THEN vrm.quantity
        ELSE .00
      END)             AS producted_steel,
      vrm.UNIT_ABBR_AV AS Carbon_Unit,
      vrm.id_unit_set,
      CASE
        WHEN SUM( DECODE(vrm.IO,1, vrm.ANALYTICAL_VALUE,0)) > 0
        THEN SQRT (SUM (
          CASE
            WHEN vrm.IO = 1
            THEN POWER(vrm.uncertainty*vrm.analytical_value,2)
            ELSE .00
          END))/SUM(
          CASE
            WHEN vrm.IO = 1
            THEN vrm.analytical_value
            ELSE .00
          END)
        ELSE 0
      END uncertainty_Input,
      CASE
        WHEN SUM( DECODE(vrm.IO,-1, vrm.ANALYTICAL_VALUE,0)) > 0
        THEN SQRT (SUM (
          CASE
            WHEN vrm.IO =             -1
            THEN POWER(vrm.uncertainty*vrm.analytical_value,2)
            ELSE .00
          END))/SUM(
          CASE
            WHEN vrm.IO = -1
            THEN vrm.analytical_value
            ELSE .00
          END)
        ELSE 0
      END uncertainty_Output
    FROM VGBC_RESULTS_MONTH vrm
    WHERE vrm.ID_NODE       IN (1412,1615,1616,1617,1618,1619,1620,1621,1622)
    AND vrm.ID_SCOPE         = 1553
    AND vrm.ID_ANALYSIS_PARAM=4
    GROUP BY vrm.MONTH,
      vrm.UNIT_ABBR_AV,
      vrm.id_unit_set
      --      ORDER BY vrm.MONTH ASC
    ) c
  JOIN
    (SELECT vrm.MONTH,
      SUM(vrm.ANALYTICAL_VALUE) AS Energy_Sum,
      SUM(
      CASE
        WHEN vrm.IO = 1
        THEN vrm.ANALYTICAL_VALUE
        ELSE .00
      END ) AS Energy_Input,
      SUM(
      CASE
        WHEN vrm.IO = -1
        THEN vrm.ANALYTICAL_VALUE
        ELSE .00
      END ) *-1        AS Energy_Output,
      vrm.UNIT_ABBR_AV AS Energy_Unit,
      vrm.id_unit_set
    FROM VGBC_RESULTS_MONTH vrm
    WHERE vrm.ID_NODE       IN (1412,1615,1616,1617,1618,1619,1620,1621,1622)
    AND vrm.ID_SCOPE         = 1553
-- opravene z  54 na 1553 na poziadanie MVidu 21.10.2013  Hornak    
    AND vrm.ID_ANALYSIS_PARAM=2
    GROUP BY vrm.MONTH,
      vrm.UNIT_ABBR_AV,
      vrm.id_unit_set
      --      ORDER BY vrm.MONTH ASC
    ) e
  ON (c.month       = e.month
  AND c.id_unit_set = e.id_unit_set)
  ORDER BY c.month
;
  GRANT SELECT ON "VGBC_RESULTS_MONTH_BCO2" TO "TRANSFER_BI";
  GRANT SELECT ON "VGBC_RESULTS_MONTH_BCO2" TO "GBC_PRX";
