--------------------------------------------------------
--  DDL for View VCGN_MATERIAL
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_MATERIAL" ("ID", "CODE", "NAME", "MEMO", "ID_UNIT_TYPE", "PRODUCT", "REPORT_POS", "MATERIAL_REPORT", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "OBJ_VERSION", "ID_MATERIAL", "MATERIAL_GROUP", "ID_UNIT", "UNIT_ABBR") AS
  SELECT   m.ID,
            m.CODE,
            NVL (mf.name, m.NAME) name,
            m.MEMO,
            m.ID_UNIT_TYPE,
            m.PRODUCT,
            m.REPORT_POS,
            m.MATERIAL_REPORT,
            m.CREATED_BY,
            m.CREATED,
            m.MODIFIED_BY,
            m.MODIFIED,
            m.OBJ_VERSION,
            m.ID_MATERIAL,
            m.MATERIAL_GROUP,
            u.id id_unit,
            U.ABBR unit_abbr
     FROM            gbc_material m
                  LEFT OUTER JOIN
                     gbc_material_fl mf
                  ON MF.ID_MASTER = m.id
                     AND MF.ID_LANGUAGE = ph_tst_cgn.getidlanguage
               LEFT OUTER JOIN
                  GBC_UNIT_SET_SETTINGS uss
               ON USS.ID_MATERIAL = m.id
                  AND USS.ID_UNIT_SET = ph_tst_cgn.getidunitset
            LEFT OUTER JOIN
               GBC_UNIT u
            ON U.ID = USS.ID_UNIT 
;
  GRANT SELECT ON "VCGN_MATERIAL" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_MATERIAL" TO "TRANSFER_BI";
