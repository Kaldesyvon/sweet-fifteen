--------------------------------------------------------
--  DDL for View VCGN_SCOPE_PROCESS_SPEC
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_SCOPE_PROCESS_SPEC" ("ID", "NAME") AS
  SELECT   sps.id,
            NVL (NVL (dul.translation, de.translation), sps.NAME_K) name
     FROM         GBC_SCOPE_PROCESS_SPEC sps
               LEFT OUTER JOIN
                  vcgn_dictionary_usr_lng dul
               ON dul.key = sps.name_k
            LEFT OUTER JOIN
               vcgn_dictionary_en de
            ON de.key = sps.name_k 
;
  GRANT SELECT ON "VCGN_SCOPE_PROCESS_SPEC" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_SCOPE_PROCESS_SPEC" TO "TRANSFER_BI";
