--------------------------------------------------------
--  DDL for View VCGN_UNIT_SET
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_UNIT_SET" ("ID", "CODE", "NAME") AS
  SELECT   us.ID,
            US.CODE,
            NVL (NVL (dul.translation, de.translation), us.NAME_K) name
     FROM         gbc_unit_set us
               LEFT OUTER JOIN
                  vcgn_dictionary_usr_lng dul
               ON dul.key = us.name_k
            LEFT OUTER JOIN
               vcgn_dictionary_en de
            ON de.key = us.name_k 
;
  GRANT SELECT ON "VCGN_UNIT_SET" TO "TRANSFER_BI";
  GRANT SELECT ON "VCGN_UNIT_SET" TO "CGN_PRX";
