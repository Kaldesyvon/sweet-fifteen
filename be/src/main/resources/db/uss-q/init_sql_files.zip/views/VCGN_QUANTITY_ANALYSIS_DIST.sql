--------------------------------------------------------
--  DDL for View VCGN_QUANTITY_ANALYSIS_DIST
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_QUANTITY_ANALYSIS_DIST" ("ID_QUANTITY", "ID_NODE", "ID_MATERIAL", "ID_MATERIAL_NODE", "ID_UNIT_SET", "QUANTITY", "UNIT_TO_ABBR", "DATE_FROM", "MONTH_FROM", "ID_MONTH_FROM", "ID_IEAR_FROM", "DATE_TO", "IO", "REMOTE_CODE", "MEMO", "NODE_REPORT_POS", "MATERIAL_REPORT_POS", "AUTO_ANALYSIS", "TIER", "ID_METER", "NUMBER_OF_MEASUREMENTS", "QUANTITY_UNCERTAINTY", "ID_ANALYSIS", "FACTOR_A", "FORMATED_FACTOR_A", "FACTOR_B", "FORMATED_FACTOR_B", "FACTOR_C", "FORMATED_FACTOR_C", "ANALYTICAL_VALUE", "VALID_FROM", "VALID_TO", "ID_ANALYSIS_PARAM", "UNIT_ABBR_TO_ANALYSIS", "UNIT_NUMEN_ABBR_TO", "MDL_A", "ANALYSIS_UNCERTAINTY", "A_NUMBER_OF_MEASUREMENTS", "A_MEASUREMENTS_FREQUENCY", "ID_SCOPE") AS
  SELECT q.ID ID_QUANTITY,
          q.ID_NODE,
          q.ID_MATERIAL,
          q.ID_MATERIAL_NODE,
          q.ID_UNIT_SET,
          q.QUANTITY,
          q.UNIT_TO_ABBR,
          q.DATE_FROM,
          q.month_from,
          q.id_month id_month_from,
          q.id_year id_iear_from,
          q.DATE_TO,
          q.IO,
          q.REMOTE_CODE,
          q.MEMO,
          q.NODE_REPORT_POS,
          q.MATERIAL_REPORT_POS,
          q.AUTO_ANALYSIS,
          /*            Q.TIER1,
                      Q.TIER2,
                      Q.TIER3,*/
          Q.TIER,
          --            q.ID_MEASURE_POINT,
          --            q.MEASURE_POINT_NAME,
          Q.ID_METER,
          q.NUMBER_OF_MEASUREMENTS,
          q.UNCERTAINTY QUANTITY_UNCERTAINTY,
          qa.ID_ANALYSIS,
          A.FACTOR_A,
          A.FORMATED_FACTOR_A,
          A.FACTOR_B,
          A.FORMATED_FACTOR_B,
          A.FACTOR_C,
          A.FORMATED_FACTOR_C,
          DECODE (
             ut.compute,
             0, TO_NUMBER (NULL),
             (  (  a.factor_a * smn.FACTOR_A
                 + NVL (a.factor_b, 0) * NVL (smn.FACTOR_B, 0))
              * q.quantity
              * q.IO
              * smn.USE_CALCULATION))
             analytical_value,
          A.VALID_FROM,
          A.VALID_TO,
          MNA.ID_ANALYSIS_PARAM,
          A.UNIT_ABBR_TO UNIT_ABBR_TO_ANALYSIS,
          A.UNIT_NUMEN_ABBR_TO,
          A.MDL_A,
          A.UNCERTAINTY ANALYSIS_UNCERTAINTY,
          A.NUMBER_OF_MEASUREMENTS A_NUMBER_OF_MEASUREMENTS,
          A.MEASUREMENTS_FREQUENCY A_MEASUREMENTS_FREQUENCY,
          SMN.ID_SCOPE ID_SCOPE
     FROM vcgn_quantity q
          LEFT OUTER JOIN GBC_MATERIAL_NODE_AP mna
             ON MNA.ID_MATERIAL_NODE = Q.ID_MATERIAL_NODE
          LEFT OUTER JOIN GBC_SCOPE_MATERIAL_NODE smn
             ON SMN.ID_MATERIAL_NODE = Q.ID_MATERIAL_NODE
          LEFT OUTER JOIN gbc_quantity_analysis qa
             ON     QA.ID_QUANTITY = Q.ID
                AND QA.ID_ANALYSIS_PARAM = MNA.ID_ANALYSIS_PARAM
          LEFT OUTER JOIN vcgn_analysis a
             ON     A.ID = QA.ID_ANALYSIS
                AND A.ID_ANALYSIS_PARAM = MNA.ID_ANALYSIS_PARAM
          LEFT OUTER JOIN gbc_unit_type ut
             ON ut.id = a.id_unit_type_numen
   UNION ALL
   SELECT NULL ID_QUANTITY,
          a.ID_NODE,
          a.ID_MATERIAL,
          a.ID_MATERIAL_NODE,
          a.ID_UNIT_SET,
          NULL QUANTITY,
          NULL UNIT_TO_ABBR,
          NULL DATE_FROM,
          NULL month_from,
          NULL id_month_from,
          NULL id_iear_from,
          NULL DATE_TO,
          NULL IO,
          NULL REMOTE_CODE,
          NULL MEMO,
          NULL NODE_REPORT_POS,
          NULL MATERIAL_REPORT_POS,
          NULL AUTO_ANALYSIS,
          /*            NULL TIER1,
                      NULL TIER2,
                      NULL TIER3,*/
          NULL TIER,
          /*            NULL ID_MEASURE_POINT,
                      NULL MEASURE_POINT_NAME,  */
          NULL ID_METER,
          NULL NUMBER_OF_MEASUREMENTS,
          NULL QUANTITY_UNCERTAINTY,
          A.ID ID_ANALYSIS,
          A.FACTOR_A,
          A.FORMATED_FACTOR_A,
          A.FACTOR_B,
          A.FORMATED_FACTOR_B,
          A.FACTOR_C,
          A.FORMATED_FACTOR_C,
          NULL analytical_value,
          A.VALID_FROM,
          A.VALID_TO,
          A.ID_ANALYSIS_PARAM,
          A.UNIT_ABBR_TO UNIT_ABBR_TO_ANALYSIS,
          A.UNIT_NUMEN_ABBR_TO,
          A.MDL_A,
          A.UNCERTAINTY ANALYSIS_UNCERTAINTY,
          A.NUMBER_OF_MEASUREMENTS A_NUMBER_OF_MEASUREMENTS,
          A.MEASUREMENTS_FREQUENCY A_MEASUREMENTS_FREQUENCY,
          SMN.ID_SCOPE ID_SCOPE
     FROM    vcgn_analysis a
          LEFT OUTER JOIN
             GBC_SCOPE_MATERIAL_NODE smn
          ON SMN.ID_MATERIAL_NODE = A.ID_MATERIAL_NODE
    WHERE NOT EXISTS
             (SELECT 1
                FROM gbc_quantity_analysis qa
               WHERE QA.ID_ANALYSIS = a.id)
;
  GRANT SELECT ON "VCGN_QUANTITY_ANALYSIS_DIST" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_QUANTITY_ANALYSIS_DIST" TO "TRANSFER_BI";
