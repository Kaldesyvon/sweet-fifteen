--------------------------------------------------------
--  DDL for View VCGN_DICTIONARY_EN
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_DICTIONARY_EN" ("ID", "ID_LANGUAGE", "KEY", "TRANSLATION", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "OBJ_VERSION", "ID_DICTIONARY_TABLE") AS
  SELECT   "ID",
            "ID_LANGUAGE",
            "KEY",
            "TRANSLATION",
            "CREATED_BY",
            "CREATED",
            "MODIFIED_BY",
            "MODIFIED",
            "OBJ_VERSION",
            "ID_DICTIONARY_TABLE"
     FROM   gbc_dictionary d
    WHERE   D.ID_LANGUAGE = 1 
;
  GRANT SELECT ON "VCGN_DICTIONARY_EN" TO "TRANSFER_BI";
