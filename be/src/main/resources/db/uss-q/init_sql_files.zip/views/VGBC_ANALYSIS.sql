--------------------------------------------------------
--  DDL for View VGBC_ANALYSIS
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VGBC_ANALYSIS" ("ID", "ID_NODE", "ID_MATERIAL", "ID_MATERIAL_NODE", "ID_ANALYSIS_PARAM", "ID_UNIT_SET", "ID_UNIT_NUMEN_FROM", "ID_UNIT_NUMEN_TO", "ID_UNIT_DENOM_FROM", "ID_UNIT_DENOM_TO", "ID_UNIT_SET_SETTINGS", "ID_UNIT_SET_SETTINGS_AP", "FACTOR_A", "FACTOR_B", "FACTOR_C", "UNIT_ABBR_TO", "FORMATED_FACTOR_A", "FORMATED_FACTOR_B", "FORMATED_FACTOR_C", "FORMATED_UNIT_ABBR_TO", "UNIT_NUMEN_ABBR_TO", "ID_UNIT_TYPE_NUMEN", "VALID_FROM", "VALID_TO", "REMOTE_CODE", "MEMO", "FACTOR_A_FROM", "FACTOR_B_FROM", "FACTOR_C_FROM", "MATERIAL_NAME", "PLANT_NAME", "CREATED", "CREATED_BY", "MODIFIED", "MODIFIED_BY", "EDITABLE", "CALCULATED", "NODE_REPORT_POS", "MATERIAL_REPORT_POS", "ANALYSIS_PARAM_NAME_K", "MATERIAL_NODE_INPUT", "MATERIAL_NODE_OUTPUT", "UNCERTAINTY", "MDL_A", "ID_REMOTE_MATERIAL_CODE", "NUMBER_OF_MEASUREMENTS", "MEASUREMENTS_FREQUENCY") AS
  SELECT a.id id,
    p.id id_node,
    m.id id_material,
    mp.id id_material_node,
    a.id_analysis_param id_analysis_param,
    us.id id_unit_set,
    unit_numen_from.id id_unit_numen_from,
    unit_numen_to.id id_unit_numen_to,
    unit_denom_from.id id_unit_denom_from,
    unit_denom_to.id id_unit_denom_to,
    uss_to.id id_unit_set_settings,
    uss_ap_to.id id_unit_set_settings_ap,
    ( unit_numen_to.k / unit_numen_from.k * a.factor_a + unit_numen_to.q - unit_numen_from.q * (unit_numen_to.k / unit_numen_from.k)) / NVL ( ( unit_denom_to.k / unit_denom_from.k + unit_denom_to.q - unit_denom_from.q * (unit_denom_to.k / unit_denom_from.k)), 1 ) factor_a,
    ( unit_numen_to.k / unit_numen_from.k * a.factor_b + unit_numen_to.q - unit_numen_from.q * (unit_numen_to.k / unit_numen_from.k)) / NVL ( ( unit_denom_to.k / unit_denom_from.k + unit_denom_to.q - unit_denom_from.q * (unit_denom_to.k / unit_denom_from.k)), 1 ) factor_b,
    ( unit_numen_to.k / unit_numen_from.k * a.factor_c + unit_numen_to.q - unit_numen_from.q * (unit_numen_to.k / unit_numen_from.k)) / NVL ( ( unit_denom_to.k / unit_denom_from.k + unit_denom_to.q - unit_denom_from.q * (unit_denom_to.k / unit_denom_from.k)), 1 ) factor_c,
  DECODE (a.id_unit_denominator, NULL, unit_numen_to.abbr, unit_numen_to.abbr
  || '/'
  || unit_denom_to.abbr) unit_abbr_to,
  --analysis format
  ROUND ( DECODE ( unit_numen_to.id_unit_type, unit_denom_from.id_unit_type,
  --ak su typy jednotiek rovnake mozme skusit naformatovat
  (unit_numen_to.k / unit_numen_from.k * a.factor_a + unit_numen_to.q - unit_numen_from.q * (unit_numen_to.k / unit_numen_from.k)) / NVL ( (unit_numen_to.k / unit_denom_from.k + unit_numen_to.q - unit_denom_from.q * (unit_numen_to.k / unit_denom_from.k)), 1 ) * uaf.koef,
  --ak nie su typy jednotiek rovnake
  (unit_numen_to.k                                                                            / unit_numen_from.k * a.factor_a + unit_numen_to.q - unit_numen_from.q * (unit_numen_to.k / unit_numen_from.k)) / NVL ( (unit_denom_to.k / unit_denom_from.k + unit_denom_to.q - unit_denom_from.q * (unit_denom_to.k / unit_denom_from.k)), 1 ) ), uaf.max_fraction_digits ) formated_factor_a,
  ROUND ( DECODE ( unit_numen_to.id_unit_type, unit_denom_from.id_unit_type, (unit_numen_to.k / unit_numen_from.k * a.factor_b + unit_numen_to.q - unit_numen_from.q * (unit_numen_to.k / unit_numen_from.k)) / NVL ( (unit_numen_to.k / unit_denom_from.k + unit_numen_to.q - unit_denom_from.q * (unit_numen_to.k / unit_denom_from.k)), 1 ) * uaf.koef, (unit_numen_to.k / unit_numen_from.k * a.factor_b + unit_numen_to.q - unit_numen_from.q * (unit_numen_to.k / unit_numen_from.k)) / NVL ( (unit_denom_to.k / unit_denom_from.k + unit_denom_to.q - unit_denom_from.q * (unit_denom_to.k / unit_denom_from.k)), 1 ) ), uaf.max_fraction_digits ) formated_factor_b,
  ROUND ( DECODE ( unit_numen_to.id_unit_type, unit_denom_from.id_unit_type, (unit_numen_to.k / unit_numen_from.k * a.factor_c + unit_numen_to.q - unit_numen_from.q * (unit_numen_to.k / unit_numen_from.k)) / NVL ( (unit_numen_to.k / unit_denom_from.k + unit_numen_to.q - unit_denom_from.q * (unit_numen_to.k / unit_denom_from.k)), 1 ) * uaf.koef, (unit_numen_to.k / unit_numen_from.k * a.factor_c + unit_numen_to.q - unit_numen_from.q * (unit_numen_to.k / unit_numen_from.k)) / NVL ( (unit_denom_to.k / unit_denom_from.k + unit_denom_to.q - unit_denom_from.q * (unit_denom_to.k / unit_denom_from.k)), 1 ) ), uaf.max_fraction_digits ) formated_factor_c,
  DECODE ( unit_numen_to.id_unit_type, unit_denom_from.id_unit_type, NVL ( uaf.abbr, DECODE (a.id_unit_denominator, NULL, unit_numen_to.abbr, unit_numen_to.abbr
  || '/'
  || unit_denom_to.abbr) ), DECODE (a.id_unit_denominator, NULL, unit_numen_to.abbr, unit_numen_to.abbr
  || '/'
  || unit_denom_to.abbr) ) formated_unit_abbr_to,
  --end of analysis format
  unit_numen_to.abbr unit_numen_abbr_to,
  unit_numen_to.id_unit_type id_unit_type_numen,
  a.valid_from valid_from,
  a.valid_to valid_to,
  a.remote_code remote_code,
  a.memo memo,
  a.factor_a factor_a_from, --not useful columns
  a.factor_b factor_b_from,
  a.factor_c factor_c_from,
  m.name material_name,
  p.name_k plant_name,
  a.created created,
  a.created_by created_by,
  a.modified modified,
  a.modified_by modified_by,
  a.editable,
  a.calculated calculated,
  p.report_pos NODE_REPORT_POS,
  m.report_pos MATERIAL_REPORT_POS,
  ap.name_k analysis_param_name_k,
  mp.input material_node_input,
  mp.output material_node_output,
  a.UNCERTAINTY UNCERTAINTY,
  a.MDL_A MDL_A,
  a.ID_REMOTE_MATERIAL_CODE ID_REMOTE_MATERIAL_CODE,
  a.NUMBER_OF_MEASUREMENTS NUMBER_OF_MEASUREMENTS,
  a.MEASUREMENTS_FREQUENCY MEASUREMENTS_FREQUENCY
FROM gbc_analysis a
CROSS JOIN gbc_unit_set us
INNER JOIN gbc_material_node mp
ON mp.ID = a.ID_MATERIAL_NODE
INNER JOIN gbc_material m
ON m.id = mp.id_material
INNER JOIN gbc_node p
ON p.id = mp.id_node
INNER JOIN gbc_unit unit_numen_from
ON unit_numen_from.id = a.id_unit_numenator
INNER JOIN GBC_ANALYSIS_PARAM ap
ON ap.id = a.id_analysis_param
INNER JOIN GBC_UNIT_ANALYSIS_FORMAT uaf
ON uaf.id = ap.ID_ANALYSIS_FORMAT
LEFT OUTER JOIN gbc_unit unit_denom_from
ON unit_denom_from.id = a.id_unit_denominator
LEFT OUTER JOIN GBC_UNIT_SET_SETTINGS_AP uss_ap_to
ON uss_ap_to.id_unit_set        = us.id
AND uss_ap_to.id_analysis_param = ap.id
LEFT OUTER JOIN gbc_unit unit_numen_to
ON unit_numen_to.id = uss_ap_to.id_unit
LEFT OUTER JOIN GBC_UNIT_SET_SETTINGS uss_to
ON uss_to.id_unit_set  = us.id
AND uss_to.id_material = m.id
LEFT OUTER JOIN gbc_unit unit_denom_to
ON unit_denom_to.id = uss_to.id_unit
;
  GRANT SELECT ON "VGBC_ANALYSIS" TO "GBC_PRX";
  GRANT SELECT ON "VGBC_ANALYSIS" TO "CGN_PRX";
  GRANT SELECT ON "VGBC_ANALYSIS" TO "TRANSFER_BI";
