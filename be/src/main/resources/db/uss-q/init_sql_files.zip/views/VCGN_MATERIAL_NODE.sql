--------------------------------------------------------
--  DDL for View VCGN_MATERIAL_NODE
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_MATERIAL_NODE" ("ID", "ID_NODE", "ID_MATERIAL", "MEMO", "PRODUCT", "INPUT", "OUTPUT", "NAME", "TIER", "CARBON_MAX", "CARBON_MIN", "COMMON_PIPE_ID", "COMMON_PIPE_PARENT", "NOTE1", "NOTE2", "NOTE3") AS
  SELECT   mn.ID,
            mn.ID_NODE,
            mn.ID_MATERIAL,
            mn.MEMO,
            mn.PRODUCT,
            mn.INPUT,
            mn.OUTPUT,
            mn.NAME,
            MN.TIER,
            MN.CARBON_MAX,
            MN.CARBON_MIN,
            MN.COMMON_PIPE_ID,
            MN.COMMON_PIPE_PARENT,
            MN.NOTE1,
            MN.NOTE2,
            MN.NOTE3
     --       MN.ID_INCLUDED_IN,
     --       MNI.NAME name_included_in,
     --       mn.TIER1, mn.TIER2, mn.TIER3
     FROM      gbc_material_node mn
            INNER JOIN
               VCGN_USER_NODES_ALL una
            ON UNA.ID = MN.ID_NODE
/*       left outer join gbc_material_node mni on 
         mni.id=MN.ID_INCLUDED_IN;*/ 
;
  GRANT SELECT ON "VCGN_MATERIAL_NODE" TO "CGN_PRX";
  GRANT SELECT ON "VCGN_MATERIAL_NODE" TO "TRANSFER_BI";
