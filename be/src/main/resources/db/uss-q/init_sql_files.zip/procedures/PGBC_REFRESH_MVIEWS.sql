--------------------------------------------------------
--  DDL for Procedure PGBC_REFRESH_MVIEWS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "PGBC_REFRESH_MVIEWS" IS
/******************************************************************************
   NAME:       PGBC_REFRESH_MVIEWS
   PURPOSE:    REFRESH Materialized views

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        14.03.2011          1. Created this procedure.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     PGBC_REFRESH_MVIEWS
      Sysdate:         14.03.2011
      Date and Time:   14.03.2011, 13:29:16, and 14.03.2011 13:29:16
      Username:        hardon
      Table Name:       

******************************************************************************/
BEGIN
--   DBMS_MVIEW.REFRESH('MV_NODE,MV_NODE_TRANSLATED,MV_PERIOD,MV_USER,MV_VGBC_ANALYSIS,MV_VGBC_QUANTITY,MV_VGBC_RESULTS_MONTH_CGN','c');
   DBMS_MVIEW.REFRESH('MV_NODE,MV_PERIOD,MV_USER,MV_VGBC_ANALYSIS,MV_VGBC_QUANTITY','c');
   EXCEPTION
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END PGBC_REFRESH_MVIEWS; 

/
