--------------------------------------------------------
--  DDL for Procedure MATERIAL_CHECK
--------------------------------------------------------

-- todo NOT MIGRATED - ERROR
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "MATERIAL_CHECK" (ID_MATERIAL_PAR number, ID_UNIT_TYPE_PAR number) AS
BEGIN
 DECLARE
  CURSOR c1 IS select * from GBC_MATERIAL_ANALYSIS_PARAM where id_material = ID_MATERIAL_PAR;
  param_rec c1%ROWTYPE;
  nextId NUMBER;
  noOfRecords NUMBER;
  noOfRecords2 NUMBER;
  noOfRecords3 NUMBER;
BEGIN

  select count(*) into noOfRecords from GBC_MATERIAL_ANALYSIS_PARAM where id_material = ID_MATERIAL_PAR;
  IF (noOfRecords = 0) THEN
    select material_analysis_param_seq.nextval INTO nextId from dual;
    Insert into GBC_MATERIAL_ANALYSIS_PARAM  (ID,ID_PLANT,ID_MATERIAL,ID_ANALYSIS_PARAM,PROCESS_ADV,STD_DEVIATION,ID_MATERIAL_ADV_BASIS,CREATED_BY,CREATED,OBJ_VERSION) 
                                      values (nextId,null,ID_MATERIAL_PAR, 1                ,1,         2,            25,                   'admin', SYSDATE, 0);
   
   select material_analysis_param_seq.nextval INTO nextId from dual;
    Insert into GBC_MATERIAL_ANALYSIS_PARAM 
          (ID,ID_PLANT,ID_MATERIAL,ID_ANALYSIS_PARAM,PROCESS_ADV,STD_DEVIATION,ID_MATERIAL_ADV_BASIS,CREATED_BY,CREATED,OBJ_VERSION) 
   values (nextId,null,ID_MATERIAL_PAR, 2                ,1,         2,            25,                   'admin',SYSDATE, 0);
   
    select material_analysis_param_seq.nextval INTO nextId from dual;
    Insert into GBC_MATERIAL_ANALYSIS_PARAM 
          (ID,ID_PLANT,ID_MATERIAL,ID_ANALYSIS_PARAM,PROCESS_ADV,STD_DEVIATION,ID_MATERIAL_ADV_BASIS,CREATED_BY,CREATED,OBJ_VERSION) 
   values (nextId,null,ID_MATERIAL_PAR, 4                ,1,         2,            25,                   'admin',SYSDATE, 0);
  END IF;
  
  
  select count(*) into noOfRecords2 from GBC_UNIT_SET_SETTINGS where id_material = ID_MATERIAL_PAR;
  select count(*) into noOfRecords3 from GBC_UNIT_SET;
  IF (noOfRecords2 <> noOfRecords3) THEN
    DELETE FROM GBC_UNIT_SET_SETTINGS where id_material = ID_MATERIAL_PAR;

    select unit_set_settings_seq.nextval INTO nextId from dual;

    Insert into GBC_UNIT_SET_SETTINGS 
      (ID,ID_UNIT_SET,ID_MATERIAL,ID_UNIT,CREATED_BY,CREATED,OBJ_VERSION) values 
      (nextId,1, ID_MATERIAL_PAR, DECODE(ID_UNIT_TYPE_PAR, 1,1,2,3,4,5,5,7,3,9),  'admin', SYSDATE, 0);
    
    select unit_set_settings_seq.nextval INTO nextId from dual;
    
    Insert into GBC_UNIT_SET_SETTINGS 
      (ID,ID_UNIT_SET,ID_MATERIAL,ID_UNIT,CREATED_BY,CREATED,OBJ_VERSION) values 
      (nextId,2, ID_MATERIAL_PAR, DECODE(ID_UNIT_TYPE_PAR, 1,2,2,4,4,5,5,8,3,10), 'admin', SYSDATE, 0);
  
  END IF;
  END;
  
END MATERIAL_CHECK; 

/
