--------------------------------------------------------
--  DDL for Procedure AUDIT_TRG_GENERATOR
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "AUDIT_TRG_GENERATOR" (av_table_name VARCHAR2) IS
  lv_trg    VARCHAR2(32767 BYTE);
  lb_first  BOOLEAN;
  
  ln_journal_type GBC_JOURNAL_TYPE.ID%TYPE;
  lv_update_columns_list  VARCHAR2(32767 BYTE);
  lv_insert_columns_list  VARCHAR2(32767 BYTE);
  lv_if_update_detail     VARCHAR2(32767 BYTE);
  lv_delete_columns_list     VARCHAR2(32767 BYTE);
  
  ln_created_by   PLS_INTEGER;
  ln_modified_by   PLS_INTEGER;
BEGIN
  lb_first := TRUE;
  FOR rec_columns IN (select column_name, data_type, nullable
                        from user_tab_columns
                       where table_name = av_table_name
                         and column_name not in ('CREATED_BY', 'CREATED', 'MODIFIED_BY', 'MODIFIED', 'OBJ_VERSION')
                         and data_type <> 'BLOB'
                       order by column_id asc)
  LOOP
    -- lv_update_columns_list
    IF lb_first THEN
      lv_update_columns_list := rec_columns.column_name;
    ELSE
      lv_update_columns_list := lv_update_columns_list || ',' || rec_columns.column_name;
    END IF;
    
    -- lv_insert_columns_list
    IF lb_first THEN
      IF rec_columns.data_type = 'VARCHAR2' THEN
        lv_insert_columns_list := 'lv_detail := ''' || rec_columns.column_name || ': "'' || :NEW.' || rec_columns.column_name || ' || ''"'';';
      ELSE
        lv_insert_columns_list := 'lv_detail := ''' || rec_columns.column_name || ': "'' || TO_CHAR(:NEW.' || rec_columns.column_name || ') || ''"'';';
      END IF;
    ELSE
      IF rec_columns.data_type = 'VARCHAR2' THEN
        lv_insert_columns_list := lv_insert_columns_list || CHR(13) || CHR(10) || CHR(9) || CHR(9) || 'lv_detail := lv_detail || '' ' || rec_columns.column_name || ': "'' || :NEW.' || rec_columns.column_name || ' || ''"'';';
      ELSE
        lv_insert_columns_list := lv_insert_columns_list || CHR(13) || CHR(10) || CHR(9) || CHR(9) || 'lv_detail := lv_detail || '' ' || rec_columns.column_name || ': "'' || TO_CHAR(:NEW.' || rec_columns.column_name || ') || ''"'';';
      END IF;
    END IF;
    
    -- lv_if_update_detail
    IF rec_columns.column_name = 'ID' THEN
      lv_if_update_detail := lv_if_update_detail || CHR(13) || CHR(10) || CHR(9) || CHR(9) || 'IF UPDATING(''' || rec_columns.column_name || ''') AND :NEW.' || rec_columns.column_name || ' <> :OLD.' || rec_columns.column_name || ' THEN lv_detail := lv_detail || '' ' || rec_columns.column_name || ': "'' || TO_CHAR(:OLD.' || rec_columns.column_name || ') || ''"->"'' || TO_CHAR(:NEW.' || rec_columns.column_name || ') || ''"''; ELSE lv_detail := lv_detail || '' ' || rec_columns.column_name || ': "'' || TO_CHAR(:OLD.' || rec_columns.column_name || ') || ''"''; END IF;';      
    ELSE
      IF rec_columns.nullable = 'Y' THEN
        IF rec_columns.data_type = 'VARCHAR2' THEN
          lv_if_update_detail := lv_if_update_detail || CHR(13) || CHR(10) || CHR(9) || CHR(9) || 'IF UPDATING(''' || rec_columns.column_name || ''') AND (:NEW.' || rec_columns.column_name || ' <> :OLD.' || rec_columns.column_name || ' OR (:NEW.' || rec_columns.column_name || ' IS NOT NULL AND :OLD.' || rec_columns.column_name || ' IS NULL) OR (:NEW.' || rec_columns.column_name || ' IS NULL AND :OLD.' || rec_columns.column_name || ' IS NOT NULL)) THEN lv_detail := lv_detail || '' ' || rec_columns.column_name || ': "'' || :OLD.' || rec_columns.column_name || ' || ''"->"'' || :NEW.' || rec_columns.column_name || ' || ''"''; END IF;';
        ELSE
          lv_if_update_detail := lv_if_update_detail || CHR(13) || CHR(10) || CHR(9) || CHR(9) || 'IF UPDATING(''' || rec_columns.column_name || ''') AND (:NEW.' || rec_columns.column_name || ' <> :OLD.' || rec_columns.column_name || ' OR (:NEW.' || rec_columns.column_name || ' IS NOT NULL AND :OLD.' || rec_columns.column_name || ' IS NULL) OR (:NEW.' || rec_columns.column_name || ' IS NULL AND :OLD.' || rec_columns.column_name || ' IS NOT NULL)) THEN lv_detail := lv_detail || '' ' || rec_columns.column_name || ': "'' || TO_CHAR(:OLD.' || rec_columns.column_name || ') || ''"->"'' || TO_CHAR(:NEW.' || rec_columns.column_name || ') || ''"''; END IF;';
        END IF;
      ELSE
        IF rec_columns.data_type = 'VARCHAR2' THEN
          lv_if_update_detail := lv_if_update_detail || CHR(13) || CHR(10) || CHR(9) || CHR(9) || 'IF UPDATING(''' || rec_columns.column_name || ''') AND :NEW.' || rec_columns.column_name || ' <> :OLD.' || rec_columns.column_name || ' THEN lv_detail := lv_detail || '' ' || rec_columns.column_name || ': "'' || :OLD.' || rec_columns.column_name || ' || ''"->"'' || :NEW.' || rec_columns.column_name || ' || ''"''; END IF;';
        ELSE
          lv_if_update_detail := lv_if_update_detail || CHR(13) || CHR(10) || CHR(9) || CHR(9) || 'IF UPDATING(''' || rec_columns.column_name || ''') AND :NEW.' || rec_columns.column_name || ' <> :OLD.' || rec_columns.column_name || ' THEN lv_detail := lv_detail || '' ' || rec_columns.column_name || ': "'' || TO_CHAR(:OLD.' || rec_columns.column_name || ') || ''"->"'' || TO_CHAR(:NEW.' || rec_columns.column_name || ') || ''"''; END IF;';
        END IF;
      END IF;    
    END IF;
    
    -- lv_delete_columns_list
    IF lb_first THEN
      IF rec_columns.data_type = 'VARCHAR2' THEN
        lv_delete_columns_list := 'lv_detail := ''' || rec_columns.column_name || ': "'' || :OLD.' || rec_columns.column_name || ' || ''"'';';
      ELSE
        lv_delete_columns_list := 'lv_detail := ''' || rec_columns.column_name || ': "'' || TO_CHAR(:OLD.' || rec_columns.column_name || ') || ''"'';';
      END IF;
    ELSE
      IF rec_columns.data_type = 'VARCHAR2' THEN
        lv_delete_columns_list := lv_delete_columns_list || CHR(13) || CHR(10) || CHR(9) || CHR(9) || 'lv_detail := lv_detail || '' ' || rec_columns.column_name || ': "'' || :OLD.' || rec_columns.column_name || ' || ''"'';';
      ELSE
        lv_delete_columns_list := lv_delete_columns_list || CHR(13) || CHR(10) || CHR(9) || CHR(9) || 'lv_detail := lv_detail || '' ' || rec_columns.column_name || ': "'' || TO_CHAR(:OLD.' || rec_columns.column_name || ') || ''"'';';
      END IF;
    END IF;

    -- first row set
    IF lb_first THEN lb_first := FALSE; END IF;
  END LOOP;
  
  -- get journal_type
  SELECT ID INTO ln_journal_type FROM GBC_JOURNAL_TYPE WHERE name_k = 'journal.' || REPLACE(LOWER(SUBSTR(av_table_name,5)),'_','');
  
  -- get app_user
  SELECT COUNT(*) INTO ln_created_by FROM user_tab_columns WHERE table_name = av_table_name AND column_name = 'CREATED_BY';
  SELECT COUNT(*) INTO ln_modified_by FROM user_tab_columns WHERE table_name = av_table_name AND column_name = 'MODIFIED_BY';

  lv_trg := 'CREATE OR REPLACE TRIGGER TRG_BIUD_#table_name#_AUDIT 
            BEFORE INSERT OR DELETE OR UPDATE OF #update_columns_list#
            ON #full_table_name#
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := ''I'';
            
                #insert_columns_list#
                
                #insert_app_user#
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := ''U'';
              
                #if_update_detail#
                
                IF SUBSTR(lv_detail,1,1) = '' '' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                #update_app_user#
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := ''D'';
                
                #delete_columns_list#
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, #journal_type#, lv_iud);
            END;';
    
    IF av_table_name <> 'GBC_UNIT_SET_SETTINGS_AP' THEN
      IF LENGTH(SUBSTR(av_table_name,5)) > 15 THEN
        lv_trg := REPLACE(lv_trg, '#table_name#', SUBSTR(REPLACE(av_table_name,'_',''),4,15));
      ELSE
        lv_trg := REPLACE(lv_trg, '#table_name#', SUBSTR(av_table_name,5));
      END IF;
    ELSE
      lv_trg := REPLACE(lv_trg, '#table_name#', 'UNTSETSETTAP');
    END IF;
    
    lv_trg := REPLACE(lv_trg, '#full_table_name#', av_table_name);
    lv_trg := REPLACE(lv_trg, '#update_columns_list#', lv_update_columns_list);
    lv_trg := REPLACE(lv_trg, '#insert_columns_list#', lv_insert_columns_list);
    lv_trg := REPLACE(lv_trg, '#if_update_detail#', lv_if_update_detail);
    lv_trg := REPLACE(lv_trg, '#delete_columns_list#', lv_delete_columns_list);
    lv_trg := REPLACE(lv_trg, '#journal_type#', ln_journal_type);
    
    IF ln_created_by = 1 THEN
      lv_trg := REPLACE(lv_trg, '#insert_app_user#', 'lv_app_user := :NEW.CREATED_BY;');
    ELSE
      lv_trg := REPLACE(lv_trg, '#insert_app_user#', '');
    END IF;
    
    IF ln_modified_by = 1 THEN
      lv_trg := REPLACE(lv_trg, '#update_app_user#', 'IF UPDATING(''MODIFIED_BY'') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;');
    ELSE
      lv_trg := REPLACE(lv_trg, '#update_app_user#', '');
    END IF;

    
    EXECUTE IMMEDIATE lv_trg;
    --DBMS_OUTPUT.PUT_LINE(lv_update_columns_list);
    --DBMS_OUTPUT.PUT_LINE(lv_insert_columns_list);
    --DBMS_OUTPUT.PUT_LINE(lv_if_update_detail);
    --DBMS_OUTPUT.PUT_LINE(lv_delete_columns_list);
    --DBMS_OUTPUT.PUT_LINE(lv_trg);
END;

/
