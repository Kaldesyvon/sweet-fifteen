--------------------------------------------------------
--  DDL for Procedure PR_ELIMINACIA_QUANTIT
--------------------------------------------------------
set define off;

-- todo NOT MIGRATED - ERROR


  CREATE OR REPLACE EDITIONABLE PROCEDURE "PR_ELIMINACIA_QUANTIT" AS
BEGIN
  -- Selecty a Inserty pouzite pre eliminaciu Quantit po konverzii dat z 3. fazy

/*
-- Neriesi viacurovnovu hierarchiu, riesi len Potomok -> Rodica!!!

-------------------------- GBC_ANALYSIS --------------------------
Insert Into GBC_ANALYSIS
  (ID, ID_MATERIAL_NODE, ID_ANALYSIS_PARAM, VALID_FROM,
    FACTOR_A, FACTOR_B, CREATED_BY, CREATED,
    MODIFIED_BY, MODIFIED, OBJ_VERSION, REMOTE_CODE,
    MEMO, ID_UNIT_NUMENATOR, ID_UNIT_DENOMINATOR, EDITABLE,
    VALID_TO, CALCULATED, ID_ANALYSIS)
  (Select ANALYSIS_SEQ.NextVal, MN_D.ID, A.ID_ANALYSIS_PARAM, A.VALID_FROM,
    A.FACTOR_A, A.FACTOR_B, A.CREATED_BY, A.CREATED,
    A.MODIFIED_BY, A.MODIFIED, A.OBJ_VERSION, A.REMOTE_CODE,
    A.MEMO, A.ID_UNIT_NUMENATOR, A.ID_UNIT_DENOMINATOR, A.EDITABLE,
    A.VALID_TO, A.CALCULATED, A.ID
  From      GBC_MATERIAL_NODE MN_D Join GBC_MATERIAL_NODE MN_R 
              On (MN_D.ID_INCLUDED_IN = MN_R.ID And MN_R.ID_INCLUDED_IN Is Null)
            Join GBC_ANALYSIS A On (MN_R.ID = A.ID_MATERIAL_NODE)
  )
;


-------------------------- GBC_QUANTITY --------------------------
Insert Into GBC_QUANTITY
    (ID, ID_MATERIAL_NODE, ID_UNIT, REMOTE_CODE, 
      QUANTITY, MEMO, CREATED_BY, CREATED, 
      MODIFIED_BY, MODIFIED, OBJ_VERSION, DATE_FROM, 
      DATE_TO, AUTO_ANALYSIS, EDITABLE, IO, 
      ID_MEASURE_POINT, ID_ELIMINATED)
  (Select     QUANTITY_SEQ.NextVal, MN.ID_INCLUDED_IN, Q.ID_UNIT, Q.REMOTE_CODE, 
              Q.QUANTITY * -1, Q.MEMO, Q.CREATED_BY, Q.CREATED, 
              Q.MODIFIED_BY, Q.MODIFIED, Q.OBJ_VERSION, Q.DATE_FROM, 
              Q.DATE_TO, Q.AUTO_ANALYSIS, Q.EDITABLE, Q.IO, 
              Q.ID_MEASURE_POINT, Q.ID
    From      GBC_QUANTITY Q Join GBC_MATERIAL_NODE MN On (Q.ID_MATERIAL_NODE = MN.ID)
    Where     MN.ID_INCLUDED_IN Is Not Null)
    ;  -- 1134
    

Update  GBC_QUANTITY 
  Set   HAS_ELIMINATIONS = 1
  Where ID In (Select ID_ELIMINATED From GBC_QUANTITY Where ID_ELIMINATED Is Not Null);

*/
  Null;
END PR_ELIMINACIA_QUANTIT;

/
