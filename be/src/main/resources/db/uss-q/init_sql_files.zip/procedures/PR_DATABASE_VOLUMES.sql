--------------------------------------------------------
--  DDL for Procedure PR_DATABASE_VOLUMES
--------------------------------------------------------
set define off;
-- todo NOT MIGRATED - ERROR

  CREATE OR REPLACE EDITIONABLE PROCEDURE "PR_DATABASE_VOLUMES" AS 

  /******************************************************************************************************************************
    NAME:       PR_DATABASE_VOLUMES
    PURPOSE:    Zaznamenavanie udajov ohladom rastu/klesania dat v databazach. 


    REVISIONS:
    Date        Author         Description
    ----------  -------------  -----------------------------------------------------------------------
    28.03.2019  Skokan         Procedure creation, for DB DM1 and EWA

  ******************************************************************************************************************************/

  ld_date       date;
  lv_command    varchar2(200);
  lv_note       database_volumes.note%type;
  lv_db_name    varchar2(30);

BEGIN

    ld_date := sysdate;
    --select name into lv_db_name from v$database;
    select sys_context('userenv','db_name') into lv_db_name from dual;
    
    update database_volumes set last_record_flag = null where last_record_flag = 'Y';

    insert into DATABASE_VOLUMES 
        (
          OWNER,
          SEGMENT_NAME,
          SEGMENT_TYPE,
          SIZE_MB,
          SNAPSHOT_DATE,
          DB_NAME,
          LAST_RECORD_FLAG
        )
        (
            select owner,
                   segment_name,
                   segment_type,
                   size_MB,
                   ld_date,
                   lv_db_name,
                   'Y'
            from
            (        
              SELECT owner,
                     segment_name,
                     segment_type,
                     round(SUM (bytes) / 1024 / 1024) size_MB
                FROM dba_extents
               WHERE owner NOT IN ('SYS',
                                   'SYSTEM',
                                   'DBSNMP',
                                   'XDB',
                                   'SYS_UTIL',
                                   'APEX_050100')                   
            GROUP BY owner, segment_name, segment_type
            ORDER BY SUM (bytes) / 1024 / 1024 DESC
            )
            where size_MB > 100
        )
  ;

  for l_rec in (select owner, segment_name from database_volumes where snapshot_date = ld_date and segment_type = 'TABLE')
    loop

      begin
        lv_command := 'update database_volumes set row_count = ' 
                        || '(select count(*) from ' || l_rec.owner || '.' || l_rec.segment_name || ')' 
                        || ' where segment_name = ' || '''' || l_rec.segment_name || '''';
        execute immediate lv_command;
      exception
        when others then
          lv_command := 'update database_volumes set note = ''' || sqlerrm || '''' || ' where segment_name = ' || '''' || l_rec.segment_name || '''';
          execute immediate lv_command;
          continue;
      end;        

    end loop;

    commit;

END PR_DATABASE_VOLUMES;

/
