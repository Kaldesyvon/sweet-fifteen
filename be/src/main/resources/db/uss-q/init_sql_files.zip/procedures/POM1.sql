--------------------------------------------------------
--  DDL for Procedure POM1
--------------------------------------------------------
set define off;
-- todo NOT MIGRATED - ERROR

  CREATE OR REPLACE EDITIONABLE PROCEDURE "POM1" AS
BEGIN
 DECLARE
  CURSOR c1 IS SELECT ID, NAME FROM GBC_UNIT_ANALYSIS_FORMAT;
  param_rec c1%ROWTYPE;
  nextId NUMBER;
BEGIN
	OPEN c1; 
	LOOP
	  FETCH c1 INTO param_rec;
  	  EXIT WHEN c1%NOTFOUND;
      BEGIN
       DBMS_OUTPUT.PUT_LINE ( param_rec.NAME );
       select dictionary_seq.nextval INTO nextId from dual;
       Insert into GBC_DICTIONARY (ID,ID_LANGUAGE,KEY,TRANSLATION,CREATED_BY,CREATED,OBJ_VERSION) 
                   values (nextId, 1, 'uaf.'||LOWER(param_rec.NAME),param_rec.NAME,'admin',SYSDATE,0);
       update GBC_UNIT_ANALYSIS_FORMAT set NAME = 'uaf.'||LOWER(param_rec.NAME) where id = param_rec.ID;
      END;  
	  END LOOP;
	CLOSE c1;
END;  
END POM1;

/
