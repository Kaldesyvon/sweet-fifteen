--------------------------------------------------------
--  DDL for Procedure SYNCHRO_MATERIALS
--------------------------------------------------------
set define off;
-- todo NOT MIGRATED - ERROR


  CREATE OR REPLACE EDITIONABLE PROCEDURE "SYNCHRO_MATERIALS" 
as
 c_id number;
begin
  for a in (select * from gbc_material@qbco2)
  loop
    c_id:=null;
    update gbc_material set
     CODE =a.code, 
     NAME=a.name, 
     MEMO=a.memo, 
     ID_UNIT_TYPE=a.id_unit_type, 
     CREATED_BY=a.created_by, 
     CREATED=a.created, 
     MODIFIED_BY=a.modified_by, 
     MODIFIED=a.modified, 
     PRODUCT=a.product, 
     REPORT_POS=a.report_pos, 
     IO=a.io, 
     OBJ_VERSION=a.obj_version, 
     BEST_PRACTICES_MATERIAL=a.BEST_PRACTICES_MATERIAL, 
     MATERIAL_REPORT=a.MATERIAL_REPORT
    where id=a.id
    returning id into c_id; 
    if c_id is null then
     insert into gbc_material(ID, CODE, NAME, MEMO, ID_UNIT_TYPE, CREATED_BY, CREATED, MODIFIED_BY, MODIFIED, PRODUCT, REPORT_POS, IO, OBJ_VERSION, BEST_PRACTICES_MATERIAL, MATERIAL_REPORT)
       values (a.ID, a.CODE, a.NAME, a.MEMO, a.ID_UNIT_TYPE, a.CREATED_BY, a.CREATED, a.MODIFIED_BY, a.MODIFIED, a.PRODUCT, a.REPORT_POS, a.IO, a.OBJ_VERSION, a.BEST_PRACTICES_MATERIAL, a.MATERIAL_REPORT);
    end if;
    dbms_output.put_line('mID: '||a.id||'  '||c_id);
    material_check(a.id, a.id_unit_type);
  end loop;
  delete gbc_material_fl;
  insert into gbc_material_fl select * from gbc_material_fl@qbco2;
  delete gbc_material_plant;
  insert into gbc_material_plant 
    select ID, ID_PLANT, ID_MATERIAL, PRODUCT, CREATED_BY, CREATED, 
           MODIFIED_BY, MODIFIED, OBJ_VERSION, MEMO, null, null
      from gbc_material_plant@qbco2;
end; 

/
