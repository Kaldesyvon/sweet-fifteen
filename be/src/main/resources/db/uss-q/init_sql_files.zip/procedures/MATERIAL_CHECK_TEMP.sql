--------------------------------------------------------
--  DDL for Procedure MATERIAL_CHECK_TEMP
--------------------------------------------------------
set define off;
-- todo NOT MIGRATED - ERROR


  CREATE OR REPLACE EDITIONABLE PROCEDURE "MATERIAL_CHECK_TEMP" 
as
begin
  for a in (select * from gbc_material)
  loop
  	material_check(a.id, a.id_unit_type);
  end loop;
end;

/
