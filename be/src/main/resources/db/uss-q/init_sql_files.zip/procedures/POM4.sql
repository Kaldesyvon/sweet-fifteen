--------------------------------------------------------
--  DDL for Procedure POM4
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "POM4" AS
BEGIN
 DECLARE
  CURSOR c1 IS SELECT ID, CODE FROM gbc_param;
  param_rec c1%ROWTYPE;
  nextId NUMBER;
BEGIN
	OPEN c1; 
	LOOP
	  FETCH c1 INTO param_rec;
  	  EXIT WHEN c1%NOTFOUND;
      BEGIN
       --DBMS_OUTPUT.PUT_LINE ( param_rec.NAME );
       --select dictionary_seq.nextval INTO nextId from dual;
       --Insert into GBC_DICTIONARY (ID,ID_LANGUAGE,KEY,TRANSLATION,CREATED_BY,CREATED,OBJ_VERSION) 
       --            values (nextId, 1, 'ap.'||LOWER(param_rec.NAME),param_rec.NAME,'admin',SYSDATE,0);
       update gbc_dictionary set gbc_dictionary.KEY = 'plantRegion.'||param_rec.CODE where key = param_rec.CODE;
       update gbc_param set CODE = 'param.'||param_rec.CODE where id = param_rec.ID;

       --update gbc_dictionary set gbc_dictionary.KEY = 'unitType.'||param_rec.MEMO where key = param_rec.MEMO;
       --update gbc_role set MEMO = 'role.'||param_rec.MEMO where id = param_rec.ID;
      END;  
	  END LOOP;
	CLOSE c1;
END;  
END POM4;

/
