--------------------------------------------------------
--  DDL for Procedure SYNCHRO_PLANTS
--------------------------------------------------------
set define off;
-- todo NOT MIGRATED - ERROR

  CREATE OR REPLACE EDITIONABLE PROCEDURE "SYNCHRO_PLANTS" 
as
 c_id number;
begin
 for a in (select * from gbc_plant@qbco2)
 loop
  c_id:=null;
  update gbc_plant set
   CODE=a.code, 
   NAME=a.name, 
   MEMO=a.memo, 
   --TIME_ZONE=a.time_zone, 
   CREATED=a.created, 
   MODIFIED_BY=a.MODIFIED_BY, 
   MODIFIED=a.modified, 
   OBJ_VERSION=a.obj_version, 
   ID_TYPE=a.id_type, 
   ID_REGION=a.id_region, 
   REPORT_POS =a.report_pos, 
   VALID_FROM=to_date('01012005', 'DDMMYYYY'), 
   VALID_TO=null
  where id=a.id
  returning id into c_id; 
  if c_id is null then
    insert into gbc_plant(ID, CODE, NAME, MEMO, TIME_ZONE, CREATED_BY, CREATED, MODIFIED_BY, MODIFIED, OBJ_VERSION, ID_TYPE, ID_REGION, REPORT_POS, VALID_FROM, VALID_TO)
      values (a.ID, a.CODE, a.NAME, a.MEMO, a.TIME_ZONE, a.CREATED_BY, a.CREATED, a.MODIFIED_BY, a.MODIFIED, a.OBJ_VERSION, a.ID_TYPE, a.ID_REGION, a.REPORT_POS, to_date('01012005', 'DDMMYYYY'), null);
  end if;
 end loop;
end; 

/
