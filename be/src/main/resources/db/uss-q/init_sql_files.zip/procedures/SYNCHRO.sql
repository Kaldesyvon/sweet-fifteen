--------------------------------------------------------
--  DDL for Procedure SYNCHRO
--------------------------------------------------------
set define off;
-- todo NOT MIGRATED - ERROR

  CREATE OR REPLACE EDITIONABLE PROCEDURE "SYNCHRO" 
as
begin
 delete gbc_analysis;
 delete gbc_quantity;
 delete gbc_scope;
 delete gbc_production_plan;
 synchro_plants;
 synchro_materials;
 synchro_analysis;
 synchro_scope;
-- commit;
end; 

/
