--------------------------------------------------------
--  DDL for Procedure SYNCHRO_ANALYSIS
--------------------------------------------------------
set define off;
-- todo NOT MIGRATED - ERROR

  CREATE OR REPLACE EDITIONABLE PROCEDURE "SYNCHRO_ANALYSIS" 
as
 ide number;
begin
 for a in (select analysis_seq.nextval idc, q.id_material_plant, q.month,
               q.carbon_factor, q.carbon_factor2, q.created_by, q.CREATED, q.MODIFIED_BY, 
               q.MODIFIED, q.OBJ_VERSION, q.REMOTE_CODE, q.MEMO,  
               decode(q.id_unit, 1, 1,
                                  2, 2,
                               3, 1,
                               4, 2,
                               5, 1,
                               6, 2,
                               7, 1,
                               8, 2,
                               9, 1,
                               10, 2) idnc,       
               decode(q.id_unit, 1, 1,
                                  2, 2,
                               3, 3,
                               4, 4,
                               5, 5,
                               6, 5,
                               7, 7,
                               8, 8,
                               9, 9,
                               10, 10)idd,
                quantity_seq.nextval idq, q.id_unit, q.quantity, 
                last_day(q.month)+1-1/86400 date_to,
                q.energy_factor, q.energy_factor2, 
               decode(q.id_unit, 1, 9,
                                  2, 10,
                               3, 9,
                               4, 10,
                               5, 9,
                               6, 10,
                               7, 9,
                               8, 10,
                               9, 9,
                               10, 10) idne, mp.ID_PLANT
          from gbc_quantity@qbco2 q, gbc_material_plant mp
          where q.ID_MATERIAL_PLANT=mp.id
        )
 loop
  select analysis_seq.nextval into ide from dual;
--  dbms_output.put_line(a.idc||'    '||ide);
  insert into gbc_analysis(ID, ID_MATERIAL_PLANT, ID_ANALYSIS_PARAM, VALID_FROM, FACTOR_A, FACTOR_B, CREATED_BY, CREATED, MODIFIED_BY, MODIFIED, OBJ_VERSION, REMOTE_CODE, MEMO, ID_UNIT_NUMENATOR, ID_UNIT_DENOMINATOR, EDITABLE)
    values(a.idc, a.id_material_plant, 1, a.month, a.carbon_factor, a.carbon_factor2, a.CREATED_BY, a.CREATED, a.MODIFIED_BY, a.MODIFIED, a.OBJ_VERSION, a.REMOTE_CODE, a.MEMO, a.idnc, a.idd, decode(a.remote_code, null, 1, decode(a.id_plant, 9, 0, 1)));
  insert into gbc_analysis(ID, ID_MATERIAL_PLANT, ID_ANALYSIS_PARAM, VALID_FROM, FACTOR_A, FACTOR_B, CREATED_BY, CREATED, MODIFIED_BY, MODIFIED, OBJ_VERSION, REMOTE_CODE, MEMO, ID_UNIT_NUMENATOR, ID_UNIT_DENOMINATOR, EDITABLE)
    values(ide, a.id_material_plant, 2, a.month, a.energy_factor, a.energy_factor2, a.CREATED_BY, a.CREATED, a.MODIFIED_BY, a.MODIFIED, a.OBJ_VERSION, a.REMOTE_CODE, a.MEMO, a.idne, a.idd, decode(a.remote_code, null, 1, decode(a.id_plant, 9, 0, 1)));
  insert into gbc_quantity(ID, ID_MATERIAL_PLANT, ID_UNIT, REMOTE_CODE, QUANTITY, MEMO, CREATED_BY, CREATED, MODIFIED_BY, MODIFIED, OBJ_VERSION, DATE_FROM, DATE_TO, AUTO_ANALYSIS, EDITABLE)
    values(a.idq, a.id_material_plant, a.idd, a.REMOTE_CODE, a.quantity, a.MEMO, a.CREATED_BY, a.CREATED, a.MODIFIED_BY, a.MODIFIED, a.OBJ_VERSION, a.month, a.date_to, 0, decode(a.remote_code, null, 1, decode(a.id_plant, 9, 0, 1)));
  insert into gbc_quantity_analysis(ID, ID_QUANTITY, ID_ANALYSIS, ID_ANALYSIS_PARAM, CREATED_BY, CREATED, MODIFIED_BY, MODIFIED, OBJ_VERSION, REMOTE_CODE)
    values(quantity_analysis_seq.nextval, a.idq, a.idc, 1, a.CREATED_BY, a.CREATED, a.MODIFIED_BY, a.MODIFIED, a.OBJ_VERSION, a.REMOTE_CODE);
  insert into gbc_quantity_analysis(ID, ID_QUANTITY, ID_ANALYSIS, ID_ANALYSIS_PARAM, CREATED_BY, CREATED, MODIFIED_BY, MODIFIED, OBJ_VERSION, REMOTE_CODE)
    values(quantity_analysis_seq.nextval, a.idq, ide, 2, a.CREATED_BY, a.CREATED, a.MODIFIED_BY, a.MODIFIED, a.OBJ_VERSION, a.REMOTE_CODE);
 end loop;
end; 

/
