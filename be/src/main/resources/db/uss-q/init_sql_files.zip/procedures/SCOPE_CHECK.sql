--------------------------------------------------------
--  DDL for Procedure SCOPE_CHECK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "SCOPE_CHECK" (ID_SCOPE_PAR number) AS
  nextId NUMBER;
  noOfRecords2 NUMBER;
  noOfRecords NUMBER;
BEGIN

  select count(*) into noOfRecords from GBC_SCOPE_ANALYSIS_PARAM where id_scope = ID_SCOPE_PAR;
  IF (noOfRecords = 0) THEN
    select SCOPE_ANALYSIS_PARAM_seq.nextval INTO nextId from dual;
    Insert into GBC_SCOPE_ANALYSIS_PARAM  (ID,ID_SCOPE,ID_ANALYSIS_PARAM,CREATED_BY,CREATED,OBJ_VERSION) 
                                      values (nextId,ID_SCOPE_PAR, 1, 'admin', SYSDATE, 0);
   
    select SCOPE_ANALYSIS_PARAM_seq.nextval INTO nextId from dual;
    Insert into GBC_SCOPE_ANALYSIS_PARAM  (ID,ID_SCOPE,ID_ANALYSIS_PARAM,CREATED_BY,CREATED,OBJ_VERSION) 
                                      values (nextId,ID_SCOPE_PAR, 2, 'admin', SYSDATE, 0);

    select SCOPE_ANALYSIS_PARAM_seq.nextval INTO nextId from dual;
    Insert into GBC_SCOPE_ANALYSIS_PARAM  (ID,ID_SCOPE,ID_ANALYSIS_PARAM,CREATED_BY,CREATED,OBJ_VERSION) 
                                      values (nextId,ID_SCOPE_PAR, 4, 'admin', SYSDATE, 0);
  END IF;
  
  
  select count(*) into noOfRecords2 from GBC_SCOPE_DENOMINATOR  where id_scope = ID_SCOPE_PAR;
  IF (noOfRecords2 = 0) THEN

    select SCOPE_DENOMINATOR_seq.nextval INTO nextId from dual;

    Insert into GBC_SCOPE_DENOMINATOR 
      (ID,ID_SCOPE,ID_MATERIAL,CREATED_BY,CREATED,OBJ_VERSION) values 
      (nextId, ID_SCOPE_PAR, 25, 'admin', SYSDATE, 0);
    
  END IF;
 
END SCOPE_CHECK; 

/
