--------------------------------------------------------
--  DDL for Procedure SYNCHRO_SCOPE
--------------------------------------------------------
set define off;
-- todo NOT MIGRATED - ERROR

  CREATE OR REPLACE EDITIONABLE PROCEDURE "SYNCHRO_SCOPE" 
as
begin
 insert into gbc_scope
  select ID, NAME, MEMO, OBJ_VERSION, 
           CREATED_BY, CREATED, MODIFIED_BY, 
         MODIFIED, ADMIN_ONLY
    from gbc_scope@qbco2
   where id!=57;
 insert into gbc_scope_material
  select ID, ID_SCOPE, ID_MATERIAL, FACTOR1, 
           FACTOR2, OBJ_VERSION, CREATED_BY, CREATED, 
         MODIFIED_BY, MODIFIED 
    from gbc_scope_material@qbco2
   where id_scope!=57;
 for a in (select id from gbc_scope)
 loop
  scope_check(a.id);
 end loop;
end; 

/
