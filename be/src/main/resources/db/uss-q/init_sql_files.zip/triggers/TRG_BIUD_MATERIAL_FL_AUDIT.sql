--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_MATERIAL_FL_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_MATERIAL_FL_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_MASTER,ID_LANGUAGE,NAME
            ON GBC_MATERIAL_FL
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_MASTER: "' || TO_CHAR(:NEW.ID_MASTER) || '"';
		lv_detail := lv_detail || ' ID_LANGUAGE: "' || TO_CHAR(:NEW.ID_LANGUAGE) || '"';
		lv_detail := lv_detail || ' NAME: "' || :NEW.NAME || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_MASTER') AND :NEW.ID_MASTER <> :OLD.ID_MASTER THEN lv_detail := lv_detail || ' ID_MASTER: "' || TO_CHAR(:OLD.ID_MASTER) || '"->"' || TO_CHAR(:NEW.ID_MASTER) || '"'; END IF;
		IF UPDATING('ID_LANGUAGE') AND :NEW.ID_LANGUAGE <> :OLD.ID_LANGUAGE THEN lv_detail := lv_detail || ' ID_LANGUAGE: "' || TO_CHAR(:OLD.ID_LANGUAGE) || '"->"' || TO_CHAR(:NEW.ID_LANGUAGE) || '"'; END IF;
		IF UPDATING('NAME') AND :NEW.NAME <> :OLD.NAME THEN lv_detail := lv_detail || ' NAME: "' || :OLD.NAME || '"->"' || :NEW.NAME || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_MASTER: "' || TO_CHAR(:OLD.ID_MASTER) || '"';
		lv_detail := lv_detail || ' ID_LANGUAGE: "' || TO_CHAR(:OLD.ID_LANGUAGE) || '"';
		lv_detail := lv_detail || ' NAME: "' || :OLD.NAME || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 20, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_MATERIAL_FL_AUDIT" ENABLE;
