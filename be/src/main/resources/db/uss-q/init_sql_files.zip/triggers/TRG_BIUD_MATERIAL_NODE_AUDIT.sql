--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_MATERIAL_NODE_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_MATERIAL_NODE_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_NODE,ID_MATERIAL,MEMO,PRODUCT,INPUT,OUTPUT,NAME,TIER,CARBON_MIN,CARBON_MAX,COMMON_PIPE_PARENT,COMMON_PIPE_ID,NOTE1,NOTE2,NOTE3
            ON GBC_MATERIAL_NODE
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_NODE: "' || TO_CHAR(:NEW.ID_NODE) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL: "' || TO_CHAR(:NEW.ID_MATERIAL) || '"';
		lv_detail := lv_detail || ' MEMO: "' || :NEW.MEMO || '"';
		lv_detail := lv_detail || ' PRODUCT: "' || TO_CHAR(:NEW.PRODUCT) || '"';
		lv_detail := lv_detail || ' INPUT: "' || TO_CHAR(:NEW.INPUT) || '"';
		lv_detail := lv_detail || ' OUTPUT: "' || TO_CHAR(:NEW.OUTPUT) || '"';
		lv_detail := lv_detail || ' NAME: "' || :NEW.NAME || '"';
		lv_detail := lv_detail || ' TIER: "' || TO_CHAR(:NEW.TIER) || '"';
		lv_detail := lv_detail || ' CARBON_MIN: "' || TO_CHAR(:NEW.CARBON_MIN) || '"';
		lv_detail := lv_detail || ' CARBON_MAX: "' || TO_CHAR(:NEW.CARBON_MAX) || '"';
		lv_detail := lv_detail || ' COMMON_PIPE_PARENT: "' || TO_CHAR(:NEW.COMMON_PIPE_PARENT) || '"';
		lv_detail := lv_detail || ' COMMON_PIPE_ID: "' || :NEW.COMMON_PIPE_ID || '"';
		lv_detail := lv_detail || ' NOTE1: "' || :NEW.NOTE1 || '"';
		lv_detail := lv_detail || ' NOTE2: "' || :NEW.NOTE2 || '"';
		lv_detail := lv_detail || ' NOTE3: "' || :NEW.NOTE3 || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_NODE') AND :NEW.ID_NODE <> :OLD.ID_NODE THEN lv_detail := lv_detail || ' ID_NODE: "' || TO_CHAR(:OLD.ID_NODE) || '"->"' || TO_CHAR(:NEW.ID_NODE) || '"'; END IF;
		IF UPDATING('ID_MATERIAL') AND :NEW.ID_MATERIAL <> :OLD.ID_MATERIAL THEN lv_detail := lv_detail || ' ID_MATERIAL: "' || TO_CHAR(:OLD.ID_MATERIAL) || '"->"' || TO_CHAR(:NEW.ID_MATERIAL) || '"'; END IF;
		IF UPDATING('MEMO') AND (:NEW.MEMO <> :OLD.MEMO OR (:NEW.MEMO IS NOT NULL AND :OLD.MEMO IS NULL) OR (:NEW.MEMO IS NULL AND :OLD.MEMO IS NOT NULL)) THEN lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"->"' || :NEW.MEMO || '"'; END IF;
		IF UPDATING('PRODUCT') AND :NEW.PRODUCT <> :OLD.PRODUCT THEN lv_detail := lv_detail || ' PRODUCT: "' || TO_CHAR(:OLD.PRODUCT) || '"->"' || TO_CHAR(:NEW.PRODUCT) || '"'; END IF;
		IF UPDATING('INPUT') AND :NEW.INPUT <> :OLD.INPUT THEN lv_detail := lv_detail || ' INPUT: "' || TO_CHAR(:OLD.INPUT) || '"->"' || TO_CHAR(:NEW.INPUT) || '"'; END IF;
		IF UPDATING('OUTPUT') AND :NEW.OUTPUT <> :OLD.OUTPUT THEN lv_detail := lv_detail || ' OUTPUT: "' || TO_CHAR(:OLD.OUTPUT) || '"->"' || TO_CHAR(:NEW.OUTPUT) || '"'; END IF;
		IF UPDATING('NAME') AND (:NEW.NAME <> :OLD.NAME OR (:NEW.NAME IS NOT NULL AND :OLD.NAME IS NULL) OR (:NEW.NAME IS NULL AND :OLD.NAME IS NOT NULL)) THEN lv_detail := lv_detail || ' NAME: "' || :OLD.NAME || '"->"' || :NEW.NAME || '"'; END IF;
		IF UPDATING('TIER') AND (:NEW.TIER <> :OLD.TIER OR (:NEW.TIER IS NOT NULL AND :OLD.TIER IS NULL) OR (:NEW.TIER IS NULL AND :OLD.TIER IS NOT NULL)) THEN lv_detail := lv_detail || ' TIER: "' || TO_CHAR(:OLD.TIER) || '"->"' || TO_CHAR(:NEW.TIER) || '"'; END IF;
		IF UPDATING('CARBON_MIN') AND (:NEW.CARBON_MIN <> :OLD.CARBON_MIN OR (:NEW.CARBON_MIN IS NOT NULL AND :OLD.CARBON_MIN IS NULL) OR (:NEW.CARBON_MIN IS NULL AND :OLD.CARBON_MIN IS NOT NULL)) THEN lv_detail := lv_detail || ' CARBON_MIN: "' || TO_CHAR(:OLD.CARBON_MIN) || '"->"' || TO_CHAR(:NEW.CARBON_MIN) || '"'; END IF;
		IF UPDATING('CARBON_MAX') AND (:NEW.CARBON_MAX <> :OLD.CARBON_MAX OR (:NEW.CARBON_MAX IS NOT NULL AND :OLD.CARBON_MAX IS NULL) OR (:NEW.CARBON_MAX IS NULL AND :OLD.CARBON_MAX IS NOT NULL)) THEN lv_detail := lv_detail || ' CARBON_MAX: "' || TO_CHAR(:OLD.CARBON_MAX) || '"->"' || TO_CHAR(:NEW.CARBON_MAX) || '"'; END IF;
		IF UPDATING('COMMON_PIPE_PARENT') AND (:NEW.COMMON_PIPE_PARENT <> :OLD.COMMON_PIPE_PARENT OR (:NEW.COMMON_PIPE_PARENT IS NOT NULL AND :OLD.COMMON_PIPE_PARENT IS NULL) OR (:NEW.COMMON_PIPE_PARENT IS NULL AND :OLD.COMMON_PIPE_PARENT IS NOT NULL)) THEN lv_detail := lv_detail || ' COMMON_PIPE_PARENT: "' || TO_CHAR(:OLD.COMMON_PIPE_PARENT) || '"->"' || TO_CHAR(:NEW.COMMON_PIPE_PARENT) || '"'; END IF;
		IF UPDATING('COMMON_PIPE_ID') AND (:NEW.COMMON_PIPE_ID <> :OLD.COMMON_PIPE_ID OR (:NEW.COMMON_PIPE_ID IS NOT NULL AND :OLD.COMMON_PIPE_ID IS NULL) OR (:NEW.COMMON_PIPE_ID IS NULL AND :OLD.COMMON_PIPE_ID IS NOT NULL)) THEN lv_detail := lv_detail || ' COMMON_PIPE_ID: "' || :OLD.COMMON_PIPE_ID || '"->"' || :NEW.COMMON_PIPE_ID || '"'; END IF;
		IF UPDATING('NOTE1') AND (:NEW.NOTE1 <> :OLD.NOTE1 OR (:NEW.NOTE1 IS NOT NULL AND :OLD.NOTE1 IS NULL) OR (:NEW.NOTE1 IS NULL AND :OLD.NOTE1 IS NOT NULL)) THEN lv_detail := lv_detail || ' NOTE1: "' || :OLD.NOTE1 || '"->"' || :NEW.NOTE1 || '"'; END IF;
		IF UPDATING('NOTE2') AND (:NEW.NOTE2 <> :OLD.NOTE2 OR (:NEW.NOTE2 IS NOT NULL AND :OLD.NOTE2 IS NULL) OR (:NEW.NOTE2 IS NULL AND :OLD.NOTE2 IS NOT NULL)) THEN lv_detail := lv_detail || ' NOTE2: "' || :OLD.NOTE2 || '"->"' || :NEW.NOTE2 || '"'; END IF;
		IF UPDATING('NOTE3') AND (:NEW.NOTE3 <> :OLD.NOTE3 OR (:NEW.NOTE3 IS NOT NULL AND :OLD.NOTE3 IS NULL) OR (:NEW.NOTE3 IS NULL AND :OLD.NOTE3 IS NOT NULL)) THEN lv_detail := lv_detail || ' NOTE3: "' || :OLD.NOTE3 || '"->"' || :NEW.NOTE3 || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_NODE: "' || TO_CHAR(:OLD.ID_NODE) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL: "' || TO_CHAR(:OLD.ID_MATERIAL) || '"';
		lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"';
		lv_detail := lv_detail || ' PRODUCT: "' || TO_CHAR(:OLD.PRODUCT) || '"';
		lv_detail := lv_detail || ' INPUT: "' || TO_CHAR(:OLD.INPUT) || '"';
		lv_detail := lv_detail || ' OUTPUT: "' || TO_CHAR(:OLD.OUTPUT) || '"';
		lv_detail := lv_detail || ' NAME: "' || :OLD.NAME || '"';
		lv_detail := lv_detail || ' TIER: "' || TO_CHAR(:OLD.TIER) || '"';
		lv_detail := lv_detail || ' CARBON_MIN: "' || TO_CHAR(:OLD.CARBON_MIN) || '"';
		lv_detail := lv_detail || ' CARBON_MAX: "' || TO_CHAR(:OLD.CARBON_MAX) || '"';
		lv_detail := lv_detail || ' COMMON_PIPE_PARENT: "' || TO_CHAR(:OLD.COMMON_PIPE_PARENT) || '"';
		lv_detail := lv_detail || ' COMMON_PIPE_ID: "' || :OLD.COMMON_PIPE_ID || '"';
		lv_detail := lv_detail || ' NOTE1: "' || :OLD.NOTE1 || '"';
		lv_detail := lv_detail || ' NOTE2: "' || :OLD.NOTE2 || '"';
		lv_detail := lv_detail || ' NOTE3: "' || :OLD.NOTE3 || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 21, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_MATERIAL_NODE_AUDIT" ENABLE;
