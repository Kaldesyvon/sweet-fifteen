--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_PRODUCTION_PLAN_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_PRODUCTION_PLAN_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_MATERIAL_NODE,MONTH,ID_UNIT,MEMO,QUANTITY
            ON GBC_PRODUCTION_PLAN
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL_NODE: "' || TO_CHAR(:NEW.ID_MATERIAL_NODE) || '"';
		lv_detail := lv_detail || ' MONTH: "' || TO_CHAR(:NEW.MONTH) || '"';
		lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:NEW.ID_UNIT) || '"';
		lv_detail := lv_detail || ' MEMO: "' || :NEW.MEMO || '"';
		lv_detail := lv_detail || ' QUANTITY: "' || TO_CHAR(:NEW.QUANTITY) || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_MATERIAL_NODE') AND (:NEW.ID_MATERIAL_NODE <> :OLD.ID_MATERIAL_NODE OR (:NEW.ID_MATERIAL_NODE IS NOT NULL AND :OLD.ID_MATERIAL_NODE IS NULL) OR (:NEW.ID_MATERIAL_NODE IS NULL AND :OLD.ID_MATERIAL_NODE IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_MATERIAL_NODE: "' || TO_CHAR(:OLD.ID_MATERIAL_NODE) || '"->"' || TO_CHAR(:NEW.ID_MATERIAL_NODE) || '"'; END IF;
		IF UPDATING('MONTH') AND :NEW.MONTH <> :OLD.MONTH THEN lv_detail := lv_detail || ' MONTH: "' || TO_CHAR(:OLD.MONTH) || '"->"' || TO_CHAR(:NEW.MONTH) || '"'; END IF;
		IF UPDATING('ID_UNIT') AND :NEW.ID_UNIT <> :OLD.ID_UNIT THEN lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:OLD.ID_UNIT) || '"->"' || TO_CHAR(:NEW.ID_UNIT) || '"'; END IF;
		IF UPDATING('MEMO') AND (:NEW.MEMO <> :OLD.MEMO OR (:NEW.MEMO IS NOT NULL AND :OLD.MEMO IS NULL) OR (:NEW.MEMO IS NULL AND :OLD.MEMO IS NOT NULL)) THEN lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"->"' || :NEW.MEMO || '"'; END IF;
		IF UPDATING('QUANTITY') AND :NEW.QUANTITY <> :OLD.QUANTITY THEN lv_detail := lv_detail || ' QUANTITY: "' || TO_CHAR(:OLD.QUANTITY) || '"->"' || TO_CHAR(:NEW.QUANTITY) || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL_NODE: "' || TO_CHAR(:OLD.ID_MATERIAL_NODE) || '"';
		lv_detail := lv_detail || ' MONTH: "' || TO_CHAR(:OLD.MONTH) || '"';
		lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:OLD.ID_UNIT) || '"';
		lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"';
		lv_detail := lv_detail || ' QUANTITY: "' || TO_CHAR(:OLD.QUANTITY) || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 25, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_PRODUCTION_PLAN_AUDIT" ENABLE;
