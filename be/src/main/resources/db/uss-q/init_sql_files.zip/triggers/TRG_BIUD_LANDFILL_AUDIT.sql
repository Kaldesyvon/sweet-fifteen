--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_LANDFILL_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_LANDFILL_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,NAME,STATUS,OPENED_DATE,PROJECTED_CLOSE_DATE,CAPACITY,ID_UNIT,LEACHATE_RECIRCULATION,PASSIVE_VENTS_FLARES,LANDFILL_COVER_DESCRIPTION,NOTE_1,NOTE_2,NOTE_3
            ON GBC_LANDFILL
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' NAME: "' || :NEW.NAME || '"';
		lv_detail := lv_detail || ' STATUS: "' || :NEW.STATUS || '"';
		lv_detail := lv_detail || ' OPENED_DATE: "' || TO_CHAR(:NEW.OPENED_DATE) || '"';
		lv_detail := lv_detail || ' PROJECTED_CLOSE_DATE: "' || TO_CHAR(:NEW.PROJECTED_CLOSE_DATE) || '"';
		lv_detail := lv_detail || ' CAPACITY: "' || TO_CHAR(:NEW.CAPACITY) || '"';
		lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:NEW.ID_UNIT) || '"';
		lv_detail := lv_detail || ' LEACHATE_RECIRCULATION: "' || TO_CHAR(:NEW.LEACHATE_RECIRCULATION) || '"';
		lv_detail := lv_detail || ' PASSIVE_VENTS_FLARES: "' || TO_CHAR(:NEW.PASSIVE_VENTS_FLARES) || '"';
		lv_detail := lv_detail || ' LANDFILL_COVER_DESCRIPTION: "' || :NEW.LANDFILL_COVER_DESCRIPTION || '"';
		lv_detail := lv_detail || ' NOTE_1: "' || :NEW.NOTE_1 || '"';
		lv_detail := lv_detail || ' NOTE_2: "' || :NEW.NOTE_2 || '"';
		lv_detail := lv_detail || ' NOTE_3: "' || :NEW.NOTE_3 || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('NAME') AND :NEW.NAME <> :OLD.NAME THEN lv_detail := lv_detail || ' NAME: "' || :OLD.NAME || '"->"' || :NEW.NAME || '"'; END IF;
		IF UPDATING('STATUS') AND :NEW.STATUS <> :OLD.STATUS THEN lv_detail := lv_detail || ' STATUS: "' || :OLD.STATUS || '"->"' || :NEW.STATUS || '"'; END IF;
		IF UPDATING('OPENED_DATE') AND :NEW.OPENED_DATE <> :OLD.OPENED_DATE THEN lv_detail := lv_detail || ' OPENED_DATE: "' || TO_CHAR(:OLD.OPENED_DATE) || '"->"' || TO_CHAR(:NEW.OPENED_DATE) || '"'; END IF;
		IF UPDATING('PROJECTED_CLOSE_DATE') AND :NEW.PROJECTED_CLOSE_DATE <> :OLD.PROJECTED_CLOSE_DATE THEN lv_detail := lv_detail || ' PROJECTED_CLOSE_DATE: "' || TO_CHAR(:OLD.PROJECTED_CLOSE_DATE) || '"->"' || TO_CHAR(:NEW.PROJECTED_CLOSE_DATE) || '"'; END IF;
		IF UPDATING('CAPACITY') AND :NEW.CAPACITY <> :OLD.CAPACITY THEN lv_detail := lv_detail || ' CAPACITY: "' || TO_CHAR(:OLD.CAPACITY) || '"->"' || TO_CHAR(:NEW.CAPACITY) || '"'; END IF;
		IF UPDATING('ID_UNIT') AND :NEW.ID_UNIT <> :OLD.ID_UNIT THEN lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:OLD.ID_UNIT) || '"->"' || TO_CHAR(:NEW.ID_UNIT) || '"'; END IF;
		IF UPDATING('LEACHATE_RECIRCULATION') AND :NEW.LEACHATE_RECIRCULATION <> :OLD.LEACHATE_RECIRCULATION THEN lv_detail := lv_detail || ' LEACHATE_RECIRCULATION: "' || TO_CHAR(:OLD.LEACHATE_RECIRCULATION) || '"->"' || TO_CHAR(:NEW.LEACHATE_RECIRCULATION) || '"'; END IF;
		IF UPDATING('PASSIVE_VENTS_FLARES') AND :NEW.PASSIVE_VENTS_FLARES <> :OLD.PASSIVE_VENTS_FLARES THEN lv_detail := lv_detail || ' PASSIVE_VENTS_FLARES: "' || TO_CHAR(:OLD.PASSIVE_VENTS_FLARES) || '"->"' || TO_CHAR(:NEW.PASSIVE_VENTS_FLARES) || '"'; END IF;
		IF UPDATING('LANDFILL_COVER_DESCRIPTION') AND :NEW.LANDFILL_COVER_DESCRIPTION <> :OLD.LANDFILL_COVER_DESCRIPTION THEN lv_detail := lv_detail || ' LANDFILL_COVER_DESCRIPTION: "' || :OLD.LANDFILL_COVER_DESCRIPTION || '"->"' || :NEW.LANDFILL_COVER_DESCRIPTION || '"'; END IF;
		IF UPDATING('NOTE_1') AND (:NEW.NOTE_1 <> :OLD.NOTE_1 OR (:NEW.NOTE_1 IS NOT NULL AND :OLD.NOTE_1 IS NULL) OR (:NEW.NOTE_1 IS NULL AND :OLD.NOTE_1 IS NOT NULL)) THEN lv_detail := lv_detail || ' NOTE_1: "' || :OLD.NOTE_1 || '"->"' || :NEW.NOTE_1 || '"'; END IF;
		IF UPDATING('NOTE_2') AND (:NEW.NOTE_2 <> :OLD.NOTE_2 OR (:NEW.NOTE_2 IS NOT NULL AND :OLD.NOTE_2 IS NULL) OR (:NEW.NOTE_2 IS NULL AND :OLD.NOTE_2 IS NOT NULL)) THEN lv_detail := lv_detail || ' NOTE_2: "' || :OLD.NOTE_2 || '"->"' || :NEW.NOTE_2 || '"'; END IF;
		IF UPDATING('NOTE_3') AND (:NEW.NOTE_3 <> :OLD.NOTE_3 OR (:NEW.NOTE_3 IS NOT NULL AND :OLD.NOTE_3 IS NULL) OR (:NEW.NOTE_3 IS NULL AND :OLD.NOTE_3 IS NOT NULL)) THEN lv_detail := lv_detail || ' NOTE_3: "' || :OLD.NOTE_3 || '"->"' || :NEW.NOTE_3 || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' NAME: "' || :OLD.NAME || '"';
		lv_detail := lv_detail || ' STATUS: "' || :OLD.STATUS || '"';
		lv_detail := lv_detail || ' OPENED_DATE: "' || TO_CHAR(:OLD.OPENED_DATE) || '"';
		lv_detail := lv_detail || ' PROJECTED_CLOSE_DATE: "' || TO_CHAR(:OLD.PROJECTED_CLOSE_DATE) || '"';
		lv_detail := lv_detail || ' CAPACITY: "' || TO_CHAR(:OLD.CAPACITY) || '"';
		lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:OLD.ID_UNIT) || '"';
		lv_detail := lv_detail || ' LEACHATE_RECIRCULATION: "' || TO_CHAR(:OLD.LEACHATE_RECIRCULATION) || '"';
		lv_detail := lv_detail || ' PASSIVE_VENTS_FLARES: "' || TO_CHAR(:OLD.PASSIVE_VENTS_FLARES) || '"';
		lv_detail := lv_detail || ' LANDFILL_COVER_DESCRIPTION: "' || :OLD.LANDFILL_COVER_DESCRIPTION || '"';
		lv_detail := lv_detail || ' NOTE_1: "' || :OLD.NOTE_1 || '"';
		lv_detail := lv_detail || ' NOTE_2: "' || :OLD.NOTE_2 || '"';
		lv_detail := lv_detail || ' NOTE_3: "' || :OLD.NOTE_3 || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 71, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_LANDFILL_AUDIT" ENABLE;
