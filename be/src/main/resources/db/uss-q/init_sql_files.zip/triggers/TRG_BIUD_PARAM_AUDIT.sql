--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_PARAM_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_PARAM_AUDIT" 
BEFORE INSERT OR DELETE OR UPDATE OF CODE,VALUE,DATE_VALUE,EDITABLE
ON GBC_PARAM
FOR EACH ROW 
DECLARE
  lv_detail VARCHAR2(4000 BYTE);
  lv_iud    VARCHAR2(1 BYTE);
  lv_app_user VARCHAR2(20 BYTE);
BEGIN
  lv_app_user := USER;

  -- INSERT
  IF INSERTING THEN
  BEGIN
    lv_iud := 'I';

    lv_detail := 'CODE: "' || :NEW.CODE || '"';
    IF :NEW.VALUE IS NOT NULL THEN
      lv_detail := lv_detail || ' VALUE: "' || :NEW.VALUE || '"';
    ELSIF :NEW.DATE_VALUE IS NOT NULL THEN
      lv_detail := lv_detail || ' DATE_VALUE: "' || TO_CHAR(:NEW.DATE_VALUE) || '"';
    END IF;
    lv_detail := lv_detail || ' EDITABLE: "' || TO_CHAR(:NEW.EDITABLE) || '"';
    
    lv_app_user := :NEW.CREATED_BY;
  END;
  END IF;
  
  -- UPDATE
  IF UPDATING THEN
  BEGIN
    lv_iud := 'U';
  
    IF UPDATING('CODE') AND :NEW.CODE <> :OLD.CODE THEN lv_detail := 'CODE: "' || :OLD.CODE || '"->"' || :NEW.CODE || '"'; ELSE lv_detail := 'CODE: "' || :OLD.CODE || '"'; END IF;
    IF UPDATING('VALUE') AND :NEW.VALUE <> :OLD.VALUE THEN lv_detail := lv_detail || ' VALUE: "' || :OLD.VALUE || '"->"' || :NEW.VALUE || '"'; END IF;
    IF UPDATING('DATE_VALUE') AND :NEW.DATE_VALUE <> :OLD.DATE_VALUE THEN lv_detail := lv_detail || ' DATE_VALUE: "' || TO_CHAR(:OLD.DATE_VALUE) || '"->"' || TO_CHAR(:NEW.DATE_VALUE) || '"'; END IF;
    IF UPDATING('EDITABLE') AND :NEW.EDITABLE <> :OLD.EDITABLE THEN lv_detail := lv_detail || ' EDITABLE: "' || TO_CHAR(:OLD.EDITABLE) || '"->"' || TO_CHAR(:NEW.EDITABLE) || '"'; END IF;
    
    IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
  END;
  END IF;
  
  -- DELETE
  IF DELETING THEN
  BEGIN
    lv_iud := 'D';
    
    lv_detail := 'CODE: "' || :OLD.CODE || '"';
    IF :OLD.VALUE IS NOT NULL THEN
      lv_detail := lv_detail || ' VALUE: "' || :OLD.VALUE || '"';
    ELSIF :OLD.DATE_VALUE IS NOT NULL THEN
      lv_detail := lv_detail || ' DATE_VALUE: "' || TO_CHAR(:OLD.DATE_VALUE) || '"';
    END IF;
    lv_detail := lv_detail || ' EDITABLE: "' || TO_CHAR(:OLD.EDITABLE) || '"';
  END;
  END IF;

  -- insert audit record  
  INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
    VALUES (JOURNAL_SEQ.NEXTVAL, lv_detail, lv_app_user, SYSTIMESTAMP, 22, lv_iud);
END;
/
ALTER TRIGGER "TRG_BIUD_PARAM_AUDIT" ENABLE;
