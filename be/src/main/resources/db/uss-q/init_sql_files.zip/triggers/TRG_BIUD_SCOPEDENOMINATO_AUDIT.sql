--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_SCOPEDENOMINATO_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_SCOPEDENOMINATO_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_SCOPE,ID_MATERIAL
            ON GBC_SCOPE_DENOMINATOR
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_SCOPE: "' || TO_CHAR(:NEW.ID_SCOPE) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL: "' || TO_CHAR(:NEW.ID_MATERIAL) || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_SCOPE') AND :NEW.ID_SCOPE <> :OLD.ID_SCOPE THEN lv_detail := lv_detail || ' ID_SCOPE: "' || TO_CHAR(:OLD.ID_SCOPE) || '"->"' || TO_CHAR(:NEW.ID_SCOPE) || '"'; END IF;
		IF UPDATING('ID_MATERIAL') AND :NEW.ID_MATERIAL <> :OLD.ID_MATERIAL THEN lv_detail := lv_detail || ' ID_MATERIAL: "' || TO_CHAR(:OLD.ID_MATERIAL) || '"->"' || TO_CHAR(:NEW.ID_MATERIAL) || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_SCOPE: "' || TO_CHAR(:OLD.ID_SCOPE) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL: "' || TO_CHAR(:OLD.ID_MATERIAL) || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 29, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_SCOPEDENOMINATO_AUDIT" ENABLE;
