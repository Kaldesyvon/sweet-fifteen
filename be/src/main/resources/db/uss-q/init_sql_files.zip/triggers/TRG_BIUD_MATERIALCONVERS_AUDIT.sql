--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_MATERIALCONVERS_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_MATERIALCONVERS_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_MATERIAL,BC_MATERIAL_CODE,BC_MATERIAL_NAME,ID_UNIT,IO,QUANTITY_COEFFICIENT,ID_NODE,LOAD_TAB_QUANTITY,LOAD_TAB_ANALYSIS,AUTO_ANALYSIS,EDITABLE
            ON GBC_MATERIAL_CONVERSION
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL: "' || TO_CHAR(:NEW.ID_MATERIAL) || '"';
		lv_detail := lv_detail || ' BC_MATERIAL_CODE: "' || :NEW.BC_MATERIAL_CODE || '"';
		lv_detail := lv_detail || ' BC_MATERIAL_NAME: "' || :NEW.BC_MATERIAL_NAME || '"';
		lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:NEW.ID_UNIT) || '"';
		lv_detail := lv_detail || ' IO: "' || TO_CHAR(:NEW.IO) || '"';
		lv_detail := lv_detail || ' QUANTITY_COEFFICIENT: "' || TO_CHAR(:NEW.QUANTITY_COEFFICIENT) || '"';
		lv_detail := lv_detail || ' ID_NODE: "' || TO_CHAR(:NEW.ID_NODE) || '"';
		lv_detail := lv_detail || ' LOAD_TAB_QUANTITY: "' || :NEW.LOAD_TAB_QUANTITY || '"';
		lv_detail := lv_detail || ' LOAD_TAB_ANALYSIS: "' || :NEW.LOAD_TAB_ANALYSIS || '"';
		lv_detail := lv_detail || ' AUTO_ANALYSIS: "' || TO_CHAR(:NEW.AUTO_ANALYSIS) || '"';
		lv_detail := lv_detail || ' EDITABLE: "' || TO_CHAR(:NEW.EDITABLE) || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_MATERIAL') AND :NEW.ID_MATERIAL <> :OLD.ID_MATERIAL THEN lv_detail := lv_detail || ' ID_MATERIAL: "' || TO_CHAR(:OLD.ID_MATERIAL) || '"->"' || TO_CHAR(:NEW.ID_MATERIAL) || '"'; END IF;
		IF UPDATING('BC_MATERIAL_CODE') AND :NEW.BC_MATERIAL_CODE <> :OLD.BC_MATERIAL_CODE THEN lv_detail := lv_detail || ' BC_MATERIAL_CODE: "' || :OLD.BC_MATERIAL_CODE || '"->"' || :NEW.BC_MATERIAL_CODE || '"'; END IF;
		IF UPDATING('BC_MATERIAL_NAME') AND :NEW.BC_MATERIAL_NAME <> :OLD.BC_MATERIAL_NAME THEN lv_detail := lv_detail || ' BC_MATERIAL_NAME: "' || :OLD.BC_MATERIAL_NAME || '"->"' || :NEW.BC_MATERIAL_NAME || '"'; END IF;
		IF UPDATING('ID_UNIT') AND :NEW.ID_UNIT <> :OLD.ID_UNIT THEN lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:OLD.ID_UNIT) || '"->"' || TO_CHAR(:NEW.ID_UNIT) || '"'; END IF;
		IF UPDATING('IO') AND :NEW.IO <> :OLD.IO THEN lv_detail := lv_detail || ' IO: "' || TO_CHAR(:OLD.IO) || '"->"' || TO_CHAR(:NEW.IO) || '"'; END IF;
		IF UPDATING('QUANTITY_COEFFICIENT') AND :NEW.QUANTITY_COEFFICIENT <> :OLD.QUANTITY_COEFFICIENT THEN lv_detail := lv_detail || ' QUANTITY_COEFFICIENT: "' || TO_CHAR(:OLD.QUANTITY_COEFFICIENT) || '"->"' || TO_CHAR(:NEW.QUANTITY_COEFFICIENT) || '"'; END IF;
		IF UPDATING('ID_NODE') AND :NEW.ID_NODE <> :OLD.ID_NODE THEN lv_detail := lv_detail || ' ID_NODE: "' || TO_CHAR(:OLD.ID_NODE) || '"->"' || TO_CHAR(:NEW.ID_NODE) || '"'; END IF;
		IF UPDATING('LOAD_TAB_QUANTITY') AND (:NEW.LOAD_TAB_QUANTITY <> :OLD.LOAD_TAB_QUANTITY OR (:NEW.LOAD_TAB_QUANTITY IS NOT NULL AND :OLD.LOAD_TAB_QUANTITY IS NULL) OR (:NEW.LOAD_TAB_QUANTITY IS NULL AND :OLD.LOAD_TAB_QUANTITY IS NOT NULL)) THEN lv_detail := lv_detail || ' LOAD_TAB_QUANTITY: "' || :OLD.LOAD_TAB_QUANTITY || '"->"' || :NEW.LOAD_TAB_QUANTITY || '"'; END IF;
		IF UPDATING('LOAD_TAB_ANALYSIS') AND (:NEW.LOAD_TAB_ANALYSIS <> :OLD.LOAD_TAB_ANALYSIS OR (:NEW.LOAD_TAB_ANALYSIS IS NOT NULL AND :OLD.LOAD_TAB_ANALYSIS IS NULL) OR (:NEW.LOAD_TAB_ANALYSIS IS NULL AND :OLD.LOAD_TAB_ANALYSIS IS NOT NULL)) THEN lv_detail := lv_detail || ' LOAD_TAB_ANALYSIS: "' || :OLD.LOAD_TAB_ANALYSIS || '"->"' || :NEW.LOAD_TAB_ANALYSIS || '"'; END IF;
		IF UPDATING('AUTO_ANALYSIS') AND :NEW.AUTO_ANALYSIS <> :OLD.AUTO_ANALYSIS THEN lv_detail := lv_detail || ' AUTO_ANALYSIS: "' || TO_CHAR(:OLD.AUTO_ANALYSIS) || '"->"' || TO_CHAR(:NEW.AUTO_ANALYSIS) || '"'; END IF;
		IF UPDATING('EDITABLE') AND :NEW.EDITABLE <> :OLD.EDITABLE THEN lv_detail := lv_detail || ' EDITABLE: "' || TO_CHAR(:OLD.EDITABLE) || '"->"' || TO_CHAR(:NEW.EDITABLE) || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL: "' || TO_CHAR(:OLD.ID_MATERIAL) || '"';
		lv_detail := lv_detail || ' BC_MATERIAL_CODE: "' || :OLD.BC_MATERIAL_CODE || '"';
		lv_detail := lv_detail || ' BC_MATERIAL_NAME: "' || :OLD.BC_MATERIAL_NAME || '"';
		lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:OLD.ID_UNIT) || '"';
		lv_detail := lv_detail || ' IO: "' || TO_CHAR(:OLD.IO) || '"';
		lv_detail := lv_detail || ' QUANTITY_COEFFICIENT: "' || TO_CHAR(:OLD.QUANTITY_COEFFICIENT) || '"';
		lv_detail := lv_detail || ' ID_NODE: "' || TO_CHAR(:OLD.ID_NODE) || '"';
		lv_detail := lv_detail || ' LOAD_TAB_QUANTITY: "' || :OLD.LOAD_TAB_QUANTITY || '"';
		lv_detail := lv_detail || ' LOAD_TAB_ANALYSIS: "' || :OLD.LOAD_TAB_ANALYSIS || '"';
		lv_detail := lv_detail || ' AUTO_ANALYSIS: "' || TO_CHAR(:OLD.AUTO_ANALYSIS) || '"';
		lv_detail := lv_detail || ' EDITABLE: "' || TO_CHAR(:OLD.EDITABLE) || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 64, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_MATERIALCONVERS_AUDIT" ENABLE;
