--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_METER_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_METER_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,NAME,NAME_SHORT,FACTORY_NUMBER,METERID,ID_METER_TYPE,ID_FUEL_TYPE,MODEL,LOCATION,DESCRIPTION,NOTE_1,NOTE_2,NOTE_3,ID_UNIT_TYPE,VALID_FROM,VALID_TO,ID_NODE_LOCATION,GPS_LATITUDE,GPS_LONGITUDE,METER_MODEL,RATED_ACCURACY,GPS_ELEVATION,GPS_ELEVATION_UNITS
            ON GBC_METER
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' NAME: "' || :NEW.NAME || '"';
		lv_detail := lv_detail || ' NAME_SHORT: "' || :NEW.NAME_SHORT || '"';
		lv_detail := lv_detail || ' FACTORY_NUMBER: "' || :NEW.FACTORY_NUMBER || '"';
		lv_detail := lv_detail || ' METERID: "' || :NEW.METERID || '"';
		lv_detail := lv_detail || ' ID_METER_TYPE: "' || TO_CHAR(:NEW.ID_METER_TYPE) || '"';
		lv_detail := lv_detail || ' ID_FUEL_TYPE: "' || TO_CHAR(:NEW.ID_FUEL_TYPE) || '"';
		lv_detail := lv_detail || ' MODEL: "' || :NEW.MODEL || '"';
		lv_detail := lv_detail || ' LOCATION: "' || :NEW.LOCATION || '"';
		lv_detail := lv_detail || ' DESCRIPTION: "' || :NEW.DESCRIPTION || '"';
		lv_detail := lv_detail || ' NOTE_1: "' || :NEW.NOTE_1 || '"';
		lv_detail := lv_detail || ' NOTE_2: "' || :NEW.NOTE_2 || '"';
		lv_detail := lv_detail || ' NOTE_3: "' || :NEW.NOTE_3 || '"';
		lv_detail := lv_detail || ' ID_UNIT_TYPE: "' || TO_CHAR(:NEW.ID_UNIT_TYPE) || '"';
		lv_detail := lv_detail || ' VALID_FROM: "' || TO_CHAR(:NEW.VALID_FROM) || '"';
		lv_detail := lv_detail || ' VALID_TO: "' || TO_CHAR(:NEW.VALID_TO) || '"';
		lv_detail := lv_detail || ' ID_NODE_LOCATION: "' || TO_CHAR(:NEW.ID_NODE_LOCATION) || '"';
		lv_detail := lv_detail || ' GPS_LATITUDE: "' || :NEW.GPS_LATITUDE || '"';
		lv_detail := lv_detail || ' GPS_LONGITUDE: "' || :NEW.GPS_LONGITUDE || '"';
		lv_detail := lv_detail || ' METER_MODEL: "' || :NEW.METER_MODEL || '"';
		lv_detail := lv_detail || ' RATED_ACCURACY: "' || :NEW.RATED_ACCURACY || '"';
		lv_detail := lv_detail || ' GPS_ELEVATION: "' || TO_CHAR(:NEW.GPS_ELEVATION) || '"';
		lv_detail := lv_detail || ' GPS_ELEVATION_UNITS: "' || :NEW.GPS_ELEVATION_UNITS || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('NAME') AND :NEW.NAME <> :OLD.NAME THEN lv_detail := lv_detail || ' NAME: "' || :OLD.NAME || '"->"' || :NEW.NAME || '"'; END IF;
		IF UPDATING('NAME_SHORT') AND (:NEW.NAME_SHORT <> :OLD.NAME_SHORT OR (:NEW.NAME_SHORT IS NOT NULL AND :OLD.NAME_SHORT IS NULL) OR (:NEW.NAME_SHORT IS NULL AND :OLD.NAME_SHORT IS NOT NULL)) THEN lv_detail := lv_detail || ' NAME_SHORT: "' || :OLD.NAME_SHORT || '"->"' || :NEW.NAME_SHORT || '"'; END IF;
		IF UPDATING('FACTORY_NUMBER') AND (:NEW.FACTORY_NUMBER <> :OLD.FACTORY_NUMBER OR (:NEW.FACTORY_NUMBER IS NOT NULL AND :OLD.FACTORY_NUMBER IS NULL) OR (:NEW.FACTORY_NUMBER IS NULL AND :OLD.FACTORY_NUMBER IS NOT NULL)) THEN lv_detail := lv_detail || ' FACTORY_NUMBER: "' || :OLD.FACTORY_NUMBER || '"->"' || :NEW.FACTORY_NUMBER || '"'; END IF;
		IF UPDATING('METERID') AND :NEW.METERID <> :OLD.METERID THEN lv_detail := lv_detail || ' METERID: "' || :OLD.METERID || '"->"' || :NEW.METERID || '"'; END IF;
		IF UPDATING('ID_METER_TYPE') AND (:NEW.ID_METER_TYPE <> :OLD.ID_METER_TYPE OR (:NEW.ID_METER_TYPE IS NOT NULL AND :OLD.ID_METER_TYPE IS NULL) OR (:NEW.ID_METER_TYPE IS NULL AND :OLD.ID_METER_TYPE IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_METER_TYPE: "' || TO_CHAR(:OLD.ID_METER_TYPE) || '"->"' || TO_CHAR(:NEW.ID_METER_TYPE) || '"'; END IF;
		IF UPDATING('ID_FUEL_TYPE') AND (:NEW.ID_FUEL_TYPE <> :OLD.ID_FUEL_TYPE OR (:NEW.ID_FUEL_TYPE IS NOT NULL AND :OLD.ID_FUEL_TYPE IS NULL) OR (:NEW.ID_FUEL_TYPE IS NULL AND :OLD.ID_FUEL_TYPE IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_FUEL_TYPE: "' || TO_CHAR(:OLD.ID_FUEL_TYPE) || '"->"' || TO_CHAR(:NEW.ID_FUEL_TYPE) || '"'; END IF;
		IF UPDATING('MODEL') AND (:NEW.MODEL <> :OLD.MODEL OR (:NEW.MODEL IS NOT NULL AND :OLD.MODEL IS NULL) OR (:NEW.MODEL IS NULL AND :OLD.MODEL IS NOT NULL)) THEN lv_detail := lv_detail || ' MODEL: "' || :OLD.MODEL || '"->"' || :NEW.MODEL || '"'; END IF;
		IF UPDATING('LOCATION') AND (:NEW.LOCATION <> :OLD.LOCATION OR (:NEW.LOCATION IS NOT NULL AND :OLD.LOCATION IS NULL) OR (:NEW.LOCATION IS NULL AND :OLD.LOCATION IS NOT NULL)) THEN lv_detail := lv_detail || ' LOCATION: "' || :OLD.LOCATION || '"->"' || :NEW.LOCATION || '"'; END IF;
		IF UPDATING('DESCRIPTION') AND (:NEW.DESCRIPTION <> :OLD.DESCRIPTION OR (:NEW.DESCRIPTION IS NOT NULL AND :OLD.DESCRIPTION IS NULL) OR (:NEW.DESCRIPTION IS NULL AND :OLD.DESCRIPTION IS NOT NULL)) THEN lv_detail := lv_detail || ' DESCRIPTION: "' || :OLD.DESCRIPTION || '"->"' || :NEW.DESCRIPTION || '"'; END IF;
		IF UPDATING('NOTE_1') AND (:NEW.NOTE_1 <> :OLD.NOTE_1 OR (:NEW.NOTE_1 IS NOT NULL AND :OLD.NOTE_1 IS NULL) OR (:NEW.NOTE_1 IS NULL AND :OLD.NOTE_1 IS NOT NULL)) THEN lv_detail := lv_detail || ' NOTE_1: "' || :OLD.NOTE_1 || '"->"' || :NEW.NOTE_1 || '"'; END IF;
		IF UPDATING('NOTE_2') AND (:NEW.NOTE_2 <> :OLD.NOTE_2 OR (:NEW.NOTE_2 IS NOT NULL AND :OLD.NOTE_2 IS NULL) OR (:NEW.NOTE_2 IS NULL AND :OLD.NOTE_2 IS NOT NULL)) THEN lv_detail := lv_detail || ' NOTE_2: "' || :OLD.NOTE_2 || '"->"' || :NEW.NOTE_2 || '"'; END IF;
		IF UPDATING('NOTE_3') AND (:NEW.NOTE_3 <> :OLD.NOTE_3 OR (:NEW.NOTE_3 IS NOT NULL AND :OLD.NOTE_3 IS NULL) OR (:NEW.NOTE_3 IS NULL AND :OLD.NOTE_3 IS NOT NULL)) THEN lv_detail := lv_detail || ' NOTE_3: "' || :OLD.NOTE_3 || '"->"' || :NEW.NOTE_3 || '"'; END IF;
		IF UPDATING('ID_UNIT_TYPE') AND :NEW.ID_UNIT_TYPE <> :OLD.ID_UNIT_TYPE THEN lv_detail := lv_detail || ' ID_UNIT_TYPE: "' || TO_CHAR(:OLD.ID_UNIT_TYPE) || '"->"' || TO_CHAR(:NEW.ID_UNIT_TYPE) || '"'; END IF;
		IF UPDATING('VALID_FROM') AND :NEW.VALID_FROM <> :OLD.VALID_FROM THEN lv_detail := lv_detail || ' VALID_FROM: "' || TO_CHAR(:OLD.VALID_FROM) || '"->"' || TO_CHAR(:NEW.VALID_FROM) || '"'; END IF;
		IF UPDATING('VALID_TO') AND (:NEW.VALID_TO <> :OLD.VALID_TO OR (:NEW.VALID_TO IS NOT NULL AND :OLD.VALID_TO IS NULL) OR (:NEW.VALID_TO IS NULL AND :OLD.VALID_TO IS NOT NULL)) THEN lv_detail := lv_detail || ' VALID_TO: "' || TO_CHAR(:OLD.VALID_TO) || '"->"' || TO_CHAR(:NEW.VALID_TO) || '"'; END IF;
		IF UPDATING('ID_NODE_LOCATION') AND :NEW.ID_NODE_LOCATION <> :OLD.ID_NODE_LOCATION THEN lv_detail := lv_detail || ' ID_NODE_LOCATION: "' || TO_CHAR(:OLD.ID_NODE_LOCATION) || '"->"' || TO_CHAR(:NEW.ID_NODE_LOCATION) || '"'; END IF;
		IF UPDATING('GPS_LATITUDE') AND (:NEW.GPS_LATITUDE <> :OLD.GPS_LATITUDE OR (:NEW.GPS_LATITUDE IS NOT NULL AND :OLD.GPS_LATITUDE IS NULL) OR (:NEW.GPS_LATITUDE IS NULL AND :OLD.GPS_LATITUDE IS NOT NULL)) THEN lv_detail := lv_detail || ' GPS_LATITUDE: "' || :OLD.GPS_LATITUDE || '"->"' || :NEW.GPS_LATITUDE || '"'; END IF;
		IF UPDATING('GPS_LONGITUDE') AND (:NEW.GPS_LONGITUDE <> :OLD.GPS_LONGITUDE OR (:NEW.GPS_LONGITUDE IS NOT NULL AND :OLD.GPS_LONGITUDE IS NULL) OR (:NEW.GPS_LONGITUDE IS NULL AND :OLD.GPS_LONGITUDE IS NOT NULL)) THEN lv_detail := lv_detail || ' GPS_LONGITUDE: "' || :OLD.GPS_LONGITUDE || '"->"' || :NEW.GPS_LONGITUDE || '"'; END IF;
		IF UPDATING('METER_MODEL') AND (:NEW.METER_MODEL <> :OLD.METER_MODEL OR (:NEW.METER_MODEL IS NOT NULL AND :OLD.METER_MODEL IS NULL) OR (:NEW.METER_MODEL IS NULL AND :OLD.METER_MODEL IS NOT NULL)) THEN lv_detail := lv_detail || ' METER_MODEL: "' || :OLD.METER_MODEL || '"->"' || :NEW.METER_MODEL || '"'; END IF;
		IF UPDATING('RATED_ACCURACY') AND (:NEW.RATED_ACCURACY <> :OLD.RATED_ACCURACY OR (:NEW.RATED_ACCURACY IS NOT NULL AND :OLD.RATED_ACCURACY IS NULL) OR (:NEW.RATED_ACCURACY IS NULL AND :OLD.RATED_ACCURACY IS NOT NULL)) THEN lv_detail := lv_detail || ' RATED_ACCURACY: "' || :OLD.RATED_ACCURACY || '"->"' || :NEW.RATED_ACCURACY || '"'; END IF;
		IF UPDATING('GPS_ELEVATION') AND (:NEW.GPS_ELEVATION <> :OLD.GPS_ELEVATION OR (:NEW.GPS_ELEVATION IS NOT NULL AND :OLD.GPS_ELEVATION IS NULL) OR (:NEW.GPS_ELEVATION IS NULL AND :OLD.GPS_ELEVATION IS NOT NULL)) THEN lv_detail := lv_detail || ' GPS_ELEVATION: "' || TO_CHAR(:OLD.GPS_ELEVATION) || '"->"' || TO_CHAR(:NEW.GPS_ELEVATION) || '"'; END IF;
		IF UPDATING('GPS_ELEVATION_UNITS') AND (:NEW.GPS_ELEVATION_UNITS <> :OLD.GPS_ELEVATION_UNITS OR (:NEW.GPS_ELEVATION_UNITS IS NOT NULL AND :OLD.GPS_ELEVATION_UNITS IS NULL) OR (:NEW.GPS_ELEVATION_UNITS IS NULL AND :OLD.GPS_ELEVATION_UNITS IS NOT NULL)) THEN lv_detail := lv_detail || ' GPS_ELEVATION_UNITS: "' || :OLD.GPS_ELEVATION_UNITS || '"->"' || :NEW.GPS_ELEVATION_UNITS || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' NAME: "' || :OLD.NAME || '"';
		lv_detail := lv_detail || ' NAME_SHORT: "' || :OLD.NAME_SHORT || '"';
		lv_detail := lv_detail || ' FACTORY_NUMBER: "' || :OLD.FACTORY_NUMBER || '"';
		lv_detail := lv_detail || ' METERID: "' || :OLD.METERID || '"';
		lv_detail := lv_detail || ' ID_METER_TYPE: "' || TO_CHAR(:OLD.ID_METER_TYPE) || '"';
		lv_detail := lv_detail || ' ID_FUEL_TYPE: "' || TO_CHAR(:OLD.ID_FUEL_TYPE) || '"';
		lv_detail := lv_detail || ' MODEL: "' || :OLD.MODEL || '"';
		lv_detail := lv_detail || ' LOCATION: "' || :OLD.LOCATION || '"';
		lv_detail := lv_detail || ' DESCRIPTION: "' || :OLD.DESCRIPTION || '"';
		lv_detail := lv_detail || ' NOTE_1: "' || :OLD.NOTE_1 || '"';
		lv_detail := lv_detail || ' NOTE_2: "' || :OLD.NOTE_2 || '"';
		lv_detail := lv_detail || ' NOTE_3: "' || :OLD.NOTE_3 || '"';
		lv_detail := lv_detail || ' ID_UNIT_TYPE: "' || TO_CHAR(:OLD.ID_UNIT_TYPE) || '"';
		lv_detail := lv_detail || ' VALID_FROM: "' || TO_CHAR(:OLD.VALID_FROM) || '"';
		lv_detail := lv_detail || ' VALID_TO: "' || TO_CHAR(:OLD.VALID_TO) || '"';
		lv_detail := lv_detail || ' ID_NODE_LOCATION: "' || TO_CHAR(:OLD.ID_NODE_LOCATION) || '"';
		lv_detail := lv_detail || ' GPS_LATITUDE: "' || :OLD.GPS_LATITUDE || '"';
		lv_detail := lv_detail || ' GPS_LONGITUDE: "' || :OLD.GPS_LONGITUDE || '"';
		lv_detail := lv_detail || ' METER_MODEL: "' || :OLD.METER_MODEL || '"';
		lv_detail := lv_detail || ' RATED_ACCURACY: "' || :OLD.RATED_ACCURACY || '"';
		lv_detail := lv_detail || ' GPS_ELEVATION: "' || TO_CHAR(:OLD.GPS_ELEVATION) || '"';
		lv_detail := lv_detail || ' GPS_ELEVATION_UNITS: "' || :OLD.GPS_ELEVATION_UNITS || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 65, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_METER_AUDIT" ENABLE;
