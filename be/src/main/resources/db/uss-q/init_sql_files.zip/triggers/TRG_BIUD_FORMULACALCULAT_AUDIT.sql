--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_FORMULACALCULAT_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_FORMULACALCULAT_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_ANALYSIS_CALCULATED,EXPR,ID_ANALYSIS_INPUT
            ON GBC_FORMULA_CALCULATION
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_ANALYSIS_CALCULATED: "' || TO_CHAR(:NEW.ID_ANALYSIS_CALCULATED) || '"';
		lv_detail := lv_detail || ' EXPR: "' || :NEW.EXPR || '"';
		lv_detail := lv_detail || ' ID_ANALYSIS_INPUT: "' || TO_CHAR(:NEW.ID_ANALYSIS_INPUT) || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_ANALYSIS_CALCULATED') AND :NEW.ID_ANALYSIS_CALCULATED <> :OLD.ID_ANALYSIS_CALCULATED THEN lv_detail := lv_detail || ' ID_ANALYSIS_CALCULATED: "' || TO_CHAR(:OLD.ID_ANALYSIS_CALCULATED) || '"->"' || TO_CHAR(:NEW.ID_ANALYSIS_CALCULATED) || '"'; END IF;
		IF UPDATING('EXPR') AND :NEW.EXPR <> :OLD.EXPR THEN lv_detail := lv_detail || ' EXPR: "' || :OLD.EXPR || '"->"' || :NEW.EXPR || '"'; END IF;
		IF UPDATING('ID_ANALYSIS_INPUT') AND :NEW.ID_ANALYSIS_INPUT <> :OLD.ID_ANALYSIS_INPUT THEN lv_detail := lv_detail || ' ID_ANALYSIS_INPUT: "' || TO_CHAR(:OLD.ID_ANALYSIS_INPUT) || '"->"' || TO_CHAR(:NEW.ID_ANALYSIS_INPUT) || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_ANALYSIS_CALCULATED: "' || TO_CHAR(:OLD.ID_ANALYSIS_CALCULATED) || '"';
		lv_detail := lv_detail || ' EXPR: "' || :OLD.EXPR || '"';
		lv_detail := lv_detail || ' ID_ANALYSIS_INPUT: "' || TO_CHAR(:OLD.ID_ANALYSIS_INPUT) || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 72, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_FORMULACALCULAT_AUDIT" ENABLE;
