--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_NODE_DATALOCK_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_NODE_DATALOCK_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,CHECK_DATE,LOCK_DATE,AUDIT_DATE,CHECKED_BY,CHECKED_DATE,LOCKED_BY,LOCKED_DATE,AUDITED_BY,AUDITED_DATE
            ON GBC_NODE_DATALOCK
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' CHECK_DATE: "' || TO_CHAR(:NEW.CHECK_DATE) || '"';
		lv_detail := lv_detail || ' LOCK_DATE: "' || TO_CHAR(:NEW.LOCK_DATE) || '"';
		lv_detail := lv_detail || ' AUDIT_DATE: "' || TO_CHAR(:NEW.AUDIT_DATE) || '"';
		lv_detail := lv_detail || ' CHECKED_BY: "' || :NEW.CHECKED_BY || '"';
		lv_detail := lv_detail || ' CHECKED_DATE: "' || TO_CHAR(:NEW.CHECKED_DATE) || '"';
		lv_detail := lv_detail || ' LOCKED_BY: "' || :NEW.LOCKED_BY || '"';
		lv_detail := lv_detail || ' LOCKED_DATE: "' || TO_CHAR(:NEW.LOCKED_DATE) || '"';
		lv_detail := lv_detail || ' AUDITED_BY: "' || :NEW.AUDITED_BY || '"';
		lv_detail := lv_detail || ' AUDITED_DATE: "' || TO_CHAR(:NEW.AUDITED_DATE) || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('CHECK_DATE') AND :NEW.CHECK_DATE <> :OLD.CHECK_DATE THEN lv_detail := lv_detail || ' CHECK_DATE: "' || TO_CHAR(:OLD.CHECK_DATE) || '"->"' || TO_CHAR(:NEW.CHECK_DATE) || '"'; END IF;
		IF UPDATING('LOCK_DATE') AND :NEW.LOCK_DATE <> :OLD.LOCK_DATE THEN lv_detail := lv_detail || ' LOCK_DATE: "' || TO_CHAR(:OLD.LOCK_DATE) || '"->"' || TO_CHAR(:NEW.LOCK_DATE) || '"'; END IF;
		IF UPDATING('AUDIT_DATE') AND :NEW.AUDIT_DATE <> :OLD.AUDIT_DATE THEN lv_detail := lv_detail || ' AUDIT_DATE: "' || TO_CHAR(:OLD.AUDIT_DATE) || '"->"' || TO_CHAR(:NEW.AUDIT_DATE) || '"'; END IF;
		IF UPDATING('CHECKED_BY') AND (:NEW.CHECKED_BY <> :OLD.CHECKED_BY OR (:NEW.CHECKED_BY IS NOT NULL AND :OLD.CHECKED_BY IS NULL) OR (:NEW.CHECKED_BY IS NULL AND :OLD.CHECKED_BY IS NOT NULL)) THEN lv_detail := lv_detail || ' CHECKED_BY: "' || :OLD.CHECKED_BY || '"->"' || :NEW.CHECKED_BY || '"'; END IF;
		IF UPDATING('CHECKED_DATE') AND (:NEW.CHECKED_DATE <> :OLD.CHECKED_DATE OR (:NEW.CHECKED_DATE IS NOT NULL AND :OLD.CHECKED_DATE IS NULL) OR (:NEW.CHECKED_DATE IS NULL AND :OLD.CHECKED_DATE IS NOT NULL)) THEN lv_detail := lv_detail || ' CHECKED_DATE: "' || TO_CHAR(:OLD.CHECKED_DATE) || '"->"' || TO_CHAR(:NEW.CHECKED_DATE) || '"'; END IF;
		IF UPDATING('LOCKED_BY') AND (:NEW.LOCKED_BY <> :OLD.LOCKED_BY OR (:NEW.LOCKED_BY IS NOT NULL AND :OLD.LOCKED_BY IS NULL) OR (:NEW.LOCKED_BY IS NULL AND :OLD.LOCKED_BY IS NOT NULL)) THEN lv_detail := lv_detail || ' LOCKED_BY: "' || :OLD.LOCKED_BY || '"->"' || :NEW.LOCKED_BY || '"'; END IF;
		IF UPDATING('LOCKED_DATE') AND (:NEW.LOCKED_DATE <> :OLD.LOCKED_DATE OR (:NEW.LOCKED_DATE IS NOT NULL AND :OLD.LOCKED_DATE IS NULL) OR (:NEW.LOCKED_DATE IS NULL AND :OLD.LOCKED_DATE IS NOT NULL)) THEN lv_detail := lv_detail || ' LOCKED_DATE: "' || TO_CHAR(:OLD.LOCKED_DATE) || '"->"' || TO_CHAR(:NEW.LOCKED_DATE) || '"'; END IF;
		IF UPDATING('AUDITED_BY') AND (:NEW.AUDITED_BY <> :OLD.AUDITED_BY OR (:NEW.AUDITED_BY IS NOT NULL AND :OLD.AUDITED_BY IS NULL) OR (:NEW.AUDITED_BY IS NULL AND :OLD.AUDITED_BY IS NOT NULL)) THEN lv_detail := lv_detail || ' AUDITED_BY: "' || :OLD.AUDITED_BY || '"->"' || :NEW.AUDITED_BY || '"'; END IF;
		IF UPDATING('AUDITED_DATE') AND (:NEW.AUDITED_DATE <> :OLD.AUDITED_DATE OR (:NEW.AUDITED_DATE IS NOT NULL AND :OLD.AUDITED_DATE IS NULL) OR (:NEW.AUDITED_DATE IS NULL AND :OLD.AUDITED_DATE IS NOT NULL)) THEN lv_detail := lv_detail || ' AUDITED_DATE: "' || TO_CHAR(:OLD.AUDITED_DATE) || '"->"' || TO_CHAR(:NEW.AUDITED_DATE) || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' CHECK_DATE: "' || TO_CHAR(:OLD.CHECK_DATE) || '"';
		lv_detail := lv_detail || ' LOCK_DATE: "' || TO_CHAR(:OLD.LOCK_DATE) || '"';
		lv_detail := lv_detail || ' AUDIT_DATE: "' || TO_CHAR(:OLD.AUDIT_DATE) || '"';
		lv_detail := lv_detail || ' CHECKED_BY: "' || :OLD.CHECKED_BY || '"';
		lv_detail := lv_detail || ' CHECKED_DATE: "' || TO_CHAR(:OLD.CHECKED_DATE) || '"';
		lv_detail := lv_detail || ' LOCKED_BY: "' || :OLD.LOCKED_BY || '"';
		lv_detail := lv_detail || ' LOCKED_DATE: "' || TO_CHAR(:OLD.LOCKED_DATE) || '"';
		lv_detail := lv_detail || ' AUDITED_BY: "' || :OLD.AUDITED_BY || '"';
		lv_detail := lv_detail || ' AUDITED_DATE: "' || TO_CHAR(:OLD.AUDITED_DATE) || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 11, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_NODE_DATALOCK_AUDIT" ENABLE;
