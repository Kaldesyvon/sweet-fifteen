--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_ANALYSIS_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_ANALYSIS_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_MATERIAL_NODE,ID_ANALYSIS_PARAM,VALID_FROM,FACTOR_A,FACTOR_B,REMOTE_CODE,MEMO,ID_UNIT_NUMENATOR,ID_UNIT_DENOMINATOR,EDITABLE,VALID_TO,CALCULATED,UNCERTAINTY,FACTOR_C,MDL_A,ID_REMOTE_MATERIAL_CODE,ID_REMOTE_CODE_LOAD
            ON GBC_ANALYSIS
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL_NODE: "' || TO_CHAR(:NEW.ID_MATERIAL_NODE) || '"';
		lv_detail := lv_detail || ' ID_ANALYSIS_PARAM: "' || TO_CHAR(:NEW.ID_ANALYSIS_PARAM) || '"';
		lv_detail := lv_detail || ' VALID_FROM: "' || TO_CHAR(:NEW.VALID_FROM) || '"';
		lv_detail := lv_detail || ' FACTOR_A: "' || TO_CHAR(:NEW.FACTOR_A) || '"';
		lv_detail := lv_detail || ' FACTOR_B: "' || TO_CHAR(:NEW.FACTOR_B) || '"';
		lv_detail := lv_detail || ' REMOTE_CODE: "' || :NEW.REMOTE_CODE || '"';
		lv_detail := lv_detail || ' MEMO: "' || :NEW.MEMO || '"';
		lv_detail := lv_detail || ' ID_UNIT_NUMENATOR: "' || TO_CHAR(:NEW.ID_UNIT_NUMENATOR) || '"';
		lv_detail := lv_detail || ' ID_UNIT_DENOMINATOR: "' || TO_CHAR(:NEW.ID_UNIT_DENOMINATOR) || '"';
		lv_detail := lv_detail || ' EDITABLE: "' || TO_CHAR(:NEW.EDITABLE) || '"';
		lv_detail := lv_detail || ' VALID_TO: "' || TO_CHAR(:NEW.VALID_TO) || '"';
		lv_detail := lv_detail || ' CALCULATED: "' || TO_CHAR(:NEW.CALCULATED) || '"';
		lv_detail := lv_detail || ' UNCERTAINTY: "' || TO_CHAR(:NEW.UNCERTAINTY) || '"';
		lv_detail := lv_detail || ' FACTOR_C: "' || TO_CHAR(:NEW.FACTOR_C) || '"';
		lv_detail := lv_detail || ' MDL_A: "' || :NEW.MDL_A || '"';
		lv_detail := lv_detail || ' ID_REMOTE_MATERIAL_CODE: "' || TO_CHAR(:NEW.ID_REMOTE_MATERIAL_CODE) || '"';
		lv_detail := lv_detail || ' ID_REMOTE_CODE_LOAD: "' || TO_CHAR(:NEW.ID_REMOTE_CODE_LOAD) || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_MATERIAL_NODE') AND :NEW.ID_MATERIAL_NODE <> :OLD.ID_MATERIAL_NODE THEN lv_detail := lv_detail || ' ID_MATERIAL_NODE: "' || TO_CHAR(:OLD.ID_MATERIAL_NODE) || '"->"' || TO_CHAR(:NEW.ID_MATERIAL_NODE) || '"'; END IF;
		IF UPDATING('ID_ANALYSIS_PARAM') AND :NEW.ID_ANALYSIS_PARAM <> :OLD.ID_ANALYSIS_PARAM THEN lv_detail := lv_detail || ' ID_ANALYSIS_PARAM: "' || TO_CHAR(:OLD.ID_ANALYSIS_PARAM) || '"->"' || TO_CHAR(:NEW.ID_ANALYSIS_PARAM) || '"'; END IF;
		IF UPDATING('VALID_FROM') AND :NEW.VALID_FROM <> :OLD.VALID_FROM THEN lv_detail := lv_detail || ' VALID_FROM: "' || TO_CHAR(:OLD.VALID_FROM) || '"->"' || TO_CHAR(:NEW.VALID_FROM) || '"'; END IF;
		IF UPDATING('FACTOR_A') AND :NEW.FACTOR_A <> :OLD.FACTOR_A THEN lv_detail := lv_detail || ' FACTOR_A: "' || TO_CHAR(:OLD.FACTOR_A) || '"->"' || TO_CHAR(:NEW.FACTOR_A) || '"'; END IF;
		IF UPDATING('FACTOR_B') AND (:NEW.FACTOR_B <> :OLD.FACTOR_B OR (:NEW.FACTOR_B IS NOT NULL AND :OLD.FACTOR_B IS NULL) OR (:NEW.FACTOR_B IS NULL AND :OLD.FACTOR_B IS NOT NULL)) THEN lv_detail := lv_detail || ' FACTOR_B: "' || TO_CHAR(:OLD.FACTOR_B) || '"->"' || TO_CHAR(:NEW.FACTOR_B) || '"'; END IF;
		IF UPDATING('REMOTE_CODE') AND (:NEW.REMOTE_CODE <> :OLD.REMOTE_CODE OR (:NEW.REMOTE_CODE IS NOT NULL AND :OLD.REMOTE_CODE IS NULL) OR (:NEW.REMOTE_CODE IS NULL AND :OLD.REMOTE_CODE IS NOT NULL)) THEN lv_detail := lv_detail || ' REMOTE_CODE: "' || :OLD.REMOTE_CODE || '"->"' || :NEW.REMOTE_CODE || '"'; END IF;
		IF UPDATING('MEMO') AND (:NEW.MEMO <> :OLD.MEMO OR (:NEW.MEMO IS NOT NULL AND :OLD.MEMO IS NULL) OR (:NEW.MEMO IS NULL AND :OLD.MEMO IS NOT NULL)) THEN lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"->"' || :NEW.MEMO || '"'; END IF;
		IF UPDATING('ID_UNIT_NUMENATOR') AND :NEW.ID_UNIT_NUMENATOR <> :OLD.ID_UNIT_NUMENATOR THEN lv_detail := lv_detail || ' ID_UNIT_NUMENATOR: "' || TO_CHAR(:OLD.ID_UNIT_NUMENATOR) || '"->"' || TO_CHAR(:NEW.ID_UNIT_NUMENATOR) || '"'; END IF;
		IF UPDATING('ID_UNIT_DENOMINATOR') AND (:NEW.ID_UNIT_DENOMINATOR <> :OLD.ID_UNIT_DENOMINATOR OR (:NEW.ID_UNIT_DENOMINATOR IS NOT NULL AND :OLD.ID_UNIT_DENOMINATOR IS NULL) OR (:NEW.ID_UNIT_DENOMINATOR IS NULL AND :OLD.ID_UNIT_DENOMINATOR IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_UNIT_DENOMINATOR: "' || TO_CHAR(:OLD.ID_UNIT_DENOMINATOR) || '"->"' || TO_CHAR(:NEW.ID_UNIT_DENOMINATOR) || '"'; END IF;
		IF UPDATING('EDITABLE') AND :NEW.EDITABLE <> :OLD.EDITABLE THEN lv_detail := lv_detail || ' EDITABLE: "' || TO_CHAR(:OLD.EDITABLE) || '"->"' || TO_CHAR(:NEW.EDITABLE) || '"'; END IF;
		IF UPDATING('VALID_TO') AND (:NEW.VALID_TO <> :OLD.VALID_TO OR (:NEW.VALID_TO IS NOT NULL AND :OLD.VALID_TO IS NULL) OR (:NEW.VALID_TO IS NULL AND :OLD.VALID_TO IS NOT NULL)) THEN lv_detail := lv_detail || ' VALID_TO: "' || TO_CHAR(:OLD.VALID_TO) || '"->"' || TO_CHAR(:NEW.VALID_TO) || '"'; END IF;
		IF UPDATING('CALCULATED') AND :NEW.CALCULATED <> :OLD.CALCULATED THEN lv_detail := lv_detail || ' CALCULATED: "' || TO_CHAR(:OLD.CALCULATED) || '"->"' || TO_CHAR(:NEW.CALCULATED) || '"'; END IF;
		IF UPDATING('UNCERTAINTY') AND (:NEW.UNCERTAINTY <> :OLD.UNCERTAINTY OR (:NEW.UNCERTAINTY IS NOT NULL AND :OLD.UNCERTAINTY IS NULL) OR (:NEW.UNCERTAINTY IS NULL AND :OLD.UNCERTAINTY IS NOT NULL)) THEN lv_detail := lv_detail || ' UNCERTAINTY: "' || TO_CHAR(:OLD.UNCERTAINTY) || '"->"' || TO_CHAR(:NEW.UNCERTAINTY) || '"'; END IF;
		IF UPDATING('FACTOR_C') AND (:NEW.FACTOR_C <> :OLD.FACTOR_C OR (:NEW.FACTOR_C IS NOT NULL AND :OLD.FACTOR_C IS NULL) OR (:NEW.FACTOR_C IS NULL AND :OLD.FACTOR_C IS NOT NULL)) THEN lv_detail := lv_detail || ' FACTOR_C: "' || TO_CHAR(:OLD.FACTOR_C) || '"->"' || TO_CHAR(:NEW.FACTOR_C) || '"'; END IF;
		IF UPDATING('MDL_A') AND (:NEW.MDL_A <> :OLD.MDL_A OR (:NEW.MDL_A IS NOT NULL AND :OLD.MDL_A IS NULL) OR (:NEW.MDL_A IS NULL AND :OLD.MDL_A IS NOT NULL)) THEN lv_detail := lv_detail || ' MDL_A: "' || :OLD.MDL_A || '"->"' || :NEW.MDL_A || '"'; END IF;
		IF UPDATING('ID_REMOTE_MATERIAL_CODE') AND (:NEW.ID_REMOTE_MATERIAL_CODE <> :OLD.ID_REMOTE_MATERIAL_CODE OR (:NEW.ID_REMOTE_MATERIAL_CODE IS NOT NULL AND :OLD.ID_REMOTE_MATERIAL_CODE IS NULL) OR (:NEW.ID_REMOTE_MATERIAL_CODE IS NULL AND :OLD.ID_REMOTE_MATERIAL_CODE IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_REMOTE_MATERIAL_CODE: "' || TO_CHAR(:OLD.ID_REMOTE_MATERIAL_CODE) || '"->"' || TO_CHAR(:NEW.ID_REMOTE_MATERIAL_CODE) || '"'; END IF;
		IF UPDATING('ID_REMOTE_CODE_LOAD') AND (:NEW.ID_REMOTE_CODE_LOAD <> :OLD.ID_REMOTE_CODE_LOAD OR (:NEW.ID_REMOTE_CODE_LOAD IS NOT NULL AND :OLD.ID_REMOTE_CODE_LOAD IS NULL) OR (:NEW.ID_REMOTE_CODE_LOAD IS NULL AND :OLD.ID_REMOTE_CODE_LOAD IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_REMOTE_CODE_LOAD: "' || TO_CHAR(:OLD.ID_REMOTE_CODE_LOAD) || '"->"' || TO_CHAR(:NEW.ID_REMOTE_CODE_LOAD) || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL_NODE: "' || TO_CHAR(:OLD.ID_MATERIAL_NODE) || '"';
		lv_detail := lv_detail || ' ID_ANALYSIS_PARAM: "' || TO_CHAR(:OLD.ID_ANALYSIS_PARAM) || '"';
		lv_detail := lv_detail || ' VALID_FROM: "' || TO_CHAR(:OLD.VALID_FROM) || '"';
		lv_detail := lv_detail || ' FACTOR_A: "' || TO_CHAR(:OLD.FACTOR_A) || '"';
		lv_detail := lv_detail || ' FACTOR_B: "' || TO_CHAR(:OLD.FACTOR_B) || '"';
		lv_detail := lv_detail || ' REMOTE_CODE: "' || :OLD.REMOTE_CODE || '"';
		lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"';
		lv_detail := lv_detail || ' ID_UNIT_NUMENATOR: "' || TO_CHAR(:OLD.ID_UNIT_NUMENATOR) || '"';
		lv_detail := lv_detail || ' ID_UNIT_DENOMINATOR: "' || TO_CHAR(:OLD.ID_UNIT_DENOMINATOR) || '"';
		lv_detail := lv_detail || ' EDITABLE: "' || TO_CHAR(:OLD.EDITABLE) || '"';
		lv_detail := lv_detail || ' VALID_TO: "' || TO_CHAR(:OLD.VALID_TO) || '"';
		lv_detail := lv_detail || ' CALCULATED: "' || TO_CHAR(:OLD.CALCULATED) || '"';
		lv_detail := lv_detail || ' UNCERTAINTY: "' || TO_CHAR(:OLD.UNCERTAINTY) || '"';
		lv_detail := lv_detail || ' FACTOR_C: "' || TO_CHAR(:OLD.FACTOR_C) || '"';
		lv_detail := lv_detail || ' MDL_A: "' || :OLD.MDL_A || '"';
		lv_detail := lv_detail || ' ID_REMOTE_MATERIAL_CODE: "' || TO_CHAR(:OLD.ID_REMOTE_MATERIAL_CODE) || '"';
		lv_detail := lv_detail || ' ID_REMOTE_CODE_LOAD: "' || TO_CHAR(:OLD.ID_REMOTE_CODE_LOAD) || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 31, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_ANALYSIS_AUDIT" ENABLE;
