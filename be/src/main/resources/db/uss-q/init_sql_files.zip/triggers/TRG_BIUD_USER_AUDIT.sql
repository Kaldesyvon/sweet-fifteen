--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_USER_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_USER_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_NODE,LOGIN,NAME,SURNAME,FUNCTION,ENABLED,EMAIL,PHONE,ID_LANGUAGE,ID_NODE_DEF,TIMEZONE,SKIN,MAIL_NOTIFICATION,ID_UNIT_SET,ID_SCOPE_DEF,ID_ANALYSIS_PARAM_DEF
            ON GBC_USER
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_NODE: "' || TO_CHAR(:NEW.ID_NODE) || '"';
		lv_detail := lv_detail || ' LOGIN: "' || :NEW.LOGIN || '"';
		lv_detail := lv_detail || ' NAME: "' || :NEW.NAME || '"';
		lv_detail := lv_detail || ' SURNAME: "' || :NEW.SURNAME || '"';
		lv_detail := lv_detail || ' FUNCTION: "' || :NEW.FUNCTION || '"';
		lv_detail := lv_detail || ' ENABLED: "' || TO_CHAR(:NEW.ENABLED) || '"';
		lv_detail := lv_detail || ' EMAIL: "' || :NEW.EMAIL || '"';
		lv_detail := lv_detail || ' PHONE: "' || :NEW.PHONE || '"';
		lv_detail := lv_detail || ' ID_LANGUAGE: "' || TO_CHAR(:NEW.ID_LANGUAGE) || '"';
		lv_detail := lv_detail || ' ID_NODE_DEF: "' || TO_CHAR(:NEW.ID_NODE_DEF) || '"';
		lv_detail := lv_detail || ' TIMEZONE: "' || :NEW.TIMEZONE || '"';
		lv_detail := lv_detail || ' SKIN: "' || :NEW.SKIN || '"';
		lv_detail := lv_detail || ' MAIL_NOTIFICATION: "' || TO_CHAR(:NEW.MAIL_NOTIFICATION) || '"';
		lv_detail := lv_detail || ' ID_UNIT_SET: "' || TO_CHAR(:NEW.ID_UNIT_SET) || '"';
		lv_detail := lv_detail || ' ID_SCOPE_DEF: "' || TO_CHAR(:NEW.ID_SCOPE_DEF) || '"';
		lv_detail := lv_detail || ' ID_ANALYSIS_PARAM_DEF: "' || TO_CHAR(:NEW.ID_ANALYSIS_PARAM_DEF) || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_NODE') AND (:NEW.ID_NODE <> :OLD.ID_NODE OR (:NEW.ID_NODE IS NOT NULL AND :OLD.ID_NODE IS NULL) OR (:NEW.ID_NODE IS NULL AND :OLD.ID_NODE IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_NODE: "' || TO_CHAR(:OLD.ID_NODE) || '"->"' || TO_CHAR(:NEW.ID_NODE) || '"'; END IF;
		IF UPDATING('LOGIN') AND :NEW.LOGIN <> :OLD.LOGIN THEN lv_detail := lv_detail || ' LOGIN: "' || :OLD.LOGIN || '"->"' || :NEW.LOGIN || '"'; END IF;
		IF UPDATING('NAME') AND (:NEW.NAME <> :OLD.NAME OR (:NEW.NAME IS NOT NULL AND :OLD.NAME IS NULL) OR (:NEW.NAME IS NULL AND :OLD.NAME IS NOT NULL)) THEN lv_detail := lv_detail || ' NAME: "' || :OLD.NAME || '"->"' || :NEW.NAME || '"'; END IF;
		IF UPDATING('SURNAME') AND (:NEW.SURNAME <> :OLD.SURNAME OR (:NEW.SURNAME IS NOT NULL AND :OLD.SURNAME IS NULL) OR (:NEW.SURNAME IS NULL AND :OLD.SURNAME IS NOT NULL)) THEN lv_detail := lv_detail || ' SURNAME: "' || :OLD.SURNAME || '"->"' || :NEW.SURNAME || '"'; END IF;
		IF UPDATING('FUNCTION') AND (:NEW.FUNCTION <> :OLD.FUNCTION OR (:NEW.FUNCTION IS NOT NULL AND :OLD.FUNCTION IS NULL) OR (:NEW.FUNCTION IS NULL AND :OLD.FUNCTION IS NOT NULL)) THEN lv_detail := lv_detail || ' FUNCTION: "' || :OLD.FUNCTION || '"->"' || :NEW.FUNCTION || '"'; END IF;
		IF UPDATING('ENABLED') AND :NEW.ENABLED <> :OLD.ENABLED THEN lv_detail := lv_detail || ' ENABLED: "' || TO_CHAR(:OLD.ENABLED) || '"->"' || TO_CHAR(:NEW.ENABLED) || '"'; END IF;
		IF UPDATING('EMAIL') AND (:NEW.EMAIL <> :OLD.EMAIL OR (:NEW.EMAIL IS NOT NULL AND :OLD.EMAIL IS NULL) OR (:NEW.EMAIL IS NULL AND :OLD.EMAIL IS NOT NULL)) THEN lv_detail := lv_detail || ' EMAIL: "' || :OLD.EMAIL || '"->"' || :NEW.EMAIL || '"'; END IF;
		IF UPDATING('PHONE') AND (:NEW.PHONE <> :OLD.PHONE OR (:NEW.PHONE IS NOT NULL AND :OLD.PHONE IS NULL) OR (:NEW.PHONE IS NULL AND :OLD.PHONE IS NOT NULL)) THEN lv_detail := lv_detail || ' PHONE: "' || :OLD.PHONE || '"->"' || :NEW.PHONE || '"'; END IF;
		IF UPDATING('ID_LANGUAGE') AND :NEW.ID_LANGUAGE <> :OLD.ID_LANGUAGE THEN lv_detail := lv_detail || ' ID_LANGUAGE: "' || TO_CHAR(:OLD.ID_LANGUAGE) || '"->"' || TO_CHAR(:NEW.ID_LANGUAGE) || '"'; END IF;
		IF UPDATING('ID_NODE_DEF') AND :NEW.ID_NODE_DEF <> :OLD.ID_NODE_DEF THEN lv_detail := lv_detail || ' ID_NODE_DEF: "' || TO_CHAR(:OLD.ID_NODE_DEF) || '"->"' || TO_CHAR(:NEW.ID_NODE_DEF) || '"'; END IF;
		IF UPDATING('TIMEZONE') AND :NEW.TIMEZONE <> :OLD.TIMEZONE THEN lv_detail := lv_detail || ' TIMEZONE: "' || :OLD.TIMEZONE || '"->"' || :NEW.TIMEZONE || '"'; END IF;
		IF UPDATING('SKIN') AND (:NEW.SKIN <> :OLD.SKIN OR (:NEW.SKIN IS NOT NULL AND :OLD.SKIN IS NULL) OR (:NEW.SKIN IS NULL AND :OLD.SKIN IS NOT NULL)) THEN lv_detail := lv_detail || ' SKIN: "' || :OLD.SKIN || '"->"' || :NEW.SKIN || '"'; END IF;
		IF UPDATING('MAIL_NOTIFICATION') AND (:NEW.MAIL_NOTIFICATION <> :OLD.MAIL_NOTIFICATION OR (:NEW.MAIL_NOTIFICATION IS NOT NULL AND :OLD.MAIL_NOTIFICATION IS NULL) OR (:NEW.MAIL_NOTIFICATION IS NULL AND :OLD.MAIL_NOTIFICATION IS NOT NULL)) THEN lv_detail := lv_detail || ' MAIL_NOTIFICATION: "' || TO_CHAR(:OLD.MAIL_NOTIFICATION) || '"->"' || TO_CHAR(:NEW.MAIL_NOTIFICATION) || '"'; END IF;
		IF UPDATING('ID_UNIT_SET') AND :NEW.ID_UNIT_SET <> :OLD.ID_UNIT_SET THEN lv_detail := lv_detail || ' ID_UNIT_SET: "' || TO_CHAR(:OLD.ID_UNIT_SET) || '"->"' || TO_CHAR(:NEW.ID_UNIT_SET) || '"'; END IF;
		IF UPDATING('ID_SCOPE_DEF') AND (:NEW.ID_SCOPE_DEF <> :OLD.ID_SCOPE_DEF OR (:NEW.ID_SCOPE_DEF IS NOT NULL AND :OLD.ID_SCOPE_DEF IS NULL) OR (:NEW.ID_SCOPE_DEF IS NULL AND :OLD.ID_SCOPE_DEF IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_SCOPE_DEF: "' || TO_CHAR(:OLD.ID_SCOPE_DEF) || '"->"' || TO_CHAR(:NEW.ID_SCOPE_DEF) || '"'; END IF;
		IF UPDATING('ID_ANALYSIS_PARAM_DEF') AND (:NEW.ID_ANALYSIS_PARAM_DEF <> :OLD.ID_ANALYSIS_PARAM_DEF OR (:NEW.ID_ANALYSIS_PARAM_DEF IS NOT NULL AND :OLD.ID_ANALYSIS_PARAM_DEF IS NULL) OR (:NEW.ID_ANALYSIS_PARAM_DEF IS NULL AND :OLD.ID_ANALYSIS_PARAM_DEF IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_ANALYSIS_PARAM_DEF: "' || TO_CHAR(:OLD.ID_ANALYSIS_PARAM_DEF) || '"->"' || TO_CHAR(:NEW.ID_ANALYSIS_PARAM_DEF) || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_NODE: "' || TO_CHAR(:OLD.ID_NODE) || '"';
		lv_detail := lv_detail || ' LOGIN: "' || :OLD.LOGIN || '"';
		lv_detail := lv_detail || ' NAME: "' || :OLD.NAME || '"';
		lv_detail := lv_detail || ' SURNAME: "' || :OLD.SURNAME || '"';
		lv_detail := lv_detail || ' FUNCTION: "' || :OLD.FUNCTION || '"';
		lv_detail := lv_detail || ' ENABLED: "' || TO_CHAR(:OLD.ENABLED) || '"';
		lv_detail := lv_detail || ' EMAIL: "' || :OLD.EMAIL || '"';
		lv_detail := lv_detail || ' PHONE: "' || :OLD.PHONE || '"';
		lv_detail := lv_detail || ' ID_LANGUAGE: "' || TO_CHAR(:OLD.ID_LANGUAGE) || '"';
		lv_detail := lv_detail || ' ID_NODE_DEF: "' || TO_CHAR(:OLD.ID_NODE_DEF) || '"';
		lv_detail := lv_detail || ' TIMEZONE: "' || :OLD.TIMEZONE || '"';
		lv_detail := lv_detail || ' SKIN: "' || :OLD.SKIN || '"';
		lv_detail := lv_detail || ' MAIL_NOTIFICATION: "' || TO_CHAR(:OLD.MAIL_NOTIFICATION) || '"';
		lv_detail := lv_detail || ' ID_UNIT_SET: "' || TO_CHAR(:OLD.ID_UNIT_SET) || '"';
		lv_detail := lv_detail || ' ID_SCOPE_DEF: "' || TO_CHAR(:OLD.ID_SCOPE_DEF) || '"';
		lv_detail := lv_detail || ' ID_ANALYSIS_PARAM_DEF: "' || TO_CHAR(:OLD.ID_ANALYSIS_PARAM_DEF) || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 1, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_USER_AUDIT" ENABLE;
