--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_MATERIALNODEAP_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_MATERIALNODEAP_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_MATERIAL_NODE,ID_ANALYSIS_PARAM,ID_MATERIAL_NODE_ADV_BASIS,PROCESS_ADV,STD_DEVIATION,MEMO,ID_ANALYSIS_PARAM_EXPR,CONTENT_DETERMINATION_METHOD
            ON GBC_MATERIAL_NODE_AP
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL_NODE: "' || TO_CHAR(:NEW.ID_MATERIAL_NODE) || '"';
		lv_detail := lv_detail || ' ID_ANALYSIS_PARAM: "' || TO_CHAR(:NEW.ID_ANALYSIS_PARAM) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL_NODE_ADV_BASIS: "' || TO_CHAR(:NEW.ID_MATERIAL_NODE_ADV_BASIS) || '"';
		lv_detail := lv_detail || ' PROCESS_ADV: "' || TO_CHAR(:NEW.PROCESS_ADV) || '"';
		lv_detail := lv_detail || ' STD_DEVIATION: "' || TO_CHAR(:NEW.STD_DEVIATION) || '"';
		lv_detail := lv_detail || ' MEMO: "' || :NEW.MEMO || '"';
		lv_detail := lv_detail || ' ID_ANALYSIS_PARAM_EXPR: "' || TO_CHAR(:NEW.ID_ANALYSIS_PARAM_EXPR) || '"';
		lv_detail := lv_detail || ' CONTENT_DETERMINATION_METHOD: "' || :NEW.CONTENT_DETERMINATION_METHOD || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_MATERIAL_NODE') AND :NEW.ID_MATERIAL_NODE <> :OLD.ID_MATERIAL_NODE THEN lv_detail := lv_detail || ' ID_MATERIAL_NODE: "' || TO_CHAR(:OLD.ID_MATERIAL_NODE) || '"->"' || TO_CHAR(:NEW.ID_MATERIAL_NODE) || '"'; END IF;
		IF UPDATING('ID_ANALYSIS_PARAM') AND :NEW.ID_ANALYSIS_PARAM <> :OLD.ID_ANALYSIS_PARAM THEN lv_detail := lv_detail || ' ID_ANALYSIS_PARAM: "' || TO_CHAR(:OLD.ID_ANALYSIS_PARAM) || '"->"' || TO_CHAR(:NEW.ID_ANALYSIS_PARAM) || '"'; END IF;
		IF UPDATING('ID_MATERIAL_NODE_ADV_BASIS') AND (:NEW.ID_MATERIAL_NODE_ADV_BASIS <> :OLD.ID_MATERIAL_NODE_ADV_BASIS OR (:NEW.ID_MATERIAL_NODE_ADV_BASIS IS NOT NULL AND :OLD.ID_MATERIAL_NODE_ADV_BASIS IS NULL) OR (:NEW.ID_MATERIAL_NODE_ADV_BASIS IS NULL AND :OLD.ID_MATERIAL_NODE_ADV_BASIS IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_MATERIAL_NODE_ADV_BASIS: "' || TO_CHAR(:OLD.ID_MATERIAL_NODE_ADV_BASIS) || '"->"' || TO_CHAR(:NEW.ID_MATERIAL_NODE_ADV_BASIS) || '"'; END IF;
		IF UPDATING('PROCESS_ADV') AND :NEW.PROCESS_ADV <> :OLD.PROCESS_ADV THEN lv_detail := lv_detail || ' PROCESS_ADV: "' || TO_CHAR(:OLD.PROCESS_ADV) || '"->"' || TO_CHAR(:NEW.PROCESS_ADV) || '"'; END IF;
		IF UPDATING('STD_DEVIATION') AND (:NEW.STD_DEVIATION <> :OLD.STD_DEVIATION OR (:NEW.STD_DEVIATION IS NOT NULL AND :OLD.STD_DEVIATION IS NULL) OR (:NEW.STD_DEVIATION IS NULL AND :OLD.STD_DEVIATION IS NOT NULL)) THEN lv_detail := lv_detail || ' STD_DEVIATION: "' || TO_CHAR(:OLD.STD_DEVIATION) || '"->"' || TO_CHAR(:NEW.STD_DEVIATION) || '"'; END IF;
		IF UPDATING('MEMO') AND (:NEW.MEMO <> :OLD.MEMO OR (:NEW.MEMO IS NOT NULL AND :OLD.MEMO IS NULL) OR (:NEW.MEMO IS NULL AND :OLD.MEMO IS NOT NULL)) THEN lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"->"' || :NEW.MEMO || '"'; END IF;
		IF UPDATING('ID_ANALYSIS_PARAM_EXPR') AND (:NEW.ID_ANALYSIS_PARAM_EXPR <> :OLD.ID_ANALYSIS_PARAM_EXPR OR (:NEW.ID_ANALYSIS_PARAM_EXPR IS NOT NULL AND :OLD.ID_ANALYSIS_PARAM_EXPR IS NULL) OR (:NEW.ID_ANALYSIS_PARAM_EXPR IS NULL AND :OLD.ID_ANALYSIS_PARAM_EXPR IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_ANALYSIS_PARAM_EXPR: "' || TO_CHAR(:OLD.ID_ANALYSIS_PARAM_EXPR) || '"->"' || TO_CHAR(:NEW.ID_ANALYSIS_PARAM_EXPR) || '"'; END IF;
		IF UPDATING('CONTENT_DETERMINATION_METHOD') AND (:NEW.CONTENT_DETERMINATION_METHOD <> :OLD.CONTENT_DETERMINATION_METHOD OR (:NEW.CONTENT_DETERMINATION_METHOD IS NOT NULL AND :OLD.CONTENT_DETERMINATION_METHOD IS NULL) OR (:NEW.CONTENT_DETERMINATION_METHOD IS NULL AND :OLD.CONTENT_DETERMINATION_METHOD IS NOT NULL)) THEN lv_detail := lv_detail || ' CONTENT_DETERMINATION_METHOD: "' || :OLD.CONTENT_DETERMINATION_METHOD || '"->"' || :NEW.CONTENT_DETERMINATION_METHOD || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL_NODE: "' || TO_CHAR(:OLD.ID_MATERIAL_NODE) || '"';
		lv_detail := lv_detail || ' ID_ANALYSIS_PARAM: "' || TO_CHAR(:OLD.ID_ANALYSIS_PARAM) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL_NODE_ADV_BASIS: "' || TO_CHAR(:OLD.ID_MATERIAL_NODE_ADV_BASIS) || '"';
		lv_detail := lv_detail || ' PROCESS_ADV: "' || TO_CHAR(:OLD.PROCESS_ADV) || '"';
		lv_detail := lv_detail || ' STD_DEVIATION: "' || TO_CHAR(:OLD.STD_DEVIATION) || '"';
		lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"';
		lv_detail := lv_detail || ' ID_ANALYSIS_PARAM_EXPR: "' || TO_CHAR(:OLD.ID_ANALYSIS_PARAM_EXPR) || '"';
		lv_detail := lv_detail || ' CONTENT_DETERMINATION_METHOD: "' || :OLD.CONTENT_DETERMINATION_METHOD || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 26, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_MATERIALNODEAP_AUDIT" ENABLE;
