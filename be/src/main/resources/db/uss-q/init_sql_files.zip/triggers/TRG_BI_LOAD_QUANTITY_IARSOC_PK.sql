--------------------------------------------------------
--  DDL for Trigger TRG_BI_LOAD_QUANTITY_IARSOC_PK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BI_LOAD_QUANTITY_IARSOC_PK" 
   before insert on "GBC_LOAD_QUANTITY_IARSOC" 
   for each row 
begin  
   if inserting then 
     select LOAD_QUANTITY_IARSOC_SEQ.nextval into :NEW."ID" from dual; 
   end if; 
end;

/
ALTER TRIGGER "TRG_BI_LOAD_QUANTITY_IARSOC_PK" ENABLE;
