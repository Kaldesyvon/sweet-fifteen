--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_METERCERTIFICAT_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_METERCERTIFICAT_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_METER,NAME,DOCUMENT_NAME,DOCUMENT_CONTENT_TYPE,VALID_FROM,VALID_TO,MEMO
            ON GBC_METER_CERTIFICATE
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_METER: "' || TO_CHAR(:NEW.ID_METER) || '"';
		lv_detail := lv_detail || ' NAME: "' || :NEW.NAME || '"';
		lv_detail := lv_detail || ' DOCUMENT_NAME: "' || :NEW.DOCUMENT_NAME || '"';
		lv_detail := lv_detail || ' DOCUMENT_CONTENT_TYPE: "' || :NEW.DOCUMENT_CONTENT_TYPE || '"';
		lv_detail := lv_detail || ' VALID_FROM: "' || TO_CHAR(:NEW.VALID_FROM) || '"';
		lv_detail := lv_detail || ' VALID_TO: "' || TO_CHAR(:NEW.VALID_TO) || '"';
		lv_detail := lv_detail || ' MEMO: "' || :NEW.MEMO || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_METER') AND :NEW.ID_METER <> :OLD.ID_METER THEN lv_detail := lv_detail || ' ID_METER: "' || TO_CHAR(:OLD.ID_METER) || '"->"' || TO_CHAR(:NEW.ID_METER) || '"'; END IF;
		IF UPDATING('NAME') AND :NEW.NAME <> :OLD.NAME THEN lv_detail := lv_detail || ' NAME: "' || :OLD.NAME || '"->"' || :NEW.NAME || '"'; END IF;
		IF UPDATING('DOCUMENT_NAME') AND (:NEW.DOCUMENT_NAME <> :OLD.DOCUMENT_NAME OR (:NEW.DOCUMENT_NAME IS NOT NULL AND :OLD.DOCUMENT_NAME IS NULL) OR (:NEW.DOCUMENT_NAME IS NULL AND :OLD.DOCUMENT_NAME IS NOT NULL)) THEN lv_detail := lv_detail || ' DOCUMENT_NAME: "' || :OLD.DOCUMENT_NAME || '"->"' || :NEW.DOCUMENT_NAME || '"'; END IF;
		IF UPDATING('DOCUMENT_CONTENT_TYPE') AND (:NEW.DOCUMENT_CONTENT_TYPE <> :OLD.DOCUMENT_CONTENT_TYPE OR (:NEW.DOCUMENT_CONTENT_TYPE IS NOT NULL AND :OLD.DOCUMENT_CONTENT_TYPE IS NULL) OR (:NEW.DOCUMENT_CONTENT_TYPE IS NULL AND :OLD.DOCUMENT_CONTENT_TYPE IS NOT NULL)) THEN lv_detail := lv_detail || ' DOCUMENT_CONTENT_TYPE: "' || :OLD.DOCUMENT_CONTENT_TYPE || '"->"' || :NEW.DOCUMENT_CONTENT_TYPE || '"'; END IF;
		IF UPDATING('VALID_FROM') AND :NEW.VALID_FROM <> :OLD.VALID_FROM THEN lv_detail := lv_detail || ' VALID_FROM: "' || TO_CHAR(:OLD.VALID_FROM) || '"->"' || TO_CHAR(:NEW.VALID_FROM) || '"'; END IF;
		IF UPDATING('VALID_TO') AND (:NEW.VALID_TO <> :OLD.VALID_TO OR (:NEW.VALID_TO IS NOT NULL AND :OLD.VALID_TO IS NULL) OR (:NEW.VALID_TO IS NULL AND :OLD.VALID_TO IS NOT NULL)) THEN lv_detail := lv_detail || ' VALID_TO: "' || TO_CHAR(:OLD.VALID_TO) || '"->"' || TO_CHAR(:NEW.VALID_TO) || '"'; END IF;
		IF UPDATING('MEMO') AND (:NEW.MEMO <> :OLD.MEMO OR (:NEW.MEMO IS NOT NULL AND :OLD.MEMO IS NULL) OR (:NEW.MEMO IS NULL AND :OLD.MEMO IS NOT NULL)) THEN lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"->"' || :NEW.MEMO || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_METER: "' || TO_CHAR(:OLD.ID_METER) || '"';
		lv_detail := lv_detail || ' NAME: "' || :OLD.NAME || '"';
		lv_detail := lv_detail || ' DOCUMENT_NAME: "' || :OLD.DOCUMENT_NAME || '"';
		lv_detail := lv_detail || ' DOCUMENT_CONTENT_TYPE: "' || :OLD.DOCUMENT_CONTENT_TYPE || '"';
		lv_detail := lv_detail || ' VALID_FROM: "' || TO_CHAR(:OLD.VALID_FROM) || '"';
		lv_detail := lv_detail || ' VALID_TO: "' || TO_CHAR(:OLD.VALID_TO) || '"';
		lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 67, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_METERCERTIFICAT_AUDIT" ENABLE;
