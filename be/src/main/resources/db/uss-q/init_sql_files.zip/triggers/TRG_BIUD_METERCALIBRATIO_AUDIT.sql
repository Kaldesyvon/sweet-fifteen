--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_METERCALIBRATIO_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_METERCALIBRATIO_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_METER,CALIBRATION_BY,CALIBRATION_DATE,CALIBRATION_DESCRIPTION,CORRECTIVE_ACTIONS,MEMO
            ON GBC_METER_CALIBRATION
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_METER: "' || TO_CHAR(:NEW.ID_METER) || '"';
		lv_detail := lv_detail || ' CALIBRATION_BY: "' || :NEW.CALIBRATION_BY || '"';
		lv_detail := lv_detail || ' CALIBRATION_DATE: "' || TO_CHAR(:NEW.CALIBRATION_DATE) || '"';
		lv_detail := lv_detail || ' CALIBRATION_DESCRIPTION: "' || :NEW.CALIBRATION_DESCRIPTION || '"';
		lv_detail := lv_detail || ' CORRECTIVE_ACTIONS: "' || :NEW.CORRECTIVE_ACTIONS || '"';
		lv_detail := lv_detail || ' MEMO: "' || :NEW.MEMO || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_METER') AND :NEW.ID_METER <> :OLD.ID_METER THEN lv_detail := lv_detail || ' ID_METER: "' || TO_CHAR(:OLD.ID_METER) || '"->"' || TO_CHAR(:NEW.ID_METER) || '"'; END IF;
		IF UPDATING('CALIBRATION_BY') AND :NEW.CALIBRATION_BY <> :OLD.CALIBRATION_BY THEN lv_detail := lv_detail || ' CALIBRATION_BY: "' || :OLD.CALIBRATION_BY || '"->"' || :NEW.CALIBRATION_BY || '"'; END IF;
		IF UPDATING('CALIBRATION_DATE') AND :NEW.CALIBRATION_DATE <> :OLD.CALIBRATION_DATE THEN lv_detail := lv_detail || ' CALIBRATION_DATE: "' || TO_CHAR(:OLD.CALIBRATION_DATE) || '"->"' || TO_CHAR(:NEW.CALIBRATION_DATE) || '"'; END IF;
		IF UPDATING('CALIBRATION_DESCRIPTION') AND :NEW.CALIBRATION_DESCRIPTION <> :OLD.CALIBRATION_DESCRIPTION THEN lv_detail := lv_detail || ' CALIBRATION_DESCRIPTION: "' || :OLD.CALIBRATION_DESCRIPTION || '"->"' || :NEW.CALIBRATION_DESCRIPTION || '"'; END IF;
		IF UPDATING('CORRECTIVE_ACTIONS') AND :NEW.CORRECTIVE_ACTIONS <> :OLD.CORRECTIVE_ACTIONS THEN lv_detail := lv_detail || ' CORRECTIVE_ACTIONS: "' || :OLD.CORRECTIVE_ACTIONS || '"->"' || :NEW.CORRECTIVE_ACTIONS || '"'; END IF;
		IF UPDATING('MEMO') AND (:NEW.MEMO <> :OLD.MEMO OR (:NEW.MEMO IS NOT NULL AND :OLD.MEMO IS NULL) OR (:NEW.MEMO IS NULL AND :OLD.MEMO IS NOT NULL)) THEN lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"->"' || :NEW.MEMO || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_METER: "' || TO_CHAR(:OLD.ID_METER) || '"';
		lv_detail := lv_detail || ' CALIBRATION_BY: "' || :OLD.CALIBRATION_BY || '"';
		lv_detail := lv_detail || ' CALIBRATION_DATE: "' || TO_CHAR(:OLD.CALIBRATION_DATE) || '"';
		lv_detail := lv_detail || ' CALIBRATION_DESCRIPTION: "' || :OLD.CALIBRATION_DESCRIPTION || '"';
		lv_detail := lv_detail || ' CORRECTIVE_ACTIONS: "' || :OLD.CORRECTIVE_ACTIONS || '"';
		lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 66, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_METERCALIBRATIO_AUDIT" ENABLE;
