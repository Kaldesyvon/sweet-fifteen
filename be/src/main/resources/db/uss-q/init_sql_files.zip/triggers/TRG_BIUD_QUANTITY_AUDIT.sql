--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_QUANTITY_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_QUANTITY_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_MATERIAL_NODE,ID_UNIT,REMOTE_CODE,QUANTITY,MEMO,DATE_FROM,DATE_TO,AUTO_ANALYSIS,EDITABLE,IO,UNCERTAINTY,ID_METER,NUMBER_OF_MEASUREMENTS,ID_REMOTE_MATERIAL_CODE,ID_REMOTE_CODE_LOAD
            ON GBC_QUANTITY
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL_NODE: "' || TO_CHAR(:NEW.ID_MATERIAL_NODE) || '"';
		lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:NEW.ID_UNIT) || '"';
		lv_detail := lv_detail || ' REMOTE_CODE: "' || :NEW.REMOTE_CODE || '"';
		lv_detail := lv_detail || ' QUANTITY: "' || TO_CHAR(:NEW.QUANTITY) || '"';
		lv_detail := lv_detail || ' MEMO: "' || :NEW.MEMO || '"';
		lv_detail := lv_detail || ' DATE_FROM: "' || TO_CHAR(:NEW.DATE_FROM) || '"';
		lv_detail := lv_detail || ' DATE_TO: "' || TO_CHAR(:NEW.DATE_TO) || '"';
		lv_detail := lv_detail || ' AUTO_ANALYSIS: "' || TO_CHAR(:NEW.AUTO_ANALYSIS) || '"';
		lv_detail := lv_detail || ' EDITABLE: "' || TO_CHAR(:NEW.EDITABLE) || '"';
		lv_detail := lv_detail || ' IO: "' || TO_CHAR(:NEW.IO) || '"';
		lv_detail := lv_detail || ' UNCERTAINTY: "' || TO_CHAR(:NEW.UNCERTAINTY) || '"';
		lv_detail := lv_detail || ' ID_METER: "' || TO_CHAR(:NEW.ID_METER) || '"';
		lv_detail := lv_detail || ' NUMBER_OF_MEASUREMENTS: "' || TO_CHAR(:NEW.NUMBER_OF_MEASUREMENTS) || '"';
		lv_detail := lv_detail || ' ID_REMOTE_MATERIAL_CODE: "' || TO_CHAR(:NEW.ID_REMOTE_MATERIAL_CODE) || '"';
		lv_detail := lv_detail || ' ID_REMOTE_CODE_LOAD: "' || TO_CHAR(:NEW.ID_REMOTE_CODE_LOAD) || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_MATERIAL_NODE') AND :NEW.ID_MATERIAL_NODE <> :OLD.ID_MATERIAL_NODE THEN lv_detail := lv_detail || ' ID_MATERIAL_NODE: "' || TO_CHAR(:OLD.ID_MATERIAL_NODE) || '"->"' || TO_CHAR(:NEW.ID_MATERIAL_NODE) || '"'; END IF;
		IF UPDATING('ID_UNIT') AND :NEW.ID_UNIT <> :OLD.ID_UNIT THEN lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:OLD.ID_UNIT) || '"->"' || TO_CHAR(:NEW.ID_UNIT) || '"'; END IF;
		IF UPDATING('REMOTE_CODE') AND (:NEW.REMOTE_CODE <> :OLD.REMOTE_CODE OR (:NEW.REMOTE_CODE IS NOT NULL AND :OLD.REMOTE_CODE IS NULL) OR (:NEW.REMOTE_CODE IS NULL AND :OLD.REMOTE_CODE IS NOT NULL)) THEN lv_detail := lv_detail || ' REMOTE_CODE: "' || :OLD.REMOTE_CODE || '"->"' || :NEW.REMOTE_CODE || '"'; END IF;
		IF UPDATING('QUANTITY') AND :NEW.QUANTITY <> :OLD.QUANTITY THEN lv_detail := lv_detail || ' QUANTITY: "' || TO_CHAR(:OLD.QUANTITY) || '"->"' || TO_CHAR(:NEW.QUANTITY) || '"'; END IF;
		IF UPDATING('MEMO') AND (:NEW.MEMO <> :OLD.MEMO OR (:NEW.MEMO IS NOT NULL AND :OLD.MEMO IS NULL) OR (:NEW.MEMO IS NULL AND :OLD.MEMO IS NOT NULL)) THEN lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"->"' || :NEW.MEMO || '"'; END IF;
		IF UPDATING('DATE_FROM') AND :NEW.DATE_FROM <> :OLD.DATE_FROM THEN lv_detail := lv_detail || ' DATE_FROM: "' || TO_CHAR(:OLD.DATE_FROM) || '"->"' || TO_CHAR(:NEW.DATE_FROM) || '"'; END IF;
		IF UPDATING('DATE_TO') AND (:NEW.DATE_TO <> :OLD.DATE_TO OR (:NEW.DATE_TO IS NOT NULL AND :OLD.DATE_TO IS NULL) OR (:NEW.DATE_TO IS NULL AND :OLD.DATE_TO IS NOT NULL)) THEN lv_detail := lv_detail || ' DATE_TO: "' || TO_CHAR(:OLD.DATE_TO) || '"->"' || TO_CHAR(:NEW.DATE_TO) || '"'; END IF;
		IF UPDATING('AUTO_ANALYSIS') AND :NEW.AUTO_ANALYSIS <> :OLD.AUTO_ANALYSIS THEN lv_detail := lv_detail || ' AUTO_ANALYSIS: "' || TO_CHAR(:OLD.AUTO_ANALYSIS) || '"->"' || TO_CHAR(:NEW.AUTO_ANALYSIS) || '"'; END IF;
		IF UPDATING('EDITABLE') AND :NEW.EDITABLE <> :OLD.EDITABLE THEN lv_detail := lv_detail || ' EDITABLE: "' || TO_CHAR(:OLD.EDITABLE) || '"->"' || TO_CHAR(:NEW.EDITABLE) || '"'; END IF;
		IF UPDATING('IO') AND :NEW.IO <> :OLD.IO THEN lv_detail := lv_detail || ' IO: "' || TO_CHAR(:OLD.IO) || '"->"' || TO_CHAR(:NEW.IO) || '"'; END IF;
		IF UPDATING('UNCERTAINTY') AND (:NEW.UNCERTAINTY <> :OLD.UNCERTAINTY OR (:NEW.UNCERTAINTY IS NOT NULL AND :OLD.UNCERTAINTY IS NULL) OR (:NEW.UNCERTAINTY IS NULL AND :OLD.UNCERTAINTY IS NOT NULL)) THEN lv_detail := lv_detail || ' UNCERTAINTY: "' || TO_CHAR(:OLD.UNCERTAINTY) || '"->"' || TO_CHAR(:NEW.UNCERTAINTY) || '"'; END IF;
		IF UPDATING('ID_METER') AND (:NEW.ID_METER <> :OLD.ID_METER OR (:NEW.ID_METER IS NOT NULL AND :OLD.ID_METER IS NULL) OR (:NEW.ID_METER IS NULL AND :OLD.ID_METER IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_METER: "' || TO_CHAR(:OLD.ID_METER) || '"->"' || TO_CHAR(:NEW.ID_METER) || '"'; END IF;
		IF UPDATING('NUMBER_OF_MEASUREMENTS') AND (:NEW.NUMBER_OF_MEASUREMENTS <> :OLD.NUMBER_OF_MEASUREMENTS OR (:NEW.NUMBER_OF_MEASUREMENTS IS NOT NULL AND :OLD.NUMBER_OF_MEASUREMENTS IS NULL) OR (:NEW.NUMBER_OF_MEASUREMENTS IS NULL AND :OLD.NUMBER_OF_MEASUREMENTS IS NOT NULL)) THEN lv_detail := lv_detail || ' NUMBER_OF_MEASUREMENTS: "' || TO_CHAR(:OLD.NUMBER_OF_MEASUREMENTS) || '"->"' || TO_CHAR(:NEW.NUMBER_OF_MEASUREMENTS) || '"'; END IF;
		IF UPDATING('ID_REMOTE_MATERIAL_CODE') AND (:NEW.ID_REMOTE_MATERIAL_CODE <> :OLD.ID_REMOTE_MATERIAL_CODE OR (:NEW.ID_REMOTE_MATERIAL_CODE IS NOT NULL AND :OLD.ID_REMOTE_MATERIAL_CODE IS NULL) OR (:NEW.ID_REMOTE_MATERIAL_CODE IS NULL AND :OLD.ID_REMOTE_MATERIAL_CODE IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_REMOTE_MATERIAL_CODE: "' || TO_CHAR(:OLD.ID_REMOTE_MATERIAL_CODE) || '"->"' || TO_CHAR(:NEW.ID_REMOTE_MATERIAL_CODE) || '"'; END IF;
		IF UPDATING('ID_REMOTE_CODE_LOAD') AND (:NEW.ID_REMOTE_CODE_LOAD <> :OLD.ID_REMOTE_CODE_LOAD OR (:NEW.ID_REMOTE_CODE_LOAD IS NOT NULL AND :OLD.ID_REMOTE_CODE_LOAD IS NULL) OR (:NEW.ID_REMOTE_CODE_LOAD IS NULL AND :OLD.ID_REMOTE_CODE_LOAD IS NOT NULL)) THEN lv_detail := lv_detail || ' ID_REMOTE_CODE_LOAD: "' || TO_CHAR(:OLD.ID_REMOTE_CODE_LOAD) || '"->"' || TO_CHAR(:NEW.ID_REMOTE_CODE_LOAD) || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_MATERIAL_NODE: "' || TO_CHAR(:OLD.ID_MATERIAL_NODE) || '"';
		lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:OLD.ID_UNIT) || '"';
		lv_detail := lv_detail || ' REMOTE_CODE: "' || :OLD.REMOTE_CODE || '"';
		lv_detail := lv_detail || ' QUANTITY: "' || TO_CHAR(:OLD.QUANTITY) || '"';
		lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"';
		lv_detail := lv_detail || ' DATE_FROM: "' || TO_CHAR(:OLD.DATE_FROM) || '"';
		lv_detail := lv_detail || ' DATE_TO: "' || TO_CHAR(:OLD.DATE_TO) || '"';
		lv_detail := lv_detail || ' AUTO_ANALYSIS: "' || TO_CHAR(:OLD.AUTO_ANALYSIS) || '"';
		lv_detail := lv_detail || ' EDITABLE: "' || TO_CHAR(:OLD.EDITABLE) || '"';
		lv_detail := lv_detail || ' IO: "' || TO_CHAR(:OLD.IO) || '"';
		lv_detail := lv_detail || ' UNCERTAINTY: "' || TO_CHAR(:OLD.UNCERTAINTY) || '"';
		lv_detail := lv_detail || ' ID_METER: "' || TO_CHAR(:OLD.ID_METER) || '"';
		lv_detail := lv_detail || ' NUMBER_OF_MEASUREMENTS: "' || TO_CHAR(:OLD.NUMBER_OF_MEASUREMENTS) || '"';
		lv_detail := lv_detail || ' ID_REMOTE_MATERIAL_CODE: "' || TO_CHAR(:OLD.ID_REMOTE_MATERIAL_CODE) || '"';
		lv_detail := lv_detail || ' ID_REMOTE_CODE_LOAD: "' || TO_CHAR(:OLD.ID_REMOTE_CODE_LOAD) || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 7, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_QUANTITY_AUDIT" ENABLE;
