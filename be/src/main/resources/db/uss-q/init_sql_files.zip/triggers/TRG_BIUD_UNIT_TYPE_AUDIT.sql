--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_UNIT_TYPE_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_UNIT_TYPE_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,NAME_K,MEMO_K,QUANTITY,ANALYSIS,COMPUTE
            ON GBC_UNIT_TYPE
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' NAME_K: "' || :NEW.NAME_K || '"';
		lv_detail := lv_detail || ' MEMO_K: "' || :NEW.MEMO_K || '"';
		lv_detail := lv_detail || ' QUANTITY: "' || TO_CHAR(:NEW.QUANTITY) || '"';
		lv_detail := lv_detail || ' ANALYSIS: "' || TO_CHAR(:NEW.ANALYSIS) || '"';
		lv_detail := lv_detail || ' COMPUTE: "' || TO_CHAR(:NEW.COMPUTE) || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('NAME_K') AND :NEW.NAME_K <> :OLD.NAME_K THEN lv_detail := lv_detail || ' NAME_K: "' || :OLD.NAME_K || '"->"' || :NEW.NAME_K || '"'; END IF;
		IF UPDATING('MEMO_K') AND (:NEW.MEMO_K <> :OLD.MEMO_K OR (:NEW.MEMO_K IS NOT NULL AND :OLD.MEMO_K IS NULL) OR (:NEW.MEMO_K IS NULL AND :OLD.MEMO_K IS NOT NULL)) THEN lv_detail := lv_detail || ' MEMO_K: "' || :OLD.MEMO_K || '"->"' || :NEW.MEMO_K || '"'; END IF;
		IF UPDATING('QUANTITY') AND :NEW.QUANTITY <> :OLD.QUANTITY THEN lv_detail := lv_detail || ' QUANTITY: "' || TO_CHAR(:OLD.QUANTITY) || '"->"' || TO_CHAR(:NEW.QUANTITY) || '"'; END IF;
		IF UPDATING('ANALYSIS') AND :NEW.ANALYSIS <> :OLD.ANALYSIS THEN lv_detail := lv_detail || ' ANALYSIS: "' || TO_CHAR(:OLD.ANALYSIS) || '"->"' || TO_CHAR(:NEW.ANALYSIS) || '"'; END IF;
		IF UPDATING('COMPUTE') AND :NEW.COMPUTE <> :OLD.COMPUTE THEN lv_detail := lv_detail || ' COMPUTE: "' || TO_CHAR(:OLD.COMPUTE) || '"->"' || TO_CHAR(:NEW.COMPUTE) || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' NAME_K: "' || :OLD.NAME_K || '"';
		lv_detail := lv_detail || ' MEMO_K: "' || :OLD.MEMO_K || '"';
		lv_detail := lv_detail || ' QUANTITY: "' || TO_CHAR(:OLD.QUANTITY) || '"';
		lv_detail := lv_detail || ' ANALYSIS: "' || TO_CHAR(:OLD.ANALYSIS) || '"';
		lv_detail := lv_detail || ' COMPUTE: "' || TO_CHAR(:OLD.COMPUTE) || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 51, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_UNIT_TYPE_AUDIT" ENABLE;
