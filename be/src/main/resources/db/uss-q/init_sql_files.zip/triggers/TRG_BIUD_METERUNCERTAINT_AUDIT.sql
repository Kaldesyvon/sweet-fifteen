--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_METERUNCERTAINT_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_METERUNCERTAINT_AUDIT" 
            BEFORE INSERT OR DELETE OR UPDATE OF ID,ID_METER,LOWER_RANGE,UNCERTAINTY,UPPER_RANGE,ID_UNIT,VALID_FROM
            ON GBC_METER_UNCERTAINTY
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' ID_METER: "' || TO_CHAR(:NEW.ID_METER) || '"';
		lv_detail := lv_detail || ' LOWER_RANGE: "' || TO_CHAR(:NEW.LOWER_RANGE) || '"';
		lv_detail := lv_detail || ' UNCERTAINTY: "' || TO_CHAR(:NEW.UNCERTAINTY) || '"';
		lv_detail := lv_detail || ' UPPER_RANGE: "' || TO_CHAR(:NEW.UPPER_RANGE) || '"';
		lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:NEW.ID_UNIT) || '"';
		lv_detail := lv_detail || ' VALID_FROM: "' || TO_CHAR(:NEW.VALID_FROM) || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('ID_METER') AND :NEW.ID_METER <> :OLD.ID_METER THEN lv_detail := lv_detail || ' ID_METER: "' || TO_CHAR(:OLD.ID_METER) || '"->"' || TO_CHAR(:NEW.ID_METER) || '"'; END IF;
		IF UPDATING('LOWER_RANGE') AND :NEW.LOWER_RANGE <> :OLD.LOWER_RANGE THEN lv_detail := lv_detail || ' LOWER_RANGE: "' || TO_CHAR(:OLD.LOWER_RANGE) || '"->"' || TO_CHAR(:NEW.LOWER_RANGE) || '"'; END IF;
		IF UPDATING('UNCERTAINTY') AND :NEW.UNCERTAINTY <> :OLD.UNCERTAINTY THEN lv_detail := lv_detail || ' UNCERTAINTY: "' || TO_CHAR(:OLD.UNCERTAINTY) || '"->"' || TO_CHAR(:NEW.UNCERTAINTY) || '"'; END IF;
		IF UPDATING('UPPER_RANGE') AND :NEW.UPPER_RANGE <> :OLD.UPPER_RANGE THEN lv_detail := lv_detail || ' UPPER_RANGE: "' || TO_CHAR(:OLD.UPPER_RANGE) || '"->"' || TO_CHAR(:NEW.UPPER_RANGE) || '"'; END IF;
		IF UPDATING('ID_UNIT') AND :NEW.ID_UNIT <> :OLD.ID_UNIT THEN lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:OLD.ID_UNIT) || '"->"' || TO_CHAR(:NEW.ID_UNIT) || '"'; END IF;
		IF UPDATING('VALID_FROM') AND :NEW.VALID_FROM <> :OLD.VALID_FROM THEN lv_detail := lv_detail || ' VALID_FROM: "' || TO_CHAR(:OLD.VALID_FROM) || '"->"' || TO_CHAR(:NEW.VALID_FROM) || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' ID_METER: "' || TO_CHAR(:OLD.ID_METER) || '"';
		lv_detail := lv_detail || ' LOWER_RANGE: "' || TO_CHAR(:OLD.LOWER_RANGE) || '"';
		lv_detail := lv_detail || ' UNCERTAINTY: "' || TO_CHAR(:OLD.UNCERTAINTY) || '"';
		lv_detail := lv_detail || ' UPPER_RANGE: "' || TO_CHAR(:OLD.UPPER_RANGE) || '"';
		lv_detail := lv_detail || ' ID_UNIT: "' || TO_CHAR(:OLD.ID_UNIT) || '"';
		lv_detail := lv_detail || ' VALID_FROM: "' || TO_CHAR(:OLD.VALID_FROM) || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 70, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_METERUNCERTAINT_AUDIT" ENABLE;
