--------------------------------------------------------
--  DDL for Sequence REGION_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "REGION_SEQ"  MINVALUE 4 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 22 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
