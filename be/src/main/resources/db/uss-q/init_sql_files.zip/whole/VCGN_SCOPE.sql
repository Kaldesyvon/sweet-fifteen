--------------------------------------------------------
--  DDL for View VCGN_SCOPE
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_SCOPE" ("ID", "NAME", "MEMO", "OBJ_VERSION", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "ADMIN_ONLY", "ID_SCOPE_FUEL_SPEC", "SCOPE_FUEL_SPEC_NAME", "ID_SCOPE_PROCESS_SPEC", "SCOPE_PROCESS_SPEC_NAME", "ID_SCOPE_TYPE_SPEC", "SCOPE_TYPE_SPEC_NAME") AS
  SELECT   s.ID,
            NVL (NVL (dul.translation, de.translation), s.NAME_K) name,
            s.MEMO,
            s.OBJ_VERSION,
            s.CREATED_BY,
            s.CREATED,
            s.MODIFIED_BY,
            s.MODIFIED,
            s.ADMIN_ONLY,
            S.ID_SCOPE_FUEL_SPEC,
            sfs.name SCOPE_FUEL_SPEC_NAME,
            S.ID_SCOPE_PROCESS_SPEC,
            sps.name SCOPE_PROCESS_SPEC_NAME,
            S.ID_SCOPE_TYPE_SPEC,
            sts.name SCOPE_TYPE_SPEC_NAME
     FROM                  gbc_scope s
                        LEFT OUTER JOIN
                           vcgn_dictionary_usr_lng dul
                        ON dul.key = s.name_k
                     LEFT OUTER JOIN
                        vcgn_dictionary_en de
                     ON de.key = s.name_k
                  LEFT OUTER JOIN
                     VCGN_SCOPE_FUEL_SPEC sfs
                  ON sfs.id = S.ID_SCOPE_FUEL_SPEC
               LEFT OUTER JOIN
                  VCGN_SCOPE_PROCESS_SPEC sps
               ON sps.id = S.ID_SCOPE_PROCESS_SPEC
            LEFT OUTER JOIN
               VCGN_SCOPE_TYPE_SPEC sts
            ON sts.id = S.ID_SCOPE_TYPE_SPEC 
;
