--------------------------------------------------------
--  DDL for Sequence EVENT_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "EVENT_SEQ"  MINVALUE 14440 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 926064 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
