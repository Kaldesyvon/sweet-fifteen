--------------------------------------------------------
--  DDL for View VCGN_REGION
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_REGION" ("ID", "NAME", "REPORT_POS", "MEMO", "CREATED_BY", "CREATED", "MODIFIED_BY", "MODIFIED", "OBJ_VERSION") AS
  SELECT   r.ID,
            NVL (NVL (dul.translation, de.translation), r.NAME_K) name,
            r.REPORT_POS,
            r.MEMO,
            r.CREATED_BY,
            r.CREATED,
            r.MODIFIED_BY,
            r.MODIFIED,
            r.OBJ_VERSION
     FROM         gbc_region r
               LEFT OUTER JOIN
                  vcgn_dictionary_usr_lng dul
               ON dul.key = r.name_k
            LEFT OUTER JOIN
               vcgn_dictionary_en de
            ON de.key = r.name_k 
;
