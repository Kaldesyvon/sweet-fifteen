--------------------------------------------------------
--  DDL for Sequence BUSINESS_UNIT_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "BUSINESS_UNIT_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 161 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
