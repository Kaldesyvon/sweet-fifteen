--------------------------------------------------------
--  DDL for View VCGN_SCOPE_TYPE_SPEC
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VCGN_SCOPE_TYPE_SPEC" ("ID", "NAME") AS
  SELECT   sts.id,
            NVL (NVL (dul.translation, de.translation), sts.NAME_K) name
     FROM         GBC_SCOPE_TYPE_SPEC sts
               LEFT OUTER JOIN
                  vcgn_dictionary_usr_lng dul
               ON dul.key = sts.name_k
            LEFT OUTER JOIN
               vcgn_dictionary_en de
            ON de.key = sts.name_k 
;
