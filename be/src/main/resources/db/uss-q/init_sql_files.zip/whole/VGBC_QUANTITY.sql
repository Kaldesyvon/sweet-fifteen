--------------------------------------------------------
--  DDL for View VGBC_QUANTITY
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "VGBC_QUANTITY" ("ID", "ID_NODE", "ID_MATERIAL", "ID_MATERIAL_NODE", "ID_UNIT_SET", "ID_UNIT_FROM", "ID_UNIT_TO", "ID_UNIT_SET_SETTINGS", "QUANTITY", "UNIT_TO_ABBR", "DATE_FROM", "DATE_TO", "IO", "REMOTE_CODE", "MEMO", "QUANTITY_FROM", "MATERIAL_NAME", "PLANT_NAME", "CREATED", "CREATED_BY", "MODIFIED", "MODIFIED_BY", "EDITABLE", "AUTO_ANALYSIS", "NODE_REPORT_POS", "MATERIAL_REPORT_POS", "UNCERTAINTY", "NUMBER_OF_MEASUREMENTS", "ID_METER", "ID_REMOTE_MATERIAL_CODE") AS
  SELECT q.id id,
    p.id id_node,
    m.id id_material,
    mp.id id_material_node,
    us.id id_unit_set,
    unit_from.id id_unit_from,
    unit_to.id id_unit_to,
    uss_to.id id_unit_set_settings,
    ( unit_to.k / unit_from.k * q.quantity + unit_to.q - unit_from.q * (unit_to.k / unit_from.k)) quantity,
    unit_to.abbr unit_to_abbr,
    q.date_from date_from,
    q.date_to date_to,
    q.io io,
    q.remote_code remote_code,
    q.memo memo,
    q.quantity quantity_from, --nepotrebne
    m.name material_name,
    p.name_k plant_name,
    q.created created,
    q.created_by created_by,
    q.modified modified,
    q.modified_by modified_by,
    q.editable editable,
    q.auto_analysis auto_analysis,
    p.report_pos NODE_REPORT_POS,
    m.report_pos MATERIAL_REPORT_POS,
    q.UNCERTAINTY UNCERTAINTY,
    q.NUMBER_OF_MEASUREMENTS NUMBER_OF_MEASUREMENTS,
    q.ID_METER ID_METER,
    q.ID_REMOTE_MATERIAL_CODE ID_REMOTE_MATERIAL_CODE
  FROM gbc_quantity q
  CROSS JOIN gbc_unit_set us
  INNER JOIN gbc_material_node mp
  ON mp.ID = q.ID_MATERIAL_NODE
  INNER JOIN gbc_material m
  ON m.id = mp.id_material
  INNER JOIN gbc_node p
  ON p.id = mp.id_node
  INNER JOIN gbc_unit unit_from
  ON unit_from.id = q.id_unit
  LEFT OUTER JOIN GBC_UNIT_SET_SETTINGS uss_to
  ON uss_to.id_unit_set  = us.id
  AND uss_to.id_material = m.id
  LEFT OUTER JOIN gbc_unit unit_to
  ON unit_to.id = uss_to.id_unit
;
