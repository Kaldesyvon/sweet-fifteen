--------------------------------------------------------
--  DDL for Trigger TRG_BIUD_BUSINESS_UNIT_AUDIT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BIUD_BUSINESS_UNIT_AUDIT"
            BEFORE INSERT OR DELETE OR UPDATE OF ID,CODE,NAME_K,MEMO,REPORT_POSITION
            ON GBC_BUSINESS_UNIT
            FOR EACH ROW 
            DECLARE
              lv_detail   VARCHAR2(32767 BYTE);
              lv_iud      VARCHAR2(1 BYTE);
              lv_app_user VARCHAR2(20 BYTE);
            BEGIN
              lv_app_user := USER;
            
              -- INSERT
              IF INSERTING THEN
              BEGIN
                lv_iud := 'I';
            
                lv_detail := 'ID: "' || TO_CHAR(:NEW.ID) || '"';
		lv_detail := lv_detail || ' CODE: "' || :NEW.CODE || '"';
		lv_detail := lv_detail || ' NAME_K: "' || :NEW.NAME_K || '"';
		lv_detail := lv_detail || ' MEMO: "' || :NEW.MEMO || '"';
		lv_detail := lv_detail || ' REPORT_POSITION: "' || TO_CHAR(:NEW.REPORT_POSITION) || '"';
                
                lv_app_user := :NEW.CREATED_BY;
              END;
              END IF;
              
              -- UPDATE
              IF UPDATING THEN
              BEGIN
                lv_iud := 'U';
              
                
		IF UPDATING('ID') AND :NEW.ID <> :OLD.ID THEN lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"->"' || TO_CHAR(:NEW.ID) || '"'; ELSE lv_detail := lv_detail || ' ID: "' || TO_CHAR(:OLD.ID) || '"'; END IF;
		IF UPDATING('CODE') AND :NEW.CODE <> :OLD.CODE THEN lv_detail := lv_detail || ' CODE: "' || :OLD.CODE || '"->"' || :NEW.CODE || '"'; END IF;
		IF UPDATING('NAME_K') AND :NEW.NAME_K <> :OLD.NAME_K THEN lv_detail := lv_detail || ' NAME_K: "' || :OLD.NAME_K || '"->"' || :NEW.NAME_K || '"'; END IF;
		IF UPDATING('MEMO') AND (:NEW.MEMO <> :OLD.MEMO OR (:NEW.MEMO IS NOT NULL AND :OLD.MEMO IS NULL) OR (:NEW.MEMO IS NULL AND :OLD.MEMO IS NOT NULL)) THEN lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"->"' || :NEW.MEMO || '"'; END IF;
		IF UPDATING('REPORT_POSITION') AND (:NEW.REPORT_POSITION <> :OLD.REPORT_POSITION OR (:NEW.REPORT_POSITION IS NOT NULL AND :OLD.REPORT_POSITION IS NULL) OR (:NEW.REPORT_POSITION IS NULL AND :OLD.REPORT_POSITION IS NOT NULL)) THEN lv_detail := lv_detail || ' REPORT_POSITION: "' || TO_CHAR(:OLD.REPORT_POSITION) || '"->"' || TO_CHAR(:NEW.REPORT_POSITION) || '"'; END IF;
                
                IF SUBSTR(lv_detail,1,1) = ' ' THEN lv_detail := SUBSTR(lv_detail,2); END IF;
                
                IF UPDATING('MODIFIED_BY') THEN lv_app_user := :NEW.MODIFIED_BY; ELSE lv_app_user := NVL(:OLD.MODIFIED_BY, USER); END IF;
              END;
              END IF;
              
              -- DELETE
              IF DELETING THEN
              BEGIN
                lv_iud := 'D';
                
                lv_detail := 'ID: "' || TO_CHAR(:OLD.ID) || '"';
		lv_detail := lv_detail || ' CODE: "' || :OLD.CODE || '"';
		lv_detail := lv_detail || ' NAME_K: "' || :OLD.NAME_K || '"';
		lv_detail := lv_detail || ' MEMO: "' || :OLD.MEMO || '"';
		lv_detail := lv_detail || ' REPORT_POSITION: "' || TO_CHAR(:OLD.REPORT_POSITION) || '"';
              END;
              END IF;
            
              -- insert audit record  
              INSERT INTO GBC_JOURNAL (ID, DETAIL, CREATED_BY, CREATED, ID_TYPE, IUD)
                VALUES (JOURNAL_SEQ.NEXTVAL, SUBSTR(lv_detail,1,4000), lv_app_user, SYSTIMESTAMP, 53, lv_iud);
            END;
/
ALTER TRIGGER "TRG_BIUD_BUSINESS_UNIT_AUDIT" ENABLE;
