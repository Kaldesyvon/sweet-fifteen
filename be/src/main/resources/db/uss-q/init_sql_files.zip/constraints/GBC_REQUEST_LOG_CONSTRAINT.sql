--------------------------------------------------------
--  Constraints for Table GBC_REQUEST_LOG
--------------------------------------------------------

  ALTER TABLE "GBC_REQUEST_LOG" MODIFY ("URL" NOT NULL ENABLE);
  ALTER TABLE "GBC_REQUEST_LOG" MODIFY ("CALLED_BY" NOT NULL ENABLE);
  ALTER TABLE "GBC_REQUEST_LOG" MODIFY ("START_DATETIME" NOT NULL ENABLE);
