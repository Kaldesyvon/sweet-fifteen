--------------------------------------------------------
--  Constraints for Table GBC_YEAR
--------------------------------------------------------

  ALTER TABLE "GBC_YEAR" MODIFY ("YEAR" NOT NULL ENABLE);
  ALTER TABLE "GBC_YEAR" ADD CONSTRAINT "GBC_YEAR_PK" PRIMARY KEY ("YEAR")
  USING INDEX "GBC_YEAR_PK"  ENABLE;
